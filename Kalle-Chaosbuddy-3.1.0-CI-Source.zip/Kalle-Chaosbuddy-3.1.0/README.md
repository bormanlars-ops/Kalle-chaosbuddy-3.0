# Kalle – Chaosbuddy 3.0.3

Grafisches und räumliches Widget-Update auf Basis 3.0.2-Hintergrund, keine Neuentwicklung.
Paket `de.boyka.kallebuddy`, versionCode 30008, versionName 3.0.3.

Maßgeblich: [Updateanleitung](README-Update-3.0.3.txt), [Testbericht](TESTREPORT-3.0.3.md),
[Architektur](ARCHITECTURE.md), [Signierung](SIGNING.md). Dokumente früherer Versionen sind historische Berichte.

- SpriteRig: konsistente transparente Gelenkfigur aus PNG-Referenz, 24 bestehende Zustände.
- WorldMotion: Bodenkoordinaten, perspektivische Skalierung, feste Objekte, Ablaufphasen.
- WorldAssets/WorldViews: geteilte Bitmapressourcen und native RemoteViews-Ebenen.
- WorldSpeech: gefiltertes vorhandenes Dialogmaterial, gelegentliche native Einblendung.
- WidgetStory/WidgetState: bestehende Kontextwahl und Interaktionen weiterverwendet.
- Missionsdaten, Statistik, Erinnerungen, Popups, Sound und Hintergrund unverändert.

Android Studio / JDK 21 / SDK 35 / Build Tools 35.0.0 / Gradle 8.9 / AGP 8.7.3.
`./gradlew assembleRelease` baut die unsignierte Release-APK. Anschließend externen
Originalschlüssel verwenden (SIGNING.md). Keine Schlüssel/Passwörter im Archiv.
Alternativ `build-local.sh` mit ANDROID_SDK_ROOT, KALLE_KEYSTORE und KALLE_STOREPASS.
Gradle benötigt beim erstmaligen Build Internetzugriff für Werkzeuge/Testbibliotheken;
die fertige App benötigt keinen neuen Netzwerkzugriff.

Gezielte Tests:
```
./gradlew testDebugUnitTest --tests 'de.boyka.kallebuddy.WorldTest' \
  --tests 'de.boyka.kallebuddy.WidgetTest.everyExistingSceneCanRender' \
  --tests 'de.boyka.kallebuddy.CoreTest.notificationActionsStartCompleteAndSnooze' \
  --tests 'de.boyka.kallebuddy.CoreTest.threeSnoozesExactlyNinety'
```
Nachweise und Kontaktbögen: qa-3.0.3/. Keine realen Samsung-Tests behauptet.
