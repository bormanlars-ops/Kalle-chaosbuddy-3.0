Grafikherkunft 3.0.3
Kalle-Referenz.png: bereitgestellte transparente 1122×1402-PNG, unverändert als Referenz.
res/drawable-nodpi/kalle_rig.png: mit Bildgenerierung anhand dieser Referenz abgeleitetes
3×4-Atlas, konsistente Kopfvarianten, Rumpf, je zwei Armabschnitte, zwei Beine und Tasche.
kalle_torso.png: passend abgeleiteter ärmelloser Rumpf; ersetzt Atlas-Rumpf beim Laden,
um sichtbare doppelte Ruheärmel zu verhindern. Vordergrund vollständig transparent.
Runtime trimmt Alpharänder und verwendet proportionale Gelenktransformationen.
Keine vorgetäuschte Einzelbild-Ersetzung sämtlicher Zustände. Props bleiben getrennte
bisherige Vektorzeichnungen. Originales Widget-Hintergrund-JPEG unverändert.
