# Tests 3.0.2

36 unterschiedliche Tests erfolgreich; 34 im vollständigen ersten Lauf,
danach gezielte Wiederholungen und Ergänzungen. Tatsächliche Nachweise und
Zwischenfehler stehen in TESTREPORT-3.0.2.md und qa-3.0.2/.

Ausführen: `./gradlew testDebugUnitTest`. API 35, Robolectric/native Grafik.
Keine echten Samsung-Gerätetests durchgeführt.
