# Aktuelle Auslieferung 3.0.3

versionCode 30008; gesicherter Zwischenstand 30007. Identisches Zertifikat wie
3.0.2-Hintergrund (30006) durch apksigner geprüft. Privater Originalschlüssel
extern, kein Ersatzschlüssel erzeugt. Direkte Installation auf Hardware nicht geprüft.

# Aktuelle Version 3.0.2

Release 30005 und Zwischenstand 30004 verwenden denselben externen Schlüssel
wie die ausgelieferte 3.0.1 (30003). Kein privater Schlüssel im Projekt.

# Aktueller Stand 3.0.1

Version 30003 verwendet dasselbe externe Zertifikat wie 3.0 (30001) und
der Zwischenstand 3.0.1 (30002). Kein privater Schlüssel im Projekt.

# Signierung

Die neue gesicherte Versionslinie startet mit Build 01 (30000); der finale
Build 3.0.0 hat versionCode 30001 und dasselbe Zertifikat. Der verlorene frühere
temporäre Schlüssel und der ursprüngliche 2.0-Schlüssel sind nicht verfügbar.
Keine Signaturkompatibilität mit anders signierten Altinstallationen behaupten.

Kein privater Schlüssel und kein Passwort im Quellarchiv. Separate Dateien:
`Chaosbuddy-3-Signiersicherung.zip` und `Privater-Schluesselzugang.txt`.
Alias: `kalle`, Format: passwortgeschütztes PKCS12. Privat/offline sichern.
Öffentlicher Fingerabdruck: `signing-certificate.txt`.

Linux, JDK 21 und Android SDK Platform 35 / Build Tools 35.0.0:

```bash
export ANDROID_SDK_ROOT=/absoluter/pfad/android-sdk
export KALLE_KEYSTORE=/privater/pfad/Chaosbuddy-3-Signierschluessel.p12
read -rs -p 'Keystore-Passwort: ' KALLE_STOREPASS; echo
export KALLE_STOREPASS
./build-local.sh
unset KALLE_STOREPASS
```

Das Skript erstellt keinen Ersatzschlüssel bei einem Fehler. Die signierte APK
liegt danach im Nachbarverzeichnis `deliverables`. Das Passwort wird apksigner als
Umgebungsvariable übergeben. `./gradlew assembleDebug` verwendet dagegen einen
lokalen Debug-Schlüssel und ist keine Aktualisierung einer Auslieferungs-APK.

Für spätere Updates versionCode in Manifest und app/build.gradle erhöhen,
applicationId und privaten Schlüssel beibehalten. Schlüssel nie öffentlich teilen.
