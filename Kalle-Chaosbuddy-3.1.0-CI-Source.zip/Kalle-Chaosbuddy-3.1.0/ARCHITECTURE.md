# Widget-Erweiterung 3.0.3

Widget-Provider und 4×4-Metadaten bleiben erhalten. Ab API 31 erzeugt WorldViews
RemoteViews-Ebenen in der bisherigen Bühnenfläche. Hintergrund bleibt unverändert.
WorldMotion berechnet normierte Bodenpositionen und Fußanker, Tiefe sowie
APPROACH/SETTLE/USE/RISE/LEAVE. Lagerobjekte werden unabhängig gezeichnet und
nach Bodenposition vor/hinter dem Körper eingeordnet. Geteilte kleine Sprites
werden nur im Layout skaliert, um die Bitmap-Nutzlast zu begrenzen.
SpriteRig zeichnet zwei Arme/zwei Beine, Kopf-/Gesichtsvarianten und Handrequisiten.

Ein nativer ViewFlipper enthält 256 Schritte/four scenes, ein zweiter langsam
wechselnde Sprechtexte mit nativer Alpha-Ausblendung. Der Launcher führt die
Animationen aus. Kein eigener Timerdienst oder hochfrequenter Widget-Updateauftrag.
Finite Programme werden bei vorhandenen Ereignissen/regulären Widgetupdates
neu gewählt. Kontextwechsel mitten in einer gespeicherten Schleife wird erst bei
der nächsten Aktualisierung sichtbar. API 28–30 hat einen statischen Fallback.

Missionsspeicher/Scheduler/Benachrichtigungen bleiben unverändert; keine Schemaänderung.
Zusätzlicher Widgetzustand liegt ausschließlich in den vorhandenen Widgetpräferenzen.
Die folgenden Abschnitte stammen aus der Vorgängerversion und beschreiben deren Basis.

# Architektur 3.0.2

Basis ist das ausgelieferte 3.0.1-Projekt. Mission, MissionCodec, Store,
Stats/WeeklyStats, Needs, DialogSystem und KalleScene sind unverändert. Die
JSON-Daten im bisherigen SharedPreferences-Store `missions`, Schema 3,
bleiben erhalten. Widgetzustand bleibt im bestehenden Bereich kalle_revier_301.
Neue Widget-Programmfelder sind lokal je ID; Löschen eines Widgets löscht
keine Missionen. Der neue Missionsfenster-Schalter ist in der bestehenden
Backup-Typprüfung erfasst.

Die sichtbaren Bilder sind native RemoteViews. KalleWidget bindet direkte,
explizite und immutable Broadcast-Aktionen je Widget und dargestellter Szene.
Berührungen wählen Sprache/Reaktion über die bestehenden Dialog-/Needs-Werte.
Nur bewusste Schaltflächen wie MISSIONEN oder der vollständige Text öffnen
weiterhin eine Activity. Keine Activity-Trampoline beim Berühren der Figur.

WidgetStory erstellt vier kontextabhängige Aktivitäten in acht Abschnitten.
Ein einzelner nativer ViewFlipper zeigt 256 Bildplätze, je Abschnitt 32.
Bitmaps derselben Pose werden wiederverwendet; adaptive Auflösung hält den
RemoteViews-Bitmapcache unter dem Displaylimit. Native Host-Sichtbarkeit
pausiert den Takt. Keine neuen AlarmManager-Updates und kein Widget-Dienst.
Ein laufendes Programm wiederholt sich; neue Auswahl nur bei Inhaltsupdates.
Das ist eine bewusste Grenze klassischer AppWidgets.

CoachView skaliert die komplette Zeichenfläche proportional mit Randreserve.
Normale Arme werden bei gehobenen/gekreuzten Sonderhaltungen ausgespart.
Überblendung verschiedener Posen entfällt, um Doppelkonturen zu vermeiden.

Der bisherige CompanionService bleibt eine nicht registrierte interne Brücke.
MissionPopupService ist ein separater, nicht exportierter shortService nur für
fällige Missionen. Er zeigt maximal 40 Sekunden ein begrenztes Overlay-Fenster,
nutzt denselben Missions-Notification-ID und dieselben revisionsgesicherten
PendingIntents. Audio kommt über den bestehenden Kanal missions_3 mit
explizitem Standardton. Alte Kanaleinstellungen werden respektiert.
Sperrbildschirm/Display-Aus verhindern das Fenster; Start-/Fensterfehler
lassen die bereits gesendete Benachrichtigung bestehen. Schließen, Aktionen,
Timeout und Display-Aus entfernen das Fenster und beenden den Dienst.
Es gibt keine kontinuierliche Figur außerhalb des Widgets.

Scheduler.dismiss schließt zusätzlich ein zum Missions-ID gehörendes Fenster.
MissionReceiver aktualisiert nach Aktionen auch das Widget, damit neue
Needs-Werte dort ankommen. Missions-/Snooze-/Wiederholungsberechnung bleibt
unverändert. Mehrfache Auslieferung derselben Aktion zählt weiterhin nur einmal.
