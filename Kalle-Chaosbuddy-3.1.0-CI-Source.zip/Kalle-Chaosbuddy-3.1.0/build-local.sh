#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-../tooling/sdk}}"
if [ ! -d "$SDK" ]; then
  echo "FEHLER: Android SDK nicht gefunden: $SDK" >&2
  echo "ANDROID_SDK_ROOT auf den installierten SDK-Ordner setzen (Platform 35, Build Tools 35.0.0)." >&2
  exit 2
fi
SDK="$(cd "$SDK" && pwd)"
BT="$SDK/build-tools/35.0.0"
JAR="$SDK/platforms/android-35/android.jar"
BUILD="$PWD/build"
for required in "$SDK/platforms/android-35/android.jar" "$SDK/build-tools/35.0.0/aapt2" "$SDK/build-tools/35.0.0/d8" "$SDK/build-tools/35.0.0/apksigner"; do
  if [ ! -f "$required" ]; then echo "FEHLER: SDK-Komponente fehlt: $required" >&2; exit 2; fi
done
mkdir -p "$BUILD/classes" "$BUILD/generated" "$BUILD/dex" "$PWD/../deliverables"
"$BT/aapt2" compile --dir app/src/main/res -o "$BUILD/resources.zip"
python3 - "$BUILD/AndroidManifest.xml" <<'PYMANIFEST'
from pathlib import Path
import sys
Path(sys.argv[1]).write_text(Path('app/src/main/AndroidManifest.xml').read_text().replace('<manifest ', '<manifest package="de.boyka.kallebuddy" ', 1))
PYMANIFEST
"$BT/aapt2" link -I "$JAR" --manifest "$BUILD/AndroidManifest.xml" --java "$BUILD/generated" --auto-add-overlay -o "$BUILD/unsigned.apk" "$BUILD/resources.zip"
find app/src/main/java "$BUILD/generated" -name '*.java' -print > "$BUILD/sources.txt"
javac --release 8 -encoding UTF-8 -classpath "$JAR" -d "$BUILD/classes" @"$BUILD/sources.txt"
jar cf "$BUILD/classes.jar" -C "$BUILD/classes" .
"$BT/d8" --lib "$JAR" --min-api 28 --output "$BUILD/dex" "$BUILD/classes.jar"
(cd "$BUILD/dex" && zip -q -u "$BUILD/unsigned.apk" classes*.dex)
"$BT/zipalign" -f -p 4 "$BUILD/unsigned.apk" "$BUILD/aligned.apk"
KEYSTORE="${KALLE_KEYSTORE:?Privaten externen Keystore angeben}"
PASS="${KALLE_STOREPASS:?Passwort als Umgebungsvariable angeben}"
[ -f "$KEYSTORE" ] || { echo 'Keystore fehlt'; exit 2; }
"$BT/apksigner" sign --ks "$KEYSTORE" --ks-pass env:KALLE_STOREPASS --v4-signing-enabled false --ks-key-alias kalle --out "$PWD/../deliverables/Kalle-Chaosbuddy-3.1.0.apk" "$BUILD/aligned.apk"
"$BT/apksigner" verify --verbose "$PWD/../deliverables/Kalle-Chaosbuddy-3.1.0.apk"
"$BT/aapt2" dump badging "$PWD/../deliverables/Kalle-Chaosbuddy-3.1.0.apk" > "$BUILD/apk-badging.txt"
head -8 "$BUILD/apk-badging.txt"
