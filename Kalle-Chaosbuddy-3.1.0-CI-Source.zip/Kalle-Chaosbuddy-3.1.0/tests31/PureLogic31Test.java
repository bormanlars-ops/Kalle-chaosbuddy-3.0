package de.boyka.kallebuddy;
import java.time.*;
import java.util.*;
/** Standalone JDK regression tests for new pure-Java rules; not Android instrumentation. */
public final class PureLogic31Test {
 static int checks=0;
 static void ok(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
 static MissionCommandParser.Result parse(String s){return MissionCommandParser.parse(s,LocalDateTime.of(2026,11,8,8,30));}
 public static void main(String[] args){
  MissionCommandParser.Result r=parse("Kalle, morgen um 16:30 einkaufen und die Tüte mitnehmen.");
  ok(r.valid(),"basic parse: "+r.error);
  ok("Einkaufen".equals(r.title),"title: "+r.title);
  ok("die Tüte mitnehmen".equals(r.note),"note: "+r.note);
  ok(r.dateTime.equals(LocalDateTime.of(2026,11,9,16,30)),"time/date");
  ok(parse("heute um 18 Uhr Wäsche waschen").valid(),"today hour");
  ok(parse("übermorgen um 12:05 Arzt anrufen").valid(),"dayafter");
  ok(parse("am 12.11.2026 um 09:15 einkaufen").valid(),"explicit date");
  ok(parse("am Montag um 07 Uhr Müll rausbringen").valid(),"weekday");
  ok(parse("morgen schlafen").error!=null,"no time");
  ok(parse("um 18:00 Müll rausbringen").error!=null,"no date");
  ok(parse("heute um 02:30 Müll rausbringen").error!=null,"past hour");
  ok(parse("morgen um 10:00 oder um 12:00 einkaufen").error!=null,"two times");
  ok(parse("morgen übermorgen um 10 Uhr einkaufen").error!=null,"two dates");
  ok(parse("am 31.02.2026 um 10 Uhr einkaufen").error!=null,"invalid date");
  ok(parse("morgen um 16:30 einkaufen oder schlafen").error!=null,"ambiguous task");
  MissionCommandParser.Result dst=MissionCommandParser.parse("am 29.03.2026 um 02:30 einkaufen",LocalDateTime.of(2026,3,1,12,0));
  ok(dst.valid(),"DST parse");
  try{dst.millis(ZoneId.of("Europe/Berlin"));throw new AssertionError("DST gap accepted");}catch(IllegalArgumentException expected){checks++;}
  for(int hour=0;hour<24;hour++){
   LivingWorldBrain.Daypart period=LivingWorldBrain.period(hour);
   if(hour<6||hour>=23)ok(period==LivingWorldBrain.Daypart.NIGHT,"night "+hour);
   else if(hour<10)ok(period==LivingWorldBrain.Daypart.MORNING,"morning "+hour);
   else if(hour<18)ok(period==LivingWorldBrain.Daypart.DAY,"day "+hour);
   else ok(period==LivingWorldBrain.Daypart.EVENING,"evening "+hour);
   LivingWorldBrain.Choice a=LivingWorldBrain.plan(hour,70,50,false,false,0,false,null,100000000L,100000000L,42);
   ok(a.actions.length==8,"scenes length");
   for(int j=1;j<a.actions.length;j++)ok(a.actions[j]!=a.actions[j-1],"adjacent repeat "+hour+"/"+j);
  }
  LivingWorldBrain.Choice nightly=LivingWorldBrain.plan(1,80,50,false,false,0,false,null,10000000L,10000000L,43);
  ok(nightly.actions[0]==KalleScene.Action.TENT,"night sleep");
  LivingWorldBrain.Choice done=LivingWorldBrain.plan(12,80,50,false,false,3,true,null,10000000L,10000000L,43);
  ok(done.actions[0]==KalleScene.Action.DANCE,"earned reaction only");
  LivingWorldBrain.Choice soon=LivingWorldBrain.plan(12,80,50,false,true,0,false,null,10000000L,10000000L,43);
  ok(soon.actions[0]==KalleScene.Action.LOOK,"upcoming mission attention");
  LivingWorldBrain.Choice overdue=LivingWorldBrain.plan(12,80,50,true,false,0,false,null,10000000L,10000000L,43);
  ok(overdue.actions[0]==KalleScene.Action.LOOK,"real overdue reaction");
  LivingWorldBrain.Choice a=LivingWorldBrain.plan(14,80,50,false,false,0,false,null,100000000L,0,24);
  LivingWorldBrain.Choice b=LivingWorldBrain.plan(14,80,50,false,false,0,false,null,100000000L,0,24);
  ok(Arrays.equals(a.actions,b.actions)&&Objects.equals(a.event,b.event),"determinism");
  System.out.println("PASS: "+checks+" pure logic assertions");
 }
}
