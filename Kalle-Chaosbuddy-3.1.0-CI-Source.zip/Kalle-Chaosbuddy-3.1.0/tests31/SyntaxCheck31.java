import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;
/** Syntax-only parse; does not simulate Android's type checker or Gradle. */
public final class SyntaxCheck31 {
 public static void main(String[] argv) throws Exception {
  JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
  DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
  try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,null,null);
      Stream<Path> walk=Files.walk(Paths.get("app/src/main/java"))){
   List<File> files=walk.filter(p->p.toString().endsWith(".java")).map(Path::toFile).collect(Collectors.toList());
   JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,Arrays.asList("-proc:none"),null,manager.getJavaFileObjectsFromFiles(files));
   task.parse();
   int bad=0;
   for(Diagnostic<? extends JavaFileObject> d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR){System.err.println(d);bad++;}
   if(bad>0)throw new AssertionError(bad+" syntax errors");
   System.out.println("PASS: "+files.size()+" Java source files parsed without syntax errors (not an Android build)");
  }
 }
}
