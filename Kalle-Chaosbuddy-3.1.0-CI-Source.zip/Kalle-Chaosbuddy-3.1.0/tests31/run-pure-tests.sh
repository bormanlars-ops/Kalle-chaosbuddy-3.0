#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p tests31/classes
javac -encoding UTF-8 -d tests31/classes app/src/main/java/de/boyka/kallebuddy/{KalleScene,MissionCommandParser,LivingWorldBrain}.java tests31/PureLogic31Test.java tests31/SyntaxCheck31.java
java -cp tests31/classes de.boyka.kallebuddy.PureLogic31Test
java -cp tests31/classes SyntaxCheck31
