# Testbericht Kalle – Chaosbuddy 3.0.3

Stand: 07.11.2026. Paket `de.boyka.kallebuddy`, versionCode **30008**, versionName **3.0.3**.
Basis: tatsächlich vorhandene, ausgelieferte 3.0.2-Hintergrund (30006). 30007 war der vor Tests gesicherte Zwischenstand. Keine verfügbare fertige 3.0.3 wurde überschrieben.

## Änderungen

- Dauerhafte Sprechblase entfernt. Native Einblendung 3,5 Sekunden plus 0,5 Sekunden Ausblenden. Standardabstand 90 Sekunden, gespeicherter Häufigkeitswert wird verwendet. Acht ausgewählte Texte pro Programm, danach Wiederholung; neue Auswahl bei Kontext-/Widget-Ereignissen und regulären Aktualisierungen. Vorhandener Spruchbestand unverändert (264 Einträge). Stimmung, Energie, Tageszeit, Tätigkeit und Antippen fließen ein. Gespeicherte wartende Mission hat Vorrang; Benachrichtigungen bleiben unabhängig.
- Getrennte Ebenen für Bodenobjekt, Sitz, Schatten, Figur und Vordergrundobjekt. Lagerstellen bleiben innerhalb der Szene fest. Hinlaufen, Hinsetzen/Benutzen, Aufstehen und Weglaufen; beim Zelt gebeugter Eintritt mit Ausblenden im Zelt und anschließendem Austritt.
- Wegpunkte auf einer simulierten Bodenfläche, gleichmäßige perspektivische Größenänderung mit Fußanker. Kein echtes 3D und kein freies Dragging. Mitgeführte Einkaufstasche gehört weiterhin in passenden Posen zur Figur; Lagerobjekte kleben nicht am Körper.
- Einheitliches transparentes Gelenk-Rig aus der gelieferten PNG-Referenz abgeleitet: Kopfvarianten, ärmelloser Rumpf, zwei Oberarme, zwei Unterarme/Hände, zwei Beine. Alle 24 vorhandenen Zustände verwenden weiterhin unterschiedliche Posen/Bewegungen und passende separate Requisiten. Keine Ersetzung aller Animationen durch ein Standbild. Es handelt sich um aus der Referenz abgeleitete Grafiken, keine pixelidentischen vollständigen Neuzeichnungen aller 24 Szenen. Outfitwahl beeinflusst weiterhin die Kleidung.
- Vorhandene Widget-Fläche und Provider-Identität beibehalten. Kein globaler Figuren-Overlay. Antippen sendet einen Broadcast und öffnet keine Activity. Missionen/Scene/Pause-Schaltflächen bleiben.

## Tatsächlich ausgeführte Prüfungen

Robolectric 4.14.1, Android-35-Framework, native Grafik, JDK 21, SDK 35, Gradle 8.9/AGP 8.7.3. Sieben verschiedene gezielte Tests sind in ihren letzten Ausführungen erfolgreich; kein vollständiger erneuter historischer Regressionstestlauf behauptet.

| Test | Ergebnis / Nachweis |
|---|---|
| WorldTest.nativeWorldAndSpeechFadeAndMemory | Bestanden im abschließenden Lauf: 256 Weltbilder, 8 Sprüche, native Einblendanimation, Alpha nach 4,5 s = 0, nächster Text nach Intervall, Speichergrenze. Für den Uhrtest wurde ausschließlich im Test auf 6 s verkürzt. |
| WorldTest.pathsDepthGroundAndObjectAnchors | Bestanden: alle 24 Zustände, drei Größen, vier Abschnitte mit je 64 Schritten; Grenzen, konstantes Seitenverhältnis, Fußanker, Tiefenskalierung, Anschluss der Wege, feste Objektposition, Zelteintritt. |
| WorldTest.directTouchQuotesAndMissionPriority | Bestanden: kein Activity-Start, Reaktion am aktuellen Ort, Gehen zum Zelt ist kein Schlafen, Aufwachen im Zelt, acht verschiedene Texte, Missionsvorrang ohne Änderung gespeicherter Missionen. |
| WorldTest.renderAllRigScenesAndCampPhases | Bestanden: transparente Grafikteile, 24 Posen, Feuer/Zelt/Stuhl in vier Ablaufphasen. |
| WidgetTest.everyExistingSceneCanRender | Bestanden: alle vorhandenen Szenen darstellbar, unterschiedliche Kompositionen; 24 Zustände und 264 Sprüche erhalten. |
| CoreTest.notificationActionsStartCompleteAndSnooze | Bestanden: bestehende Starten-/Erledigt-/Aufschieben-Aktionspfade. |
| CoreTest.threeSnoozesExactlyNinety | Bestanden: dreimal 30 Minuten = exakt 90 Minuten. |
| Gradle assembleRelease / lintVitalRelease | Erfolgreich, abschließender Build in world-release.log. Java-8-Veraltungswarnungen, kein Buildfehler. |
| apksigner verify | Erfolgreich, APK-Signaturschema v3, RSA 3072. Gleiches Zertifikat wie 3.0.2-Hintergrund. |
| zipalign / Paket / Version | Erfolgreich: de.boyka.kallebuddy / 30008 / 3.0.3, minSdk 28, targetSdk 35. |
| Geschützte Dateien / Hintergrund | Bytevergleich erfolgreich: Missionsspeicher, Statistik, Dialogkatalog, Erinnerungs-/Popup-Code unverändert. Hintergrund-JPEG byteidentisch. Keine Datenbankmigration oder Änderung der Missionsdatenstruktur. |
| Sichtkontrolle | 24 Posen sowie Lagerphasen als gerenderte Kontaktbögen angesehen. Keine zusätzlichen Ruheärmel; Schlafpose, gehobene Arme und Stuhl-Ebene korrigiert. Keine visuell erkannten zusätzlichen Gliedmaßen. |

Gemessene Bitmap-Nutzlast im abschließenden Test: 6.121.984 Bytes bei Profilgrenze 8.788.824 Bytes. Das ist ein Framework-Speichertest, keine Akku- oder Binder-Messung auf Samsung-Hardware.

Während der Entwicklung gab es echte fehlgeschlagene Prüfungen: zu schnelle Größenänderung beim Weggehen, fehlende Animationsausführung durch Robolectrics vereinfachten ViewAnimator und ein bereits auf 90 s eingeplanter Test-Callback. Wegphase korrigiert; Test verwendet reale Android-Animator-Methoden; Test-Flipper nach Intervallwechsel neu gestartet. Betroffene Prüfungen anschließend erfolgreich wiederholt. Rohprotokolle liegen bei.

## Grenzen und offene Gerätetests

- Vollständige Welttechnik verwendet zulässige RemoteViews-Layout-APIs ab Android 12. Auf Android 9–11 bleibt eine statische Darstellung als Fallback; Zielgerät Android 15 nutzt den Weltpfad.
- Vier vorbereitete Aktivitäten in einem zyklischen Programm, 64 Bilder je Aktivität. Standard 8 Bilder/s: 8 s pro Aktivität, 32 s pro Schleife. Je vorhandener Einstellung 5/8/10 nominelle Bilder/s; reale One-UI-Bildrate nicht gemessen. Perspektive verändert nur die Layoutgröße, keine neuen Bitmaps je Position.
- Keine permanente App-Tickschleife, kein neuer Hintergrunddienst, kein Widget-Alarm für die Animation. Zwei native Launcher-Flipper: Welt und langsame Sprechblase. Android stoppt ViewFlipper bei nicht sichtbarem Fenster; ob Samsung einzelne nicht sichtbare Homescreen-Seiten zusätzlich pausiert, bestimmt der Launcher und ist offen. Akkuverbrauch nicht auf Hardware gemessen.
- Automatische Abwechslung erfolgt innerhalb des vorbereiteten Programms; Auswahl reagiert auf Kontext bei Aktualisierungen/Ereignissen, nicht jede Sekunde auf eine neue Uhrzeit. Bis dahin wiederholt sich das Programm. Sprüche wiederholen sich standardmäßig nach acht Einträgen/12 Minuten, falls keine neue Auswahl stattfindet. Kein uneingeschränkt endloses Eigenleben behauptet.
- Gegenstände sind einfache, teilweise aus bisherigen Vektoren abgeleitete Grafiken. Der Einkaufswagen ist in dieser Fassung ein stationärer Szenengegenstand, keine rollende Physiksimulation. Kleidung wird gefärbt, nicht als neue Outfit-Garderobe nachgezeichnet.
- Der Screenshot world-speech-hidden.png ist ein statischer Robolectric-Canvas-Schnappschuss; die Canvas-Erfassung bildet die View-Animationsmatrix nicht zuverlässig ab. Er ist KEIN visueller Nachweis einer unsichtbaren Blase. Der native Animationstransformations-Test weist Alpha 0 nach. Die reale Ausblenddarstellung auf One UI bleibt zu prüfen.
- Keine Hardware-/ADB-Installation, kein realer Updateversuch und kein Samsung-Test durchgeführt. Offen: Hinzufügen/Seitentrennung/Verschieben/Größenwechsel, tatsächliche Sprechblasen-Ausblendung und Lesbarkeit, Launcher-Gesten, reale Bildrate/Akku, hörbarer Missionston und Overlay/Heads-up über YouTube/WhatsApp sowie Datenbestand nach echter Updateinstallation. Benachrichtigungskanäle, Töne, Berechtigungen und Popupcode wurden ausdrücklich nicht verändert.
- Updatekompatibilität ist durch gleiche Paketkennung, höhere Version und identisches Zertifikat technisch gegeben. Das ersetzt keinen tatsächlichen Installationstest und garantiert nichts für anders signierte Altinstallationen. `de.boyka.kalle` wird nicht aktualisiert.
