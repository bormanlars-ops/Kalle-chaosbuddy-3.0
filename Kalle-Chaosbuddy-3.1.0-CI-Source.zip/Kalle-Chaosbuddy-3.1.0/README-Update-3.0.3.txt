KALLE – CHAOSBUDDY 3.0.3 (30008)

UPDATE
1. Falls gewünscht vorher in der bestehenden App Daten exportieren.
2. Kalle-Chaosbuddy-3.0.3.apk öffnen und „Aktualisieren“ wählen.
   Bestehende App NICHT deinstallieren und Daten NICHT löschen.
3. Das vorhandene Widget bleibt mit gleicher Provider-Kennung erhalten.
   Falls One UI noch alte Bilder zeigt: App einmal öffnen, dann zurück zum Homescreen.
4. Bei einem neuen Widget: Homescreen lange drücken > Widgets > Kalle Chaosbuddy >
   4×4-Revier. Auf gewünschte Seite ziehen. Regulär verschieben/vergrößern im Launcher.
5. Kalle antippen: Reaktion direkt im Widget. Szene: optionale zusätzliche Auswahl.

Paket: de.boyka.kallebuddy. Kalle Missionschaot de.boyka.kalle bleibt getrennt.
Gleiches Signaturzertifikat wie ausgelieferte 3.0.2-Hintergrund (30006).
SHA-256: 867d34ed80f46a07a49febaccc0aa7d3ea99517bf85c9fe13bdaee1c20256bb2
Bei „App nicht installiert“ nicht durch Deinstallation erzwingen: möglicherweise
anders signierte oder höher versionierte Installation. Erst Daten sichern/Version klären.

Sprechblase ca. 4 Sekunden, standardmäßig alle 90 Sekunden. Vier automatische
Aktivitäten als native Schleife, neue Auswahl bei Ereignissen/Systemupdates.
Keine neuen Berechtigungen. Missionserinnerungen/Overlay/Ton wie bisher.
Vollständige Welt ab Android 12, Android 9–11 statischer Fallback.
Samsung-/echte Installationstests offen; Details im TESTREPORT-3.0.3.md.
