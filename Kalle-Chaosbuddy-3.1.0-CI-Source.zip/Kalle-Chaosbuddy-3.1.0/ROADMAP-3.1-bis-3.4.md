# Nächste Schritte

Die aktuelle Grundversion behält vorhandene Szenen und Alttexte und ergänzt die
3.0-Missionslogik. Deshalb sind bereits 24 Vektorzustände und 264 eindeutige
Standardsprüche vorhanden. Diese Anzahl allein ersetzt keinen Geräte-/Design-Test.

| Version | Nächster Schwerpunkt |
|---|---|
| 3.1 | Animationen und Übergänge weiter verfeinern; Outfits, Saisonverhalten und Tagesrhythmus auf echten Geräten prüfen. |
| 3.2 | Kategorien, Textqualität und Interaktionen ausbauen; bestehende virtuelle Spenden, Zelt und Schlafszenen überarbeiten. |
| 3.3 | Automatische Sonntagsberichte, echte Wochenvergleiche, dauerhaftes Berichtarchiv mit eindeutiger ISO-Wochenkennung. Dies ist noch nicht implementiert. |
| 3.4 | One-UI- und Akku-Profiling, Bedienbarkeit, große Schrift, weitere Launcher und grafischer Feinschliff. |

Für jedes Update dieselbe applicationId `de.boyka.kallebuddy`, denselben jetzt
gesicherten privaten Signierschlüssel und einen höheren versionCode verwenden.
Aktuell: 30001. Neue Datenfelder mit Defaultwerten/Migrationen ergänzen, niemals
Datenbanken löschen. Vor jedem Update sichern, Tests und Signaturprüfung erneut
laufen lassen. Datenmodell, Originaltermine und Aufschiebeereignisse weiterführen.

Vor einem breiten Einsatz noch auf S22 Ultra / Android 15 testen: Installation,
Launcher-Appwechsel, Schublade/Recents, Sperre/Entsperren, Neustart, echte
Benachrichtigungsaktionen, Doze über Nacht und Akkuverbrauch.
