# TESTREPORT – Kalle Chaosbuddy 3.0.1

Stand: 07.11.2026. **Signierte Release-APK tatsächlich gebaut und geprüft.**
Paket `de.boyka.kallebuddy`, Version `3.0.1`, versionCode **30003** (3.0: 30001;
separat gesicherter Zwischenstand: 30002). Android minSdk 28, targetSdk 35.

## Ergebnis und Umfang

- 28 automatisierte Unit-/Android-Frameworktests bestanden, 0 Fehler im
  abschließenden vollständigen Lauf. Robolectric 4.14.1, Android API 35,
  native Grafikdarstellung. Das sind **keine Emulator-/Gerätetests**.
- Nach letzter Änderung am Einstellungsbildschirm die beiden betroffenen
  Editor-/Seitenrender-Tests erneut ausgeführt: beide bestanden.
- Gradle 8.9 / AGP 8.7.3 / JDK 21: `testDebugUnitTest assembleRelease`
  erfolgreich; finaler gezielter UI-Test plus Release-Build ebenfalls erfolgreich.
  `lintVitalRelease`: „No issues found“. Vollständiger Lint-Scan nicht ausgeführt.
- APK mit dem externen 3.0-PKCS12-Schlüssel signiert; `apksigner verify` bestanden
  (v3), Zipalign-Prüfung bestanden. Zertifikat exakt gleich zur gelieferten 3.0:
  `867d34ed80f46a07a49febaccc0aa7d3ea99517bf85c9fe13bdaee1c20256bb2`.
- Paketkennung, erhöhte Version und kompiliertes 4×4-Provider-Metadatum geprüft.
  Keine Kennung `de.boyka.kalle`, kein Mikrofon-, Internet-, Accessibility-,
  Vollbild-, Overlay-, Nutzungszugriffs- oder Foreground-Service-Recht.
- APK und Quellcode vor den längeren Tests separat als Zwischenstand gesichert.
  Die fertige 3.0-Basis wurde unverändert zurückgeholt und per SHA-256 abgeglichen.

## Implementierung

Echtes natives 4×4-Widget, horizontal bewegte Einzelbildfolgen mit Pausen und
Wenden, vorhandene 24 Vektorzustände, 264 eindeutige Standardsprüche, Outfits,
Stimmung/Energie und Reaktionen. Native ViewFlipper-Layouts mit 900/1500/3000 ms,
16 Bilder à 256×160 RGB565, maximal 1.310.720 Bitmap-Bytes je bewegter Ansicht.
Kein Dienst und kein App-Timer für die Animation. Figur/Requisiten liegen im
begrenzten Bildbereich; Widget-Inhalte zusätzlich geclippt. Native Renderings
für 250, 320 und 440 dp angesehen. Lange Sprüche erhalten eine ausdrücklich
markierte Vorschau; vollständiger Text über direkten Dialog-Activity-Aufruf.

Widget-Aktionen: Szene wechseln, Pause/Fortsetzen/Aktivieren, Missionen öffnen,
Antippen, Aufwachen, schnelle Wiederholung im Dialog, virtuelle Spenden.
Die normale Launcher-Steuerung verschiebt das ganze Widget. Keine behauptete
freie Fingersteuerung der Figur innerhalb von RemoteViews.

Der globale Begleiter ist nicht mehr als Service registriert und kann keine
WindowManager-Fenster erzeugen. Vorheriger Schalter wird einmalig deaktiviert,
alte Begleiter-Benachrichtigung entfernt. Overlay-/Nutzungszugriffsberechtigung
wurde nach technischer Prüfung bewusst entfernt: Der gewählte Missionsweg
verwendet normale Heads-up-Benachrichtigungen und braucht diese Rechte nicht.

Missionen bleiben unabhängig vom Widget: gleicher Benachrichtigungskanal
`missions_3`, hohe Wichtigkeit, Titel, Kommentar, Starten / 30 Min aufschieben /
Erledigt. Pause/Fortsetzen für aktive Timer bleibt erhalten. Schließen durch
Wegwischen. Eigener Einstellungslink öffnet die Android-Kanaleinstellungen.
Kein erzwungener Activity-Start aus einem Alarm und kein Full-Screen-Intent.
Die sichtbare Heads-up-Darstellung kann Android/Samsung bzw. der Nutzer durch
Kanal-/Ton-/Pop-up-/Nicht-stören-Einstellungen verhindern; sie wird nicht erzwungen.

## Ausgeführte Einzeltests

| Test | Ergebnis |
|---|---|
| `longSpeechFitsAndFullTextSurvives` | Bestanden |
| `migrationKeepsMissionJsonAndSettingsAndNoService` | Bestanden |
| `headsUpActionsIndependentOfWidget` | Bestanden |
| `horizontalPosesStayInsideAndMemoryBounded` | Bestanden |
| `pauseDisableAndQuietHaveNoFlipper` | Bestanden |
| `everyExistingSceneCanRender` | Bestanden |
| `widgetActionsAndInteractionsPersist` | Bestanden |
| `nativeInflationResizeAndPlayback` | Bestanden |
| `horizontalMovementAndTurns` | Bestanden |
| `timerPauseResumeAndRestart` | Bestanden |
| `alarmReplacementHasOneIdentity` | Bestanden |
| `migrationAndNeedsAndQuiet` | Bestanden |
| `threeSnoozesExactlyNinety` | Bestanden |
| `storeIdempotentAndPersistentSnooze` | Bestanden |
| `notificationActionsStartCompleteAndSnooze` | Bestanden |
| `notificationDeniedAndBackup` | Bestanden |
| `statsUseOriginalCohort` | Bestanden |
| `normalizationAfterLongAbsenceIsOneStep` | Bestanden |
| `sharedPreferencesReloadFromDisk` | Bestanden |
| `timezoneDstAndYearBoundary` | Bestanden |
| `recurrenceIsUniqueAndIndependent` | Bestanden |
| `sleepTentDonationAndAnnoyance` | Bestanden |
| `renderEveryPoseAndPages` | Bestanden |
| `tenAndSixtyExternal` | Bestanden |
| `legacyAndCodec` | Bestanden |
| `speechCatalogFiltersAndHistory` | Bestanden |
| `actualEditorCreatesAndEdits` | Bestanden |
| `malformedSettingsImportCannotReplaceData` | Bestanden |

Die Tests senden echte vom Modell erzeugte PendingIntents im Android-Framework:
Starten, Erledigt und Aufschieben; doppelte Zustellung derselben Aktion zählt
nicht doppelt. Drei mal 30 Minuten ergeben exakt 90 Minuten. Alarmidentitäten,
Originalfälligkeit, individuelle Wiederholungsvorkommen, Tages-/Wochenquoten,
Dateipersistenz und Export-/Importvalidierung bleiben abgedeckt.
Widget- und Benachrichtigungsprüfungen laufen auch ohne gegenseitige Aktivierung.
Der native ViewFlipper wurde in einem sichtbaren Testfenster zeitlich fortgeschaltet.

Mission, MissionCodec, Store, Scheduler, MissionReceiver, Stats, WeeklyStats,
Needs, DialogSystem, CoachView, KalleScene und RoamPath sind gegenüber 3.0
bytegleich. Widgetzustand verwendet einen eigenen Preferences-Bereich;
Missions-JSON und Statistikdaten werden nicht migriert oder neu angelegt.
Die neue Hauptschalter-Einstellung ist in der Backup-Typprüfung berücksichtigt.
Der bestehende Import ersetzt weiterhin bewusst den Datenbestand und lässt die
Figur zunächst deaktiviert; die normale Updateinstallation benötigt keinen Import.

## Fehlgeschlagene Zwischenprüfungen und Korrektur

Nach dem Umgebungsreset fehlte der Java-Compiler; außerdem verlangte AGP zunächst
nicht installierte Build Tools 34. JDK 21 und Build Tools 35 wurden eingerichtet
und die Projektversion explizit auf 35 festgelegt. Danach Builds erfolgreich.
Im ersten vollständigen Testlauf: 26/28 bestanden. Zwei neue Testfehler wurden
korrigiert: eine ungültige Testmission ohne Dauer und ein ViewFlipper ohne
sichtbares Hostfenster. Anschließend 8/8 Widgettests und 28/28 Gesamttests
bestanden. Keine offenen automatisierten Testfehler.
Der bisherige Test der Overlay-Launcher-Erkennung entfällt, weil diese
Architektur entfernt ist; die anderen 20 bisherigen Tests bleiben erhalten.

## Grenzen und ausdrücklich offene Gerätetests

| Anforderung | Nachweis / offen |
|---|---|
| Widget hinzufügen und auf Seite platzieren/verschieben/vergrößern | Native Registrierung/Ansichten geprüft; echte One-UI-Platzierung **offen** |
| Kalle nur im Widget, kein zweiter globaler Kalle | Kein registrierter Fensterdienst und keine Overlay-Rechte; echter Seitenwechsel **offen** |
| Grenzen, horizontales Laufen, Wenden, Schlaf-/weitere Szenen | Geometrie, beide Richtungen, 24 native Renderings getestet; echte Launcher-Wiedergabe **offen** |
| Sprechblase, Tippen, Schlafen, Spenden | Frameworktests und Renderings bestanden; Samsung-Bedienung **offen** |
| Icons außerhalb des Widgets und normale Navigation | Ausschließlich native Widgetfläche; reale Touch-/Swipe-Prüfung **offen** |
| Missionen über YouTube/WhatsApp/Browser | Kanal und Aktionen geprüft; tatsächliche Heads-up-Sichtbarkeit **offen** |
| Aufschieben, keine doppelten Alarme | Automatisierte Regressionen bestanden |
| Daten nach Update erhalten | Gleiches Paket/Zertifikat und unveränderte Datenhaltung geprüft; echte APK-Updateinstallation **offen** |
| Akku, Display-Aus, unsichtbare Nachbarseiten | Keine App-Hintergrundschleife/Widget-Alarme; native niedrige Bildrate. Echte Messung und One-UI-Lifecycle **offen** |
| APK/Signatur | Erfolgreich tatsächlich ausgeführt |

Kein verbundenes Samsung-/Android-Gerät und kein `/dev/kvm` vorhanden. Deshalb
kein langsamer Emulator gestartet und keine ADB-Installation behauptet.
Der Launcher steuert das Anhalten unsichtbarer ViewFlipper; Nachbarseiten können
je nach Host im Speicher sichtbar bleiben. Keine absolute Nullverbrauchszusage.
System-Inhaltsupdates frühestens alle 30 Minuten, eventuell später. Ruhezeitgrenzen
werden beim nächsten Update berücksichtigt. Die bisherigen Sekundenwerte für
Spruchdauer/-häufigkeit bleiben gespeichert, laufen im Widget aber nicht als
Timer weiter; die Regler werden deshalb hier nicht angeboten. Sprüche bleiben
bis zum nächsten Ereignis sichtbar. Dies ist die dokumentierte Reduzierung der
alten flüssigen Overlay-Animation.

## Technische Grundlagen

- [RemoteViews: unterstützte Ansichten einschließlich ViewFlipper](https://developer.android.com/reference/android/widget/RemoteViews)
- [Widget-Aktualisierung und 30-Minuten-Mindestintervall](https://developer.android.com/develop/ui/views/appwidgets/advanced)
- [Android-15-Beschränkung: Overlay-Recht allein erlaubt keinen beliebigen FGS-Start](https://developer.android.com/about/versions/15/behavior-changes-15)
- [High-Importance-Kanäle und systemgesteuerte Heads-up-Anzeige](https://developer.android.com/develop/ui/compose/notifications)

Logs, Test-XML, Zertifikatsvergleich, kompiliertes Widget-Metadatum und native
Widget-Renderings befinden sich im Quellprojekt unter `qa-3.0.1/`.
Private Schlüssel und Passwörter sind nicht Bestandteil des Quellarchivs.
