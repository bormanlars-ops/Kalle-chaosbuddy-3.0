# Änderungen gegenüber 3.0.3

- Lokal gesteuerte Tagesphasen mit ruhigen Aktionsfolgen und Pausen.
- Seltene Ereignisse mit achtstündiger Sperrfrist.
- 20 natürliche Alltagstexte plus objektbezogene Kommentare statt häufiger Motivationsparolen.
- Visuelle Reaktion auf tatsächliche Missionsabschlüsse, Serien und anstehende/fällige Aufgaben.
- Offline-Textbefehle mit strenger Datums-/Uhrzeitprüfung und ausdrücklichem Bestätigen/Bearbeiten/Abbrechen.
- Dezente Lichtstimmung über unverändertem Originalhintergrund; Nacht-/Energiespar-Drosselung.
- Widget-Status als anklickbarer Einstieg in Kalles Zustand.
- Unveränderte Daten-/Alarmformate und Paketkennung, versionCode 30100, versionName 3.1.0.

**Status:** Quellcode-Entwicklungsstand. Kein bestätigter Android-Build, keine signierte APK; siehe TESTREPORT-3.1.0.md.
