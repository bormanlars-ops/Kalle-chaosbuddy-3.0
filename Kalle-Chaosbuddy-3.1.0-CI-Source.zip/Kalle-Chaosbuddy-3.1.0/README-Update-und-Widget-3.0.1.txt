KALLE – CHAOSBUDDY 3.0.1
Update und 4×4-Revier

1. UPDATE
Die APK über die vorhandene Chaosbuddy-3.0-App installieren, NICHT vorher
   deinstallieren. Paket de.boyka.kallebuddy, gleicher Signierschlüssel wie die
   hier zuvor gelieferte 3.0 (versionCode 30001). Neue Version: 3.0.1 / 30003.
   Auch der Zwischenstand 30002 lässt sich damit aktualisieren.
   Missionen, Statistiken und Einstellungen bleiben im selben App-Speicher.
   Für eine zusätzliche eigene Sicherung gibt es weiterhin den Datenexport.
   Kalle Missionschaot 1.0 (de.boyka.kalle) wird nicht ersetzt.
   Bei einer Signaturkonflikt-Meldung nicht zur Konfliktlösung deinstallieren:
   Diese APK passt zum hier gelieferten 3.0-Zertifikat, nicht zu beliebigen
   anders signierten APKs. Auf dem echten Gerät wurde das Update nicht getestet.

2. WIDGET AUF DER GEWÜNSCHTEN SEITE PLATZIEREN
   Nach dem Update Kalle einmal öffnen. Der alte globale Begleiter wird
   abgeschaltet und kann in dieser Version keine Overlay-Fenster mehr öffnen.
   Auf die gewünschte Homescreen-Seite wechseln, freie Fläche lange drücken,
   Widgets wählen und „Kalle – Chaosbuddy 3.0.1“ als 4×4-Revier hinzufügen.
   Alternativ in Kalle „KALLES 4×4-REVIER HINZUFÜGEN“ verwenden.
   Nur ein Widget platzieren, wenn Kalle auf genau einer Seite wohnen soll.
   Das ganze Widget wie jedes andere Samsung-Widget lange drücken, verschieben
   und gegebenenfalls an den angebotenen Griffen vergrößern.
   Die tatsächliche Zellgröße bestimmt der Launcher. 4×4 ist die Standardvorgabe.
   Ein altes 4×2-Steuerwidget gegebenenfalls vom Homescreen entfernen und neu
   hinzufügen. Das Entfernen eines Widgets löscht keine Missionen.

3. BEDIENUNG
   Figur antippen: kleines App-Fenster mit Reaktion, Schlaf-/Aufwachreaktion.
   Figur im Reaktionsfenster mehrfach schnell antippen: Kalle wird genervt.
   Sprechblase antippen: vollständigen Text lesen. Lange Texte werden im Widget
   ausdrücklich als Vorschau mit „… Tippen“ angezeigt.
   SZENE: nächste der vorhandenen 24 Vektorszenen.
   PAUSE / WEITER: Widget-Animation anhalten bzw. fortsetzen.
   MISSIONEN: Missionen öffnen. Virtuelle Spenden in der passenden Szene über
   das Reaktionsfenster; keine echte Zahlung.
   Kalles Bude: Größe, Schrift, Kleidung, Bewegungsbereich, Grundlinie, Tempo,
   Stimmung/Humorfilter, Ruhezeiten und Energiesparmodus bleiben nutzbar.
   Vollständig deaktivieren blendet die Figur im Revier aus. Das Revier selbst
   kann über den Launcher entfernt werden. Missionen bleiben unabhängig aktiv.

4. MISSIONS-POPUPS ÜBER ANDEREN APPS
   Benachrichtigungen erlauben. In Kalles Bude „MISSIONEN ALS POP-UP“ öffnen
   und im Android-Kanal Missionserinnerungen Pop-up/Ton/Vibration zulassen.
   „Nicht stören“, stummgeschaltete Kategorien, verweigerte Benachrichtigungen
   oder Samsung-Einstellungen können die Pop-up-Darstellung unterdrücken.
   Eine fällige Mission wird über den bestehenden Kanal mit hoher Wichtigkeit
   als Android-Heads-up angefordert, auch ohne Widget und in anderen Apps.
   Aktionen: Starten, 30 Min aufschieben, Erledigt. Bei laufenden Timern steht
   anstelle von Starten Pause/Fortsetzen zur Verfügung. Die Meldung lässt sich
   wegwischen; dadurch wird die Mission nicht erledigt. Die Meldung bei Bedarf
   aufklappen, um Text und Aktionen zu sehen; Antippen öffnet die Mission.
   Der 30-Minuten-Knopf ist fest; der gespeicherte Standard für Aufschieben
   bleibt für die Missionseingabe/-ansicht erhalten.
   „Genaue Erinnerungen“ erlauben, wenn pünktliche Weckalarme gewünscht sind.
   Keine erzwungenen Vollbild-Intents, keine Accessibility-Lösung, kein
   Missions-Overlay. Die Overlay-Berechtigung wird für Heads-up nicht benötigt.
   Android entscheidet über tatsächliche Pop-up-Größe und Anzeigedauer.

5. BEWUSSTE WIDGET-GRENZEN
   Keine flüssige 24-fps-Figur: 16 vorbereitete Einzelbilder in einem nativen
   ViewFlipper (0,9 / 1,5 / 3 Sekunden je Bild; Energiesparen 3 Sekunden).
   Laufen bewegt die Figur horizontal, mit Pausen und sichtbarem Umdrehen.
   Andere Szenen zeigen reduzierte Körper-/Requisitenbewegungen. Alles bleibt
   im Bildbereich. Keine freie Drag-Steuerung der Figur innerhalb des Widgets.
   System-Updates für neue Szenen/Sprüche frühestens alle 30 Minuten und bei
   Ereignissen wie Antippen, Einstellungsänderung oder Missionen. Android kann
   automatische Updates verzögern. Keine eigenen periodischen Widget-Alarme,
   kein dauernder Begleitdienst und keine App-Hintergrundschleife.
   Der Launcher steuert die Sichtbarkeit und das native Abspielen. Display-Aus
   wird vom ViewFlipper behandelt; das Aussetzen auf unsichtbaren Nachbarseiten
   hängt zusätzlich vom Launcher ab und wurde auf One UI nicht gemessen.
   PAUSE, deaktivierte Animationen und Ruhezeit erzeugen eine statische Ansicht.
   Grenzen von Ruhezeiten wirken beim nächsten Update, eventuell verzögert.
   Die bisherigen Werte für Spruchdauer und kurze Spruchintervalle bleiben
   gespeichert, sind im Widget aber nicht als Sekunden-Timer anwendbar. Sprüche
   bleiben bis zum nächsten Textwechsel sichtbar. Ihre früheren Regler werden
   deshalb im Widget-Modus nicht als funktionsfähige Timer angeboten.

Build/Signatur und automatisierte Android-Frameworktests: siehe TESTREPORT.
Echte Samsung-S22-Ultra-/One-UI-Gerätetests sind ausdrücklich noch offen.
