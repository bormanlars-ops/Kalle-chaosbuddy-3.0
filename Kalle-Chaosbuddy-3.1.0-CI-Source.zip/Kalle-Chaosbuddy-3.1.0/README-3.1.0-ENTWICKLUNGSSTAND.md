# Kalle – Chaosbuddy 3.1.0 – Entwicklungsstand (kein freigegebenes Release)

Quellbasis: Kalle-Chaosbuddy-3.0.3-Source.zip. Anwendungs-ID und Provider bleiben identisch; die getrennte ursprüngliche App `de.boyka.kalle` wurde nicht verändert.

## Neu implementierter Code

- `LivingWorldBrain.java`: lokale Tagesphasen 06–10, 10–18, 18–23, 23–06; passende Aktionsauswahl, Energie- und Stimmungsgewichtung, Reaktion auf bevorstehende und tatsächlich überfällige Missionen. Fünf seltene Ereignisse mit mindestens acht Stunden Abstand.
- `WidgetStory.java`: nutzt diese Entscheidungslogik im vorhandenen, zustandsbasierten Widget-Programm; Ereignisse werden im bestehenden per-Widget-Speicher abgelegt. Kein permanenter Hintergrundprozess.
- `WorldAssets.java`, `WorldViews.java`: bestehendes Gassenbild bleibt erhalten; dezente Tageszeit-Lichtfilter, keine neuen Hintergrunddateien. Bereits getrennte Requisiten und perspektivische Bewegungen aus 3.0.3 bleiben erhalten.
- `WorldSpeech.java`: 20 neue trockene Alltagssätze sowie ortsspezifische Formulierungen für Zelt/Feuer/Zeitung. Mehrheit der Ambient-Texte stammen aus dieser Sammlung statt aus pauschalen Motivationssprüchen; fällige Missionen behalten Vorrang.
- `LivingWorldReactions.java`, `Store.java`: optische/textliche Reaktionen auf wirklich abgeschlossene oder abgebrochene Missionen, ohne Änderung des Abschluss- und Punktesystems.
- `MissionCommandParser.java`, `MainActivity.java`: rein lokaler, bewusst restriktiver deutscher Textparser, Vorschau mit Bestätigen/Bearbeiten/Abbrechen. Erst die ausdrückliche Bestätigung speichert über bestehende Store-/Scheduler-Routinen. Zeitumstellungen und doppelte Zeitangaben werden abgefangen.
- `KalleWidget.java`: Widget-Status öffnet die vorhandene Interaktionsansicht; nachts und im Energiesparmodus statische statt permanenter Flipperbewegungen.
- Versionsnummer: Manifest, Gradle, App-Titel und Buildskript auf 3.1.0 / 30100 geändert.

## Verifiziert

- Standalone-Java-Tests: **238 Assertions erfolgreich**, einschließlich deutscher Datum-/Uhrzeitmuster, DST-Lücke, Mehrdeutigkeiten, deterministischer Tagesroutinen und Missionsreaktionen.
- Java-Syntaxprüfung: **36 Java-Quelldateien ohne Syntaxfehler geparst**.
- Ressourcenprüfung: **26 XML-Dateien wohlgeformt**.
- 7 geschützte Dateien (Missionsmodell, Missionscodec, Scheduler, Alarmdienst, Backup, Popupdienst, Gassenhintergrund) byteidentisch zur Basis 3.0.3.

## Nicht nachgewiesen / noch offen

**Dies ist ein Entwicklungsstand, keine fertige Release-APK.** Ein echter Android-Build wurde versucht, scheiterte aber schon am fehlenden Gradle-8.9-Download: `java.net.UnknownHostException: services.gradle.org`. Hier fehlen Android SDK Platform 35 / Build Tools 35.0.0 und eine nutzbare Gradle-Distribution, Netzwerkzugang ist gesperrt. Der ursprüngliche private Release-Signierschlüssel ist nicht Teil dieses Quellarchivs. Daher wurde keine Release-APK erstellt oder signiert. Android-Kompilierung, Android-Unit-/Instrumentationstests, Samsung-Launcher-Interaktion, Batterieverbrauch und Installationskompatibilität **konnten nicht geprüft werden**.

UI-Verbesserungen beschränken sich auf den Mission-Command und die Versionszeile. Nicht realisiert: neue hochauflösende Sprite-Animationen, weitere physikalische Effekte, ein dauerhaftes Geschichten-Gedächtnis oder zusätzliche ungetestete Widget-APIs. Die vorhandenen 3.0.3-Assets bleiben erhalten. Die Screenshot-/Hardware-Abnahme ist zwingend.

## Release herstellen

In einer Android-Entwicklungsumgebung mit SDK 35 und Gradle 8.9 zuerst `./gradlew testDebugUnitTest assembleDebug` ausführen. Kompilierungs- und Laufzeitprobleme beheben und anschließend auf dem Samsung Galaxy S22 Ultra testen. Ein kompatibles Release muss danach mit **dem bisherigen privaten Original-Schlüssel** signiert werden; keinen neuen Schlüssel erzeugen, wenn ein Upgrade mit erhaltenen Nutzerdaten gewünscht ist. Das mitgelieferte `build-local.sh` verwendet `KALLE_KEYSTORE` und `KALLE_STOREPASS` und erzeugt bei korrekter Umgebung die 3.1.0-APK. Den Schlüssel und sein Passwort nicht zum Quellcode packen.
