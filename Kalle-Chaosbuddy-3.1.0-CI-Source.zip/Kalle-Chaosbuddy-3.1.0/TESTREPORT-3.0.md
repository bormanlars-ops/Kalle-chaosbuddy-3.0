# TESTREPORT – Kalle Chaosbuddy 3.0.0

Stand: 06.11.2026. Finale applicationId **de.boyka.kallebuddy**, versionCode
**30001**, min API 28, target/compile API 35.

## Ergebnis und Grenzen

**Eine echte signierte APK wurde erzeugt.** Manueller Android-Build, Gradle-Build,
APK-Signatur, Zipalign und Archivprüfung sind erfolgreich. **21 automatisierte
Tests bestanden, 0 Fehler, 0 übersprungen.** Die Tests laufen mit Robolectric
4.14.1 / Android-API-35-Framework auf Linux und JDK 21, mit nativer Skia-Grafik.
Sie sind keine Samsung- oder Android-Emulator-Gerätetests.

Per ADB ist kein Gerät verbunden. In dieser Fortsetzung wurden keine weiteren
langen Emulatorstarts versucht: Hardwarebeschleunigung /dev/kvm fehlt, und die
vorherigen Versuche hatten Android-Systemserver-Zeitüberschreitungen. Es wird
keine bestandene echte Installation oder One-UI-Prüfung behauptet.

## Wiederherstellung und Signatur

Der vorherige temporäre Ordner war nach der Unterbrechung leer. Die frühere
Test-APK und ihr temporärer Schlüssel waren nicht mehr vorhanden. Der Stand wurde
anhand der dokumentierten 3.0-Änderungen auf der richtigen Chaosbuddy-2.0-Basis
wiederhergestellt. Er ist keine behauptete byteidentische Kopie des verlorenen
Arbeitsordners. Neue APK, Quellstand, Schlüssel und Zugang wurden frühzeitig
separat dauerhaft gesichert; Build 01 bleibt unverändert erhalten.

Die Original-ZIP bleibt unter backup unverändert erhalten (SHA-256
7ac3224f686d9887fc523a165109746277b4c15dc00c0f3e240c3af61f4c49ab).
Bekannte Ausgangsfehler – fehlende Widget-Textressource und doppelte lokale Variable
in CoachView – sind behoben. Die Ausgangsversion wurde hier nicht unnötig erneut
als unveränderter Build analysiert.

Build 01 (30000) und finale APK (30001) haben dasselbe neue Zertifikat. Das wurde
mit apksigner verglichen. Eine direkte Aktualisierung dieses Build 01 ist damit
vorgesehen; die echte Geräteinstallation wurde nicht durchgeführt. Der originale
2.0-Schlüssel lag nicht vor. Ein Update einer anders signierten Original-2.0-
Installation kann nicht zugesichert werden. Nicht zur Konfliktlösung ungesichert
deinstallieren. Die getrennte Missionschaot-App de.boyka.kalle wird nicht ersetzt.

## Ausgeführte Prüfungen

| Test | Ergebnis |
|---|---|
| horizontalMovementAndTurns | Bestanden |
| timerPauseResumeAndRestart | Bestanden |
| alarmReplacementHasOneIdentity | Bestanden |
| migrationAndNeedsAndQuiet | Bestanden |
| threeSnoozesExactlyNinety | Bestanden |
| storeIdempotentAndPersistentSnooze | Bestanden |
| modeledHomeGateAndLauncherBounds | Bestanden |
| notificationActionsStartCompleteAndSnooze | Bestanden |
| notificationDeniedAndBackup | Bestanden |
| statsUseOriginalCohort | Bestanden |
| normalizationAfterLongAbsenceIsOneStep | Bestanden |
| sharedPreferencesReloadFromDisk | Bestanden |
| timezoneDstAndYearBoundary | Bestanden |
| recurrenceIsUniqueAndIndependent | Bestanden |
| sleepTentDonationAndAnnoyance | Bestanden |
| renderEveryPoseAndPages | Bestanden |
| tenAndSixtyExternal | Bestanden |
| legacyAndCodec | Bestanden |
| speechCatalogFiltersAndHistory | Bestanden |
| actualEditorCreatesAndEdits | Bestanden |
| malformedSettingsImportCannotReplaceData | Bestanden |

Die Notification-Tests senden die erzeugten PendingIntents im Frameworkmodell:
Starten → aktiv, Erledigt → gespeichert, 30 Minuten Aufschieben → neue Erinnerung.
Eine erneute Zustellung derselben Aktion zählt nicht doppelt. Drei mal 30 Minuten
sind exakt 90 Minuten; Originaltermin und individuelle Wiederholungen bleiben
getrennt. Alarmidentitäten werden ersetzt und nicht vervielfacht.

SharedPreferences-XML wurde erzeugt, der Frameworkcache geleert und die Daten
über einen neuen Package-Context erneut von der Datei gelesen. Das prüft
Dateipersistenz; ein echter Prozess-/Handy-Neustart wurde nicht ausgeführt.
Legacy-JSON aus 2.0 wurde gelesen und mit neuen Feldern verlustfrei weitergeführt.
Das ersetzt keine echte APK-Updateinstallation mit dem unbekannten Originalschlüssel.

Der modellierte Launcher-Test prüft Vordergrundereignisse, fremde App, Display-Aus-
Bedingung, begrenzte Fenster sowie NOT_FOCUSABLE/NOT_TOUCH_MODAL. Die tatsächliche
Touchweiterleitung und Erkennung unter One UI wurden nicht getestet.

Die Bewegungssimulation prüft 15.000 Schritte auf feste Höhe, Grenzen, beide
Richtungen und Wenden. Dies ist kein Akku-/FPS-Benchmark.

## Funktionen und Abnahme

| Bereich | Stand |
|---|---|
| Echte APK / Signatur / Paket / Version / Zipalign | Geprüft, bestanden |
| Alte Missionschaot-App unverändert | Separate Kennung; keine Änderungen oder Geräteaktionen dagegen |
| Spracheingabe | Keine Sprach-API, kein RECORD_AUDIO-Recht, keine Sprachbuttons |
| Figuren-/Sprechblasenzeichnung | Native Renderings geprüft; Schlaf-/Sitz-Clipping korrigiert |
| Mindestens 20 Animationen | 24 benannte Vektorzustände und 24 verschiedene native Posen gerendert; zeitabhängige Körper-/Requisitenbewegungen |
| Mindestens 200 Sprüche | 264 eindeutige Standardsprüche, acht Kategorien, Humor-/Vulgaritätsfilter und Verlauf getestet |
| Schlafen / Zelt / virtuelle Spenden | Bestehende Szenen erhalten, Zustandsübergänge und virtuelle Spenden getestet; kein echtes Geld |
| Stimmung / Energie | 0–100, persistente Normalisierung; beeinflussen Tempo, Posen und Spruchwahl |
| Mission erstellen / bearbeiten / löschen | Editor und Speicherlogik getestet |
| Start / Pause / Fortsetzen / Erledigt / Abbruch | Modell-/Frameworktests bestanden |
| Aufschieben 10 / 30 / 60 | Getestet; Revision und Ereignistoken verhindern doppelte Erfassung |
| Tages-/Wochenquote und Verlauf | Originaler Fälligkeitstag, eindeutige Vorkommen, leere Daten korrekt |
| Jahresübersicht | Erhaltene echte Datenansicht, keine Zufallswerte |
| Einstellungen | Im Code verbunden, Speicherung und wesentliche Auswirkungen getestet; vollständige One-UI-Bedienmatrix offen |
| Datenimport/-export | Roundtrip und Ablehnung fehlerhafter Einstellungen getestet; JSON enthält private Texte |
| Homescreen / Launcher-Bedienbarkeit | Frameworkmodell bestanden; echte One-UI-/Schubladen-/Recents-Prüfung offen |
| Benachrichtigungen bei Gerätesperre / Doze | Nicht geräteseitig getestet |
| App-/Handyneustart | Dateireload getestet; echter Prozess-/Geräteneustart offen |
| Akkuverbrauch | Framebegrenzung und Display-Aus-Stopp implementiert; kein Langzeitmesswert |
| Automatischer Sonntagsbericht | Nicht implementiert; im ursprünglichen Auftrag ausdrücklich Update 3.3 zugeordnet |

## Korrigierte Befunde

- Originaltermin und Erinnerung getrennt; kein automatischer Timerstart bei Erinnerung.
- Doppelte Aktionen durch erwartete Revision und gespeicherten Token abgefangen.
- Neu erzeugte Wiederholungen werden auch sofort als Systemalarme eingeplant.
- Wochenansicht öffnet konkrete Vorkommen des ausgewählten Tages.
- Persönliches Tagesziel verändert nicht die Quote erledigt/geplant.
- Lange Abwesenheit normalisiert Stimmung/Energie ohne wiederholtes Nachschreiben.
- Schlafpose und Sitztasche innerhalb der Zeichenfläche; Seitenrandreserve ergänzt.
- Fehlerhafte Sicherungseinstellungen werden vor Ersetzung vorhandener Daten abgelehnt.

Bei der Testeinrichtung gab es zuerst eine nicht mehr gültige Proxy-Adresse und
anschließend eine fehlende AndroidX-Testkonfiguration. Diese Setupfehler wurden
behoben. Ein ServiceController-Fehler im Testaufbau wurde ebenfalls korrigiert.
Die abschließende Suite ist vollständig erfolgreich; fehlgeschlagene Setupversuche
werden nicht als bestandene App-Tests gezählt.

## Noch auf dem S22 Ultra prüfen

Installation/Update, Originalzertifikat, echte Notification-Aktionen, Homescreen-
Appwechsel, Schublade/Recents, Berührbarkeit von Icons, Sperren/Entsperren,
Neustart, Doze, Samsung-Akkuregeln und große Systemschrift. Unterschiedliche
Launcher, DeX und Split-Screen sind nicht freigegeben/geprüft.

## Prüfsummen

APK SHA-256: `717af509c4404236c52f0a6017b774967b53e93fa5a480fb878d25c55237bfa5`

Zertifikat SHA-256: `867d34ed80f46a07a49febaccc0aa7d3ea99517bf85c9fe13bdaee1c20256bb2`

Rohbelege im Quellprojekt unter qa: Gradle-/Build-/Signaturlogs, JUnit-XML,
Zertifikatsvergleich und native Bilder. Keine privaten Schlüssel im Source-ZIP.
