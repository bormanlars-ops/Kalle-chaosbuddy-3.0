# TESTREPORT – Kalle Chaosbuddy 3.0.2

Stand: 07.11.2026. **Release-APK tatsächlich gebaut, signiert und geprüft.**
Paket `de.boyka.kallebuddy`, versionName `3.0.2`, versionCode **30005**.
3.0.1 hatte 30003, der separat gesicherte 3.0.2-Zwischenstand hat 30004.

## Ergebnis

**36 unterschiedliche automatisierte Tests erfolgreich.** Zuerst vollständiger
Lauf mit 34 Tests bestanden. Nach Optimierung der Wiedergabe und Sitzpose
gezielt die betroffenen Widget-/Grafik-/Missionsfensterprüfungen ausgeführt:
17 Tests, davon 16 sofort erfolgreich; die zu strenge Zeitannahme eines neuen
Tests korrigiert und diesen einzeln erfolgreich wiederholt. Die unveränderten
Missionsberechnungen wurden nicht grundlos erneut durchgetestet.
Nachweise je Test und Ausführungsrunde: `qa-3.0.2/test-summary.json` und die
echten Test-XML. Kein erfundener abschließender Komplettlauf mit 36 Tests.

Gradle 8.9 / AGP 8.7.3 / JDK 21 / Build Tools 35.0.0. Gezielte Unit-/Frameworktests
und `assembleRelease` erfolgreich. `lintVitalRelease`: „No issues found“;
kein vollständiger zusätzlicher Lint-Scan. Robolectric 4.14.1, Android API 35,
native Grafik. **Dies sind keine Emulator- oder Samsung-Gerätetests.**

`apksigner verify` und Zipalign erfolgreich. Gleicher Zertifikatsfingerabdruck
wie die ausgelieferte 3.0.1:
`867d34ed80f46a07a49febaccc0aa7d3ea99517bf85c9fe13bdaee1c20256bb2`.
Paket, erhöhte Versionsnummer und kompiliertes 4×4-Widget-Metadatum geprüft.
Kein Internet-, Mikrofon-, Nutzungsstatistik-, Accessibility- oder Vollbildrecht.
Neu wieder vorhanden: Overlay und Foreground-Service, ausschließlich für das
optionale, kurzzeitige Missionsfenster. Alter globaler Begleiter bleibt
unregistriert. Die separate Missionschaot-App `de.boyka.kalle` wird nicht ersetzt.

## Gezielte Änderungen

- Figurberührung ist ein expliziter immutable Broadcast-PendingIntent. Direkte
  Sprach-/Posenreaktion im Widget; Frameworktest prüft, dass keine Activity
  gestartet wird. Tatsächlich sichtbare Schlafpose wird als Aktionsparameter
  übergeben. Schnelle Wiederholung nervt Kalle. Virtuelle Pfandspende bleibt
  ohne echte Zahlung direkt im Widget möglich.
- Ein einzelner nativer ViewFlipper spielt die vorbereitete automatische
  Szenenfolge: acht Abschnitte, vier unterschiedliche Aktivitäten, keine
  benachbarten/Schleifenrand-Wiederholungen. Auswahl nach Uhrzeit, Stimmung,
  Energie und letzten Reaktionen; gespeichertes Programm bleibt bis zum
  nächsten relevanten Inhaltsupdate erhalten. Die Folge wiederholt sich;
  kein unbegrenzter Zufallsgenerator während einer unveränderten Ansicht.
- 256 native Bildplätze, Bitmaps wiederverwendet. Konfiguriert: 100/125/200 ms,
  also **nominell 10/8/5 Bilder pro Sekunde**. Normale Szene 4 Sekunden, normales
  Programm 32 Sekunden. Im kontrollierten 1-Sekunden-Frameworkfenster wurden
  7 Fortschaltungen beobachtet; UI-Planung ist nicht millisekundengenau.
  **Reale Samsung-FPS sind nicht gemessen.**
- Geprüfter RemoteViews-Bitmapcache: **7.380.480 Bytes** bei einem Android-Limit
  von 8.788.824 Bytes im Testprofil 411×891 dp/xhdpi. Adaptive Bitmapauflösung,
  Cache für vier Szenensätze. Genau ein nativer Taktgeber; keine App-Ticks,
  zusätzlichen Widget-Alarme oder Widget-Foreground-Services. Native
  Fenstersichtbarkeit pausiert die Wiedergabe im Frameworktest. Echter
  Launcher-Lifecycle/Display-Aus und Akkuverbrauch bleiben Gerätetests.
- Einheitliche Skalierung der ganzen Figur und Randreserve. Normale Arme bei
  Gähnen/Rauchen/gekreuzten Armen ausgespart; keine Pose-Crossfade-Doppelkonturen.
  Sitzposition angehoben, damit Beine sichtbar bleiben. Alle 24 Zustände als
  native Posenübersicht gerendert und visuell angesehen; Widgetgrößen 250,
  320 und 440 dp ebenfalls geprüft. Keine komplette Neugestaltung.
- Missionsfenster als nicht exportierter `shortService`, höchstens 40 Sekunden,
  begrenzte Overlay-Fläche statt Vollbild. Große Überschrift, Kommentar,
  Starten / 30 Minuten / Erledigt / Schließen. Nur bei erlaubtem Overlay,
  eingeschaltetem/entsperrtem Display und aktivierten Erinnerungen.
  Display-Aus, Aktionen, Schließen und Zeitlimit entfernen das Fenster.
- Sound über den bestehenden High-Importance-Kanal `missions_3`, explizite
  Standard-Benachrichtigungs-URI und Audioattribute für neue Kanalanlage.
  Vorhandene stumme/gesperrte Nutzer-Kanaleinstellungen werden respektiert.
  Diagnose und echte Testbenachrichtigung ohne gespeicherte Demo-Mission.
  Tatsächlich hörbarer Ton wurde mangels Gerät nicht geprüft.
- Wenn Android den Hintergrunddienst oder das Overlay ablehnt, bleibt die
  zuvor gesendete Benachrichtigung mit Aktionen erhalten. Ablehnung im
  Frameworkmodell simuliert und geprüft. Keine Full-Screen-Intents oder
  Sicherheitsumgehungen. Das Modell belegt keine tatsächliche One-UI-Freigabe.

## Ausgeführte Tests

| Test | Ergebnis nach gegebenenfalls gezielter Wiederholung |
|---|---|
| `actualEditorCreatesAndEdits` | Bestanden |
| `alarmReplacementHasOneIdentity` | Bestanden |
| `horizontalMovementAndTurns` | Bestanden |
| `legacyAndCodec` | Bestanden |
| `malformedSettingsImportCannotReplaceData` | Bestanden |
| `migrationAndNeedsAndQuiet` | Bestanden |
| `normalizationAfterLongAbsenceIsOneStep` | Bestanden |
| `notificationActionsStartCompleteAndSnooze` | Bestanden |
| `notificationDeniedAndBackup` | Bestanden |
| `recurrenceIsUniqueAndIndependent` | Bestanden |
| `renderEveryPoseAndPages` | Bestanden |
| `sharedPreferencesReloadFromDisk` | Bestanden |
| `sleepTentDonationAndAnnoyance` | Bestanden |
| `speechCatalogFiltersAndHistory` | Bestanden |
| `statsUseOriginalCohort` | Bestanden |
| `storeIdempotentAndPersistentSnooze` | Bestanden |
| `tenAndSixtyExternal` | Bestanden |
| `threeSnoozesExactlyNinety` | Bestanden |
| `timerPauseResumeAndRestart` | Bestanden |
| `timezoneDstAndYearBoundary` | Bestanden |
| `automaticHostScenesAndDirectTapNoActivity` | Bestanden |
| `deniedOverlayAndRejectedServiceKeepAudibleNotification` | Bestanden |
| `existingSilentChannelIsDiagnosedNotOverridden` | Bestanden |
| `missionWindowActionsAndFortySecondLimit` | Bestanden |
| `oneNativeClockPausesWithHostWindow` | Bestanden |
| `popupStartAndDoneUseExistingActions` | Bestanden |
| `sceneProgramDependsOnNeedsAndAvoidsRepeats` | Bestanden |
| `uniformFitAndPoseReviewSheet` | Bestanden |
| `everyExistingSceneCanRender` | Bestanden |
| `headsUpActionsIndependentOfWidget` | Bestanden |
| `horizontalPosesStayInsideAndMemoryBounded` | Bestanden |
| `longSpeechFitsAndFullTextSurvives` | Bestanden |
| `migrationKeepsMissionJsonAndSettingsAndNoService` | Bestanden |
| `nativeInflationResizeAndPlayback` | Bestanden |
| `pauseDisableAndQuietHaveNoFlipper` | Bestanden |
| `widgetActionsAndInteractionsPersist` | Bestanden |

Die Missionsaktionen wurden über die erzeugten PendingIntents und über die
Schaltflächen des Missionsfensters ausgeführt. Drei mal 30 Minuten bleiben
exakt 90 Minuten; erneute Zustellung derselben Aktion zählt nicht doppelt.
Tages-/Wochenquote, ursprünglicher Fälligkeitstag, Wiederholungsvorkommen,
Timer, Datei-Neuladen und Backup-Validierung bleiben abgedeckt.

Mission, MissionCodec, Store, Stats, WeeklyStats, Needs, DialogSystem, KalleScene
und RoamPath sind gegenüber 3.0.1 bytegleich. Missions-JSON weiterhin im selben
Store, Schema 3. Kein Löschen/Migrieren vorhandener Missionen. Scheduler schließt
nur zusätzlich das zugehörige Missionsfenster; MissionReceiver aktualisiert nach
Aktionen das Widget mit den neuen Needs-Werten. Backup-Typprüfung um den
Missionsfensterschalter ergänzt. 264 eindeutige Standardsprüche und 24 Vektorzustände
in den Tests bestätigt. Outfitdaten und übrige Einstellungen bleiben erhalten.

## Zwischenfehler und Korrekturen

Ein neuer Test nutzte zunächst try-with-resources für einen ServiceController,
der nicht AutoCloseable ist. Auf explizites finally/destroy korrigiert;
anschließend Testkompilierung und 34 Tests bestanden. Die erste APK war davon
nicht betroffen und bereits erfolgreich gebaut/signiert.

Nach der Optimierung war die Erwartung „exakt acht Bildschritte in 1000 ms“
zu streng: der native UI-Takt lieferte sieben. Der Test prüft jetzt Fortschritt
innerhalb einer begründeten Toleranz, genau einen Taktgeber sowie vollständiges
Anhalten/Weiterlaufen bei geänderter Hostfenstersichtbarkeit. Erneut ausgeführt
und bestanden. Keine offenen automatisierten Testfehler. Historische fehlgeschlagene
XML bleiben ausdrücklich als Zwischenprüfung gekennzeichnet erhalten.

## Offene reale Gerätetests / Grenzen

| Anforderung | Nachweis und reale Grenze |
|---|---|
| Direktes Antippen ohne App-Start | PendingIntent-/Frameworktest bestanden; echte One-UI-Touchweiterleitung offen |
| Unverzerrte Figur / Arme / Requisiten | Uniforme Skalierung getestet, 24 native Posen angesehen; Samsung-Darstellung offen |
| Automatische Szenen / Akku | Native Zeitfortschaltung und Fenstersichtbarkeit getestet; keine echten Akku-/FPS-Messwerte |
| Missionsfenster über YouTube/WhatsApp/Browser | Overlay-Modell, Aktionen und 40-Sekunden-Ende geprüft; reale Android-15-Hintergrundzulassung offen |
| Popup und hörbarer Ton | Kanal/URI/hohe Wichtigkeit geprüft, Ablehnungsfallback simuliert; tatsächliche Anzeige und Hörbarkeit offen |
| Starten / Erledigt / 30 Minuten / keine Duplikate | Ausgeführt, bestanden |
| Bestehende Daten / Update | Gleiche Signatur, Paket und unveränderte Datentypen geprüft; echte APK-Updateinstallation offen |
| Nur eine Widget-Seite / Icons außerhalb | Native Widgetfläche, kein Charakter-Overlay; Seitenwechsel/Launcher-Icons auf One UI offen |
| Build und Signatur | Tatsächlich erfolgreich ausgeführt |

Kein verbundenes Android-/Samsung-Gerät und kein `/dev/kvm` vorhanden. Deshalb
keine langsamen Emulatorstarts und keine behauptete ADB-Installation. Das native
Widget hält seine Position nur durch den Launcher; mehrere vom Nutzer platzierte
Widgets würden mehrere Instanzen ergeben. Display-Aus/Nachbarseiten können nur
vom realen Host-Lifecycle überprüft werden. PAUSE/Ruhezeit verwenden statische
Ansichten; Ruhezeitgrenzen werden beim nächsten Inhaltsupdate wirksam.

Overlay-Erlaubnis und genaue Erinnerungen müssen gegebenenfalls in der Bude
eingerichtet werden. Ein nutzerseitig geplanter exakter Alarm kann den kurzen
Dienst zulässig starten. Andere Hintergrundstarts kann Android verweigern.
Sound und Heads-up bleiben abhängig von Berechtigungen, Lautstärke, „Nicht stören“
und Samsung-Kanaleinstellungen. Manche Apps blenden fremde Overlays aus. Diese
Entscheidungen werden nicht umgangen. Anleitung: README-Update-3.0.2.txt.

## Verwendete offizielle technische Grundlagen

- [Zulässige Ausnahmen für FGS-Hintergrundstarts, unter anderem exakte Nutzeralarme](https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start)
- [shortService: Typ, Berechtigungen und Zeitlimit](https://developer.android.com/develop/background-work/services/fgs/service-types)
- [NotificationChannel und persistente Ton-/Nutzereinstellungen](https://developer.android.com/reference/android/app/NotificationChannel)
- [RemoteViews: unterstützte native Widget-Ansichten](https://developer.android.com/reference/android/widget/RemoteViews)

Originale 3.0.1-Dateien bleiben unverändert gesichert. Frühe 3.0.2-APK und Quelle
wurden separat dauerhaft bereitgestellt; finale Dateien ersetzen sie nicht.
Private Signierschlüssel/Passwörter gehören nicht ins Quellarchiv.
