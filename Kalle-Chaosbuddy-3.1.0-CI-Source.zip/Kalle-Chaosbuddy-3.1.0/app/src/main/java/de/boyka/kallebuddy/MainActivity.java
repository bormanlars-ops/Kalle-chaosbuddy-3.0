package de.boyka.kallebuddy;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class MainActivity extends Activity {
    LinearLayout root;ScrollView scroll;final Handler handler=new Handler(Looper.getMainLooper());
    int selected=-1;Ui.Ring ring;TextView stateLabel;boolean history=false,formOpen=false,settingsVisible=false,successVisible=false;
    boolean addMissionOnOpen=false;
    int page=0,statsYear=Calendar.getInstance().get(Calendar.YEAR),weekDay=-1;
    final ArrayList<Runnable> ticks=new ArrayList<>();
    final Runnable ticker=new Runnable(){public void run(){for(Runnable r:new ArrayList<>(ticks))r.run();handler.postDelayed(this,500);}};
    final BroadcastReceiver changed=new BroadcastReceiver(){public void onReceive(Context c,Intent i){int id=i.getIntExtra("id",-1);if(id>0)selected=id;render();}};
    @Override public void onCreate(Bundle b){super.onCreate(b);SettingsMigration.run(this);selected=getIntent().getIntExtra("id",-1);settingsVisible=getIntent().getBooleanExtra("companionSetup",false);addMissionOnOpen=getIntent().getBooleanExtra("addMission",false);}
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(ticker);handler.post(ticker);Scheduler.reconcile(this);Buddy.schedule(this,false);KalleWidget.updateAll(this);render();if(addMissionOnOpen){addMissionOnOpen=false;editor(null);}if(Build.VERSION.SDK_INT>=33)registerReceiver(changed,new IntentFilter("de.boyka.kallebuddy.CHANGED"),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(changed,new IntentFilter("de.boyka.kallebuddy.CHANGED"));}
    @Override protected void onPause(){super.onPause();handler.removeCallbacks(ticker);ticks.clear();unregisterReceiver(changed);}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);selected=i.getIntExtra("id",-1);successVisible=false;if(selected>0)settingsVisible=false;if(i.getBooleanExtra("companionSetup",false))settingsVisible=true;render();if(i.getBooleanExtra("addMission",false))editor(null);}
    void base(){
        ticks.clear();getWindow().setStatusBarColor(Ui.BG);getWindow().setNavigationBarColor(Ui.BG);
        scroll=new ScrollView(this);scroll.setBackgroundColor(Ui.BG);scroll.setFillViewport(true);scroll.setClipToPadding(false);
        root=Ui.column(this);root.setPadding(Ui.dp(this,22),Ui.dp(this,18),Ui.dp(this,22),Ui.dp(this,28));scroll.addView(root);setContentView(scroll);
        scroll.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});scroll.requestApplyInsets();
    }
    void render(){
        if(formOpen||successVisible)return;
        if(settingsVisible){settings();return;}
        Mission detail=Store.get(this,selected);
        setShowWhenLocked(false);setTurnScreenOn(false);
        if(detail!=null&&!detail.archived()){detail(detail);return;}selected=-1;home();
    }
    void label(String s){TextView t=Ui.bold(this,s,11,Ui.YELLOW);t.setLetterSpacing(.16f);root.addView(t);}
    void heading(String s){TextView t=Ui.heavy(this,s,40,Ui.FG);root.addView(t);}
    String signature(){return Store.prefs(this).getString("items", "[]")+Stats.dayKey(System.currentTimeMillis());}
    void home(){
        successVisible=false;settingsVisible=false;selected=-1;setShowWhenLocked(false);setTurnScreenOn(false);base();
        final String snapshot=signature();ticks.add(()->{if(!snapshot.equals(signature()))render();});
        LinearLayout top=Ui.row(this);TextView brand=Ui.bold(this,"KALLE / CHAOSBUDDY 3.1.0",12,Ui.YELLOW);brand.setLetterSpacing(.15f);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings=Ui.bold(this,"⚙ BUDE",11,Ui.MUTED);settings.setPadding(12,0,0,20);settings.setOnClickListener(v->settings());top.addView(settings);root.addView(top);Ui.gap(root,10);
        heading(page==1?"WOCHENPLAN":page==2?"DEINE BILANZ":page==3?"MISSIONSLOG":"KALLE");
        root.addView(Ui.text(this,page==1?"Feste Zeiten. Klare Ansagen. Jede Woche.":page==2?"Jeder kleine Schritt hinterlässt Spuren.":page==3?"Erledigt, verpasst oder übersprungen.":new SimpleDateFormat("EEEE, dd. MMMM",Locale.GERMANY).format(new Date()).toUpperCase(Locale.GERMANY),13,Ui.MUTED));Ui.gap(root,20);
        LinearLayout tabs=Ui.row(this);String[] names={"HEUTE","WOCHE","STATISTIK","VERLAUF"};
        for(int i=0;i<4;i++){final int n=i;tabs.addView(tab(names[i],page==i,()->{page=n;home();}),new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));}root.addView(tabs);Ui.gap(root,20);
        if(page==1){week();return;}if(page==2){statistics();return;}
        List<Mission> all=Store.all(this);
        if(page==0){
            progressPanel(root,all);Ui.gap(root,16);root.addView(Ui.button(this,"+  NEUE MISSION",true,()->editor(null)));Ui.gap(root,10);
            commandBar();Ui.gap(root,12);
            
            root.addView(Ui.button(this,"KALLES 4×4-REVIER HINZUFÜGEN",false,()->KalleWidget.pin(this)));Ui.gap(root,12);
            if(!ready()){TextView setup=Ui.text(this,"● Alarme noch nicht bereit · Jetzt einrichten",14,Ui.YELLOW);setup.setPadding(0,12,0,20);setup.setOnClickListener(v->settings());root.addView(setup);}
            boolean today=false;label("DEIN TAG / GELB: MISSION · BLAU: ROUTINE");Ui.gap(root,12);
            for(Mission m:all)if(!m.archived()&&(m.dueDay().equals(java.time.LocalDate.now().toString())||m.running())){card(m);today=true;}
            if(!today){empty("FREIE BAHN", "Für heute ist keine offene Mission mehr da. Plane deinen nächsten Schritt.");}
            boolean later=false;for(Mission m:all)if(!m.archived()&&!m.running()&&!m.dueDay().equals(java.time.LocalDate.now().toString())){if(!later){Ui.gap(root,16);label("ALS NÄCHSTES");Ui.gap(root,12);later=true;}card(m);}
        }else{
            Collections.reverse(all);boolean any=false;int shown=0;for(Mission m:all)if(m.archived()){any=true;card(m);if(++shown>=100)break;}
            if(!any)empty("DER ANFANG ZÄHLT", "Sobald du eine Mission beendest, erscheint sie hier. Die Statistik behält auch ältere Einträge.");
            if(shown==100)root.addView(Ui.text(this,"Die letzten 100 Einträge. Die Jahresstatistik berücksichtigt alle gespeicherten Missionen.",12,Ui.MUTED));
        }
        Ui.gap(root,24);TextView footer=Ui.text(this,"DEINE ZEIT · DEINE MISSIONEN",10,Ui.MUTED);footer.setGravity(Gravity.CENTER);root.addView(footer);
    }
    void commandBar(){
        LinearLayout box=Ui.column(this);Ui.pad(box,14);box.setBackground(Ui.shape(Ui.CARD,Ui.dp(this,8)));
        box.addView(Ui.bold(this,"MISSION COMMAND · OFFLINE",12,Ui.YELLOW));Ui.gap(box,6);
        EditText command=field(box,"Sag Kalle, was ansteht ...","",android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        command.setSingleLine(false);command.setMaxLines(3);
        box.addView(Ui.button(this,"BEFEHL PRÜFEN",false,()->{
            MissionCommandParser.Result parsed=MissionCommandParser.parse(command.getText().toString(),java.time.LocalDateTime.now());
            if(!parsed.valid()){command.setError(parsed.error);new AlertDialog.Builder(this).setTitle("Kalle versteht das nicht eindeutig").setMessage(parsed.error).setPositiveButton("Bearbeiten",null).show();return;}
            final long timestamp;
            try {timestamp=parsed.millis(java.time.ZoneId.systemDefault());}
            catch(IllegalArgumentException ex){new AlertDialog.Builder(this).setTitle("Uhrzeit nicht eindeutig").setMessage(ex.getMessage()).setPositiveButton("Ändern",null).show();return;}
            String preview="Mission: "+parsed.title+"\nDatum: "+parsed.dateTime.toLocalDate()+"\nUhrzeit: "+String.format(java.util.Locale.GERMANY,"%02d:%02d",parsed.dateTime.getHour(),parsed.dateTime.getMinute())+" Uhr\nNotiz: "+(parsed.note.isEmpty()?"–":parsed.note);
            new AlertDialog.Builder(this).setTitle("Kalle sagt: Mission verstanden, Chef!")
              .setMessage(preview+"\n\nErst bei Bestätigung wird die Mission gespeichert.")
              .setPositiveButton("MISSION BESTÄTIGEN",(d,w)->{
                  if(timestamp<=System.currentTimeMillis()){
                    new AlertDialog.Builder(this).setTitle("Zeit abgelaufen").setMessage("Dieser Termin liegt inzwischen zurück. Bitte neu eingeben.").setPositiveButton("OK",null).show();return;
                  }
                  Mission m=new Mission();m.id=Store.nextId(this);m.title=parsed.title;m.note=parsed.note;m.duration=15*60000L;m.start=timestamp;m.plannedStart=timestamp;m.reminderAt=timestamp;m.series=m.id;m.category="Alltag";
                  Store.put(this,m);Scheduler.schedule(this,m);KalleFeedback.confirm(this,m,false);home();
              })
              .setNeutralButton("BEARBEITEN",(d,w)->editor(null,false,parsed))
              .setNegativeButton("ABBRECHEN",null).show();
        }));
        root.addView(box);
    }
    void empty(String title,String message){LinearLayout box=Ui.column(this);Ui.pad(box,20);box.setBackground(Ui.shape(Ui.CARD,Ui.dp(this,8)));box.addView(Ui.heavy(this,title,24,Ui.FG));Ui.gap(box,8);box.addView(Ui.text(this,message,14,Ui.MUTED));root.addView(box);}
    void progressPanel(LinearLayout parent,List<Mission> all){
        int planned=0,done=0;long now=System.currentTimeMillis();for(Mission m:all)if(m.dueDay().equals(java.time.LocalDate.now().toString())){planned++;if(m.completed())done++;}
        int goal=Store.prefs(this).getInt("dailyGoal",0),target=planned,percent=target==0?0:Math.min(100,done*100/target);
        LinearLayout box=Ui.column(this);Ui.pad(box,20);box.setBackground(new Ui.MissionBackdrop(Ui.GREEN));
        LinearLayout row=Ui.row(this);LinearLayout copy=Ui.column(this);copy.addView(Ui.bold(this,"TAGESFORTSCHRITT",11,Ui.GREEN));copy.addView(Ui.heavy(this,done+" / "+target+" ERLEDIGT",26,Ui.FG));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));row.addView(Ui.heavy(this,percent+"%",38,Ui.GREEN));box.addView(row);Ui.gap(box,12);
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(percent);bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.GREEN));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff394137));box.addView(bar,new LinearLayout.LayoutParams(-1,Ui.dp(this,10)));Ui.gap(box,8);
        box.addView(Ui.text(this,goal>0?"Persönliches Ziel: "+done+" / "+goal+" · "+Math.min(100,done*100/goal)+" %. Tagesquote zählt alle "+planned+" geplanten Missionen.":"Automatisch: alle heute geplanten Missionen zählen.",12,Ui.MUTED));
        if(parent==root){TextView edit=Ui.bold(this,"ZIEL ANPASSEN  ↗",11,Ui.GREEN);edit.setPadding(0,18,0,2);edit.setOnClickListener(v->goalEditor());box.addView(edit);}parent.addView(box);
    }
    void goalEditor(){EditText number=new EditText(this);number.setInputType(2);number.setHint("0 = automatisch");number.setText(String.valueOf(Store.prefs(this).getInt("dailyGoal",0)));AlertDialog d=new AlertDialog.Builder(this).setTitle("Tagesziel in Missionen").setMessage("0: alle heute geplanten Aufgaben. Oder wähle ein festes Ziel von 1 bis 100. Erledigte und verspätet erledigte Missionen zählen.").setView(number).setPositiveButton("Speichern",null).setNegativeButton("Zurück",null).create();d.show();d.getButton(-1).setOnClickListener(v->{try{int n=Integer.parseInt(number.getText().toString());if(n<0||n>100)throw new NumberFormatException();Store.prefs(this).edit().putInt("dailyGoal",n).apply();d.dismiss();home();}catch(NumberFormatException e){number.setError("0 bis 100 eingeben");}});}
    String daysLabel(Mission m){if(m.dayMask()==127)return "TÄGLICH";String[] days={"MO","DI","MI","DO","FR","SA","SO"};StringBuilder out=new StringBuilder();for(int i=0;i<7;i++)if((m.dayMask()&(1<<i))!=0){if(out.length()>0)out.append(" · ");out.append(days[i]);}return out.toString();}
    void week(){
        root.addView(Ui.accentButton(this,"+  FESTE WOCHENROUTINE",Ui.BLUE,()->editor(null,true)));Ui.gap(root,18);
        Calendar monday=Calendar.getInstance();monday.set(Calendar.HOUR_OF_DAY,0);monday.set(Calendar.MINUTE,0);monday.set(Calendar.SECOND,0);monday.set(Calendar.MILLISECOND,0);monday.add(Calendar.DATE,-((monday.get(Calendar.DAY_OF_WEEK)+5)%7));
        if(weekDay<0)weekDay=(Calendar.getInstance().get(Calendar.DAY_OF_WEEK)+5)%7;
        LinearLayout strip=Ui.row(this);String[] labels={"MO","DI","MI","DO","FR","SA","SO"};for(int i=0;i<7;i++){final int day=i;Calendar date=(Calendar)monday.clone();date.add(Calendar.DATE,i);TextView t=tab(labels[i]+"\n"+date.get(Calendar.DATE),weekDay==i,()->{weekDay=day;home();});t.setTextSize(11);strip.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1));}root.addView(strip);Ui.gap(root,20);
        Calendar chosen=(Calendar)monday.clone();chosen.add(Calendar.DATE,weekDay);label(new SimpleDateFormat("EEEE · dd.MM.",Locale.GERMANY).format(chosen.getTime()).toUpperCase(Locale.GERMANY));Ui.gap(root,12);
        String selectedDay=java.time.Instant.ofEpochMilli(chosen.getTimeInMillis()).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString();boolean found=false;for(Mission m:Store.all(this))if(m.routine()&&m.dueDay().equals(selectedDay)){card(m);found=true;}if(!found)empty("KEINE ROUTINE","Für diesen Tag ist keine konkrete Wiederholung gespeichert.");Ui.gap(root,18);root.addView(Ui.text(this,"Jede Wiederholung hat einen eigenen Verlauf. Antippen öffnet genau diesen Eintrag. Kommende Wiederholungen werden acht Tage im Voraus gespeichert.",13,Ui.MUTED));
    }
    void statistics(){
        List<Mission> all=Store.all(this);basicStatistics(all);Stats stats=new Stats(all,statsYear);
        LinearLayout years=Ui.row(this);years.addView(tab("‹",false,()->{statsYear--;home();}),new LinearLayout.LayoutParams(0,48,1));TextView y=Ui.heavy(this,String.valueOf(statsYear),30,Ui.FG);y.setGravity(Gravity.CENTER);years.addView(y,new LinearLayout.LayoutParams(0,-2,3));years.addView(tab("›",false,()->{statsYear++;home();}),new LinearLayout.LayoutParams(0,48,1));root.addView(years);Ui.gap(root,20);
        LinearLayout numbers=Ui.row(this);metric(numbers,String.valueOf(stats.done),"ERLEDIGT",Ui.GREEN);metric(numbers,Stats.duration(stats.total),"ERFASSTE ZEIT",Ui.YELLOW);root.addView(numbers);Ui.gap(root,12);
        LinearLayout more=Ui.row(this);metric(more,String.valueOf(stats.activeDays),"AKTIVE TAGE",Ui.BLUE);metric(more,stats.started==0?"–":(stats.onTime*100/stats.started)+"%","PÜNKTLICH¹",Ui.FG);root.addView(more);Ui.gap(root,24);
        label("JAHRESAKTIVITÄT / ERLEDIGTE MISSIONEN");Ui.gap(root,12);Ui.YearChart heatmap=new Ui.YearChart(this,stats);root.addView(heatmap,new LinearLayout.LayoutParams(-1,Ui.dp(this,128)));root.addView(Ui.text(this,"Mo oben · So unten    ▪ wenig  →  ■ viel    Grau = keine Aktivität",11,Ui.MUTED));Ui.gap(root,24);
        label("ZEIT PRO MONAT");Ui.gap(root,12);root.addView(new Ui.MonthChart(this,stats),new LinearLayout.LayoutParams(-1,Ui.dp(this,170)));Ui.gap(root,24);
        label("AUFGABEN / GESAMTZEIT IM JAHR");Ui.gap(root,12);if(stats.tasks.isEmpty())empty("HIER WÄCHST DEINE BILANZ", "Keine erfundenen Werte. Schließe deine erste Mission ab, dann füllen sich Diagramme und Zeiten.");
        List<Map.Entry<String,Stats.Task>> tasks=new ArrayList<>(stats.tasks.entrySet());tasks.sort((a,b)->Long.compare(b.getValue().time,a.getValue().time));long max=1;for(Map.Entry<String,Stats.Task> e:tasks)max=Math.max(max,e.getValue().time);
        for(Map.Entry<String,Stats.Task> e:tasks){LinearLayout box=Ui.column(this);Ui.pad(box,16);box.setBackground(Ui.shape(Ui.CARD,8));box.addView(Ui.bold(this,e.getKey(),16,Ui.FG));Ui.gap(box,5);box.addView(Ui.text(this,e.getValue().count+"× erledigt  ·  "+Stats.duration(e.getValue().time),13,Ui.GREEN));ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setProgress((int)(e.getValue().time*100/max));bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.BLUE));box.addView(bar,new LinearLayout.LayoutParams(-1,Ui.dp(this,10)));root.addView(box);Ui.gap(root,10);}
        Ui.gap(root,18);long lifetime=0;int lifetimeDone=0;for(Mission m:all)if(m.completed()){lifetime+=m.elapsed();lifetimeDone++;}root.addView(Ui.bold(this,"SEIT BEGINN: "+lifetimeDone+" MISSIONEN · "+Stats.duration(lifetime),12,Ui.YELLOW));Ui.gap(root,10);
        root.addView(Ui.text(this,"Zeit = vom Missionsstart bis zum Antippen von Erledigt, einschließlich verspäteter Abschlüsse. Das ist erfasste Laufzeit, keine gemessene Arbeitszeit. Kalenderzuordnung nach geplantem Start. Gleich benannte Aufgaben werden zusammengefasst.\n¹ Pünktliche Abschlüsse / alle gestarteten bzw. verpassten Missionen. Gelöschte Einträge zählen nicht.",12,Ui.MUTED));
    }
    void basicStatistics(List<Mission> all){java.time.LocalDate today=java.time.LocalDate.now();WeeklyStats.Summary d=WeeklyStats.today(all,today),w=WeeklyStats.week(all,today);label("HEUTE / ORIGINALER FÄLLIGKEITSTAG");Ui.gap(root,10);root.addView(Ui.heavy(this,d.planned==0?"KEINE DATEN":d.percent()+" % ERLEDIGT",28,Ui.GREEN));root.addView(Ui.text(this,d.planned+" geplant · "+d.done+" erledigt · "+d.open+" offen",16,Ui.FG));Ui.gap(root,18);label("DIESE WOCHE / MO–SO");Ui.gap(root,10);root.addView(Ui.heavy(this,w.planned==0?"KEINE DATEN":w.percent()+" % ERLEDIGT",28,Ui.YELLOW));root.addView(Ui.text(this,w.planned+" geplant · "+w.done+" erledigt · "+w.open+" offen\n"+w.snoozed+" Missionen verschoben · "+w.snoozes+" Aktionen · "+w.snoozeMillis/60000+" Minuten",15,Ui.MUTED));Ui.gap(root,18);label("LETZTE SIEBEN TAGE / ERLEDIGT VON GEPLANT");root.addView(new Ui.WeekChart(this,all,today),new LinearLayout.LayoutParams(-1,Ui.dp(this,190)));Ui.gap(root,18);label("WOCHENÜBERSICHT");for(int i=0;i<6;i++){java.time.LocalDate start=WeeklyStats.monday(today).minusWeeks(i);WeeklyStats.Summary n=WeeklyStats.between(all,start,start.plusDays(7));root.addView(Ui.text(this,start+": "+(n.planned==0?"Keine Daten":n.done+" / "+n.planned+" · "+n.percent()+" %"),14,Ui.FG));Ui.gap(root,8);}root.addView(Ui.text(this,"Zuordnung nach ursprünglichem Fälligkeitstag. Jede Wiederholung zählt einmal. Aufschieben verändert die Wochenquote nicht. Die Woche enthält auch noch kommende geplante Aufgaben.",12,Ui.MUTED));Ui.gap(root,24);}
    void metric(LinearLayout parent,String value,String caption,int color){LinearLayout box=Ui.column(this);Ui.pad(box,14);box.setBackground(Ui.shape(Ui.CARD,8));box.addView(Ui.heavy(this,value,28,color));box.addView(Ui.text(this,caption,10,Ui.MUTED));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(0,0,Ui.dp(this,6),0);parent.addView(box,lp);}
    TextView tab(String s,boolean active,Runnable click){TextView t=Ui.bold(this,s,12,active?Ui.YELLOW:Ui.MUTED);t.setGravity(Gravity.CENTER);t.setBackground(Ui.shape(active?Ui.CARD:Ui.BG,Ui.dp(this,4)));t.setOnClickListener(v->click.run());return t;}
    String date(long time){return new SimpleDateFormat("dd.MM. · HH:mm",Locale.GERMANY).format(new Date(time));}
    String status(Mission m){switch(m.state){case "waiting":return "MISSION WARTET";case "paused":return "TIMER PAUSIERT";case "active":return "MISSION LÄUFT";case "overdue":return "ZEIT ABGELAUFEN";case "done":return "MISSION BESTANDEN";case "late":return "SPÄTER ABGESCHLOSSEN";case "skipped":return "ÜBERSPRUNGEN";case "missed":return "VERPASST";default:return "GEPLANT";}}
    void card(Mission m){
        LinearLayout card=Ui.column(this);Ui.pad(card,18);card.setBackground(new Ui.MissionBackdrop(m.routine()?Ui.BLUE:Ui.YELLOW));
        TextView status=Ui.bold(this,status(m)+(m.routine()?"  ↻ "+daysLabel(m):""),10,m.state.equals("overdue")?Ui.RED:m.archived()?Ui.MUTED:m.routine()?Ui.BLUE:Ui.YELLOW);status.setLetterSpacing(.1f);card.addView(status);Ui.gap(card,8);
        card.addView(Ui.heavy(this,m.title,26,Ui.FG));Ui.gap(card,7);
        TextView line=Ui.text(this,date(m.reminder())+" / "+m.duration/60000+" MIN · "+m.category,12,Ui.MUTED);card.addView(line);
        if(m.running()){
            TextView timer=Ui.heavy(this,"",32,Ui.YELLOW);Ui.gap(card,8);card.addView(timer);Runnable tick=()->timer.setText(m.remaining(System.currentTimeMillis())<=0?"ZEIT ABGELAUFEN":Mission.clock(m.remaining(System.currentTimeMillis())));ticks.add(tick);tick.run();
        }
        if(m.archived()) {if(m.points()>0){Ui.gap(card,6);card.addView(Ui.bold(this,"+$"+m.points(),16,Ui.GREEN));}card.setOnClickListener(v->archivedOptions(m));}
        else card.setOnClickListener(v->{selected=m.id;render();});
        root.addView(card,new LinearLayout.LayoutParams(-1,-2));Ui.gap(root,12);
    }
    void detail(Mission m){settingsVisible=false;base();label("MISSION / "+status(m));Ui.gap(root,12);heading(m.title.toUpperCase(Locale.GERMANY));Ui.gap(root,12);root.addView(Ui.text(this,"Kalle sagt: Chef, eine Sache nach der anderen.",18,Ui.YELLOW));Ui.gap(root,12);if(!m.note.isEmpty())root.addView(Ui.text(this,m.note,17,Ui.FG));Ui.gap(root,12);root.addView(Ui.text(this,"Ursprünglich: "+date(m.anchor())+"\nAktuelle Erinnerung: "+date(m.reminder())+"\n"+m.category+(m.external?" · Fester externer Termin":"")+"\n"+m.snoozeCount+"× verschoben · "+m.snoozeMillis/60000+" Minuten",14,Ui.MUTED));Ui.gap(root,16);
        if(m.running()){ring=new Ui.Ring(this);root.addView(ring,new LinearLayout.LayoutParams(-1,Ui.dp(this,250)));root.addView(Ui.bold(this,m.state.equals("paused")?"TIMER PAUSIERT":"DEINE RESTZEIT",14,Ui.YELLOW));Runnable tick=()->{Mission n=Store.get(this,m.id);if(n==null||n.archived()){selected=-1;render();return;}ring.update(n.remaining(System.currentTimeMillis()),n.duration);};ticks.add(tick);tick.run();String a=m.state.equals("paused")?"RESUME":"PAUSE";root.addView(Ui.button(this,a.equals("RESUME")?"FORTSETZEN":"TIMER PAUSIEREN",true,()->{Store.act(this,m.id,a,m.revision);AlarmService.notify(this,Store.get(this,m.id),false);selected=m.id;render();}));}
        else{root.addView(Ui.button(this,"STARTEN",true,()->{Store.act(this,m.id,"BEGIN",m.revision);AlarmService.notify(this,Store.get(this,m.id),false);selected=m.id;render();}));Ui.gap(root,10);int min=Store.prefs(this).getInt("defaultSnooze",30);root.addView(Ui.button(this,min+" MIN AUFSCHIEBEN",false,()->snooze(m,min)));Ui.gap(root,8);LinearLayout row=Ui.row(this);for(int minutes:new int[]{10,30,60})row.addView(Ui.button(this,minutes+" MIN",false,()->snooze(m,minutes)),new LinearLayout.LayoutParams(0,-2,1));root.addView(row);Ui.gap(root,10);root.addView(Ui.button(this,"BEARBEITEN",false,()->editor(m)));}
        Ui.gap(root,12);root.addView(Ui.accentButton(this,"✓ ERLEDIGT",Ui.GREEN,()->complete(m)));Ui.gap(root,10);root.addView(Ui.button(this,"ABBRECHEN",false,()->new AlertDialog.Builder(this).setTitle("Mission abbrechen?").setMessage("Bleibt als abgebrochen im Verlauf.").setPositiveButton("Abbrechen",(d,w)->{Store.act(this,m.id,"SKIP",m.revision);selected=-1;home();}).setNegativeButton("Zurück",null).show()));Ui.gap(root,10);root.addView(Ui.button(this,m.routine()?"ROUTINE BEENDEN":"LÖSCHEN",false,()->confirmDelete(m)));Ui.gap(root,10);root.addView(Ui.button(this,"← ÜBERSICHT",false,()->{selected=-1;home();}));}
    void snooze(Mission m,int min){if(Store.snooze(this,m.id,min,m.revision,"ui:"+m.id+":"+m.revision)){Mission n=Store.get(this,m.id);selected=-1;home();new AlertDialog.Builder(this).setTitle("Kalle sagt").setMessage("Na gut, Chef. Dann eben "+new SimpleDateFormat("HH:mm",Locale.GERMANY).format(new Date(n.reminder()))+" Uhr. Aber diesmal wirklich!\n\n"+n.snoozeCount+"× · "+n.snoozeMillis/60000+" Minuten insgesamt.").setPositiveButton("Alles klar",null).show();}}
    void complete(Mission m){Store.finish(this,m.id,true);Scheduler.command(this,"REFRESH",m.id);selected=-1;success(Store.get(this,m.id));}
    void success(Mission m){successVisible=true;if(Store.prefs(this).getBoolean("sound",true)){android.media.MediaPlayer sound=android.media.MediaPlayer.create(this,R.raw.mission_passed);if(sound!=null){sound.setOnCompletionListener(mp->mp.release());sound.start();}}base();Ui.gap(root,70);label("FORTSCHRITT GESPEICHERT");Ui.gap(root,18);TextView title=Ui.heavy(this,"MISSION\nBESTANDEN",58,Ui.GREEN);title.setShadowLayer(2,2,3,android.graphics.Color.BLACK);root.addView(title);Ui.gap(root,18);root.addView(Ui.heavy(this,m.title,28,Ui.FG));Ui.gap(root,12);root.addView(Ui.text(this,m.state.equals("late")?"Später fertig. Trotzdem durchgezogen.":"Innerhalb des Zeitlimits erledigt.",17,Ui.MUTED));Ui.gap(root,30);root.addView(Ui.heavy(this,"RESPEKT +\n$"+m.points(),36,Ui.YELLOW));Ui.gap(root,40);root.addView(Ui.button(this,"WEITER",true,()->home()));}
    void missionOptions(Mission m){selected=m.id;render();}
    void archivedOptions(Mission m){new AlertDialog.Builder(this).setTitle(m.title).setMessage(status(m)+"\n"+date(m.start)+"\n"+m.note).setPositiveButton("Schließen",null).setNeutralButton("Löschen",(d,w)->confirmDelete(m)).show();}
    void confirmDelete(Mission m){new AlertDialog.Builder(this).setTitle("Mission löschen?").setMessage(m.routine()&&!m.archived()?"Damit endet diese Routine. Ihr bisheriger Verlauf bleibt erhalten.":m.title).setPositiveButton("Löschen",(d,w)->{if(m.routine()&&!m.archived())Store.stopRoutine(this,m);else{Scheduler.cancel(this,m);Store.delete(this,m.id);}Scheduler.command(this,"REFRESH",-1);home();}).setNegativeButton("Zurück",null).show();}
    EditText field(LinearLayout box,String hint,String value,int input){EditText e=new EditText(this);e.setTextColor(Ui.FG);e.setTextSize(16);e.setHintTextColor(Ui.MUTED);e.setHint(hint);e.setText(value);e.setInputType(input);box.addView(e,new LinearLayout.LayoutParams(-1,-2));Ui.gap(box,10);return e;}
    void editor(Mission original){editor(original,false);}
    void editor(Mission original,boolean newRoutine){editor(original,newRoutine,null);}
    void editor(Mission original,boolean newRoutine,MissionCommandParser.Result draft){
        final int previousDays=original==null?0:original.dayMask();final long previousAnchor=original==null?0:original.anchor();
        formOpen=true;LinearLayout form=Ui.column(this);Ui.pad(form,22);form.setBackgroundColor(Ui.BG);ScrollView s=new ScrollView(this);s.addView(form);
        EditText title=field(form,"Was ist die Mission?",original==null?(draft==null?"":draft.title):original.title,android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        EditText note=field(form,"Ziel / Schritte (optional)",original==null?(draft==null?"":draft.note):original.note,android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        EditText category=field(form,"Kategorie",original==null?"Alltag":original.category,android.text.InputType.TYPE_CLASS_TEXT);CheckBox external=new CheckBox(this);external.setText("Fester externer Termin – nur Erinnerung verschieben");external.setTextColor(Ui.FG);external.setChecked(original!=null&&original.external);form.addView(external);
        EditText minutes=field(form,"Zeitlimit in Minuten (1–1440)",original==null?"15":String.valueOf(original.duration/60000),android.text.InputType.TYPE_CLASS_NUMBER);
        Calendar when=Calendar.getInstance();when.setTimeInMillis(original==null?(draft==null?System.currentTimeMillis()+300000:draft.millis(java.time.ZoneId.systemDefault())):original.start);when.set(Calendar.SECOND,0);when.set(Calendar.MILLISECOND,0);
        TextView time=Ui.button(this,"",false,()->new TimePickerDialog(this,(v,h,min)->{when.set(Calendar.HOUR_OF_DAY,h);when.set(Calendar.MINUTE,min);renderTimeLabel(form,when);},when.get(Calendar.HOUR_OF_DAY),when.get(Calendar.MINUTE),true).show());time.setTag("time");form.addView(time);Ui.gap(form,10);
        TextView day=Ui.button(this,"Datum ändern",false,()->new DatePickerDialog(this,(v,y,mo,d)->{when.set(y,mo,d);renderTimeLabel(form,when);},when.get(Calendar.YEAR),when.get(Calendar.MONTH),when.get(Calendar.DAY_OF_MONTH)).show());form.addView(day);Ui.gap(form,10);renderTimeLabel(form,when);
        form.addView(Ui.bold(this,"WIEDERHOLUNG / Wochentage auswählen",12,Ui.BLUE));Ui.gap(form,8);
        CheckBox[] weekdays=new CheckBox[7];String[] dayNames={"Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag","Sonntag"};
        int initial=original!=null?original.dayMask():newRoutine?31:0;
        for(int i=0;i<7;i++){CheckBox dayBox=new CheckBox(this);dayBox.setText(dayNames[i]);dayBox.setTextColor(Ui.FG);dayBox.setChecked((initial&(1<<i))!=0);weekdays[i]=dayBox;form.addView(dayBox);}
        form.addView(Ui.text(this,"Kein Tag = einmalige Mission. Ausgewählte Tage = blaue Grundaufgabe. Datum = frühester Start, Uhrzeit bleibt wöchentlich gleich.",12,Ui.MUTED));
        TextView error=Ui.text(this,"",13,Ui.RED);form.addView(error);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(original==null?"NEUE MISSION":"MISSION BEARBEITEN").setView(s).setPositiveButton("Speichern",null).setNegativeButton("Zurück",null).create();
        dialog.setOnDismissListener(d->formOpen=false);dialog.show();dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int mins;try{mins=Integer.parseInt(minutes.getText().toString());}catch(NumberFormatException e){error.setText("Gib ein Zeitlimit zwischen 1 und 1440 Minuten ein.");return;}
            if(title.getText().toString().trim().isEmpty()||title.getText().length()>120){error.setText("Gib der Mission einen Namen (max. 120 Zeichen).");return;}
            if(mins<1||mins>1440){error.setText("Das Zeitlimit muss 1 bis 1440 Minuten betragen.");return;}
            if(note.getText().length()>1500){error.setText("Die Beschreibung darf höchstens 1500 Zeichen enthalten.");return;}
            int dayMask=0;for(int i=0;i<7;i++)if(weekdays[i].isChecked())dayMask|=1<<i;
            long chosen=when.getTimeInMillis();if(dayMask!=0){Mission candidate=new Mission();candidate.start=chosen;candidate.days=dayMask;chosen=candidate.nextOccurrence(Math.max(System.currentTimeMillis(),chosen-1));}
            if(chosen<=System.currentTimeMillis()){error.setText("Wähle eine zukünftige Startzeit oder Wochentage.");return;}
            Mission m=original==null?new Mission():original;if(original!=null)Scheduler.cancel(this,original);else m.id=Store.nextId(this);
            m.revision++;m.reminderAt=chosen;m.plannedLocal="";m.category=category.getText().toString().trim().isEmpty()?"Alltag":category.getText().toString().trim();m.external=external.isChecked();m.title=title.getText().toString().trim();m.note=note.getText().toString().trim();m.duration=mins*60000L;m.start=chosen;m.plannedStart=chosen;m.days=dayMask;m.daily=dayMask==127;if(m.series==0)m.series=m.id;if(previousDays!=0){if(m.dayMask()==0)Store.prefs(this).edit().putBoolean("stopped_"+m.series,true).commit();for(Mission n:Store.all(this))if(n.series==m.series&&n.id!=m.id&&!n.archived()&&!n.running()&&n.snoozeCount==0&&n.anchor()>previousAnchor)Store.delete(this,n.id);}
            Store.put(this,m);Store.setRoutineDefinition(this,m);Scheduler.reconcile(this);formOpen=false;dialog.dismiss();home();KalleFeedback.confirm(this,m,false);
        });
    }
    void renderTimeLabel(LinearLayout form,Calendar c){TextView time=form.findViewWithTag("time");time.setText("Start: "+date(c.getTimeInMillis()));}
    boolean notifications(){return getSystemService(NotificationManager.class).areNotificationsEnabled();}
    boolean ready(){return notifications()&&Scheduler.allowed(this);}
    void setupNeeded(){new AlertDialog.Builder(this).setTitle("Missionsalarme aktivieren").setMessage("Erlaube zuerst Benachrichtigungen und genaue Alarme. Danach kannst du Missionen planen.").setPositiveButton("Einrichten",(d,w)->settings()).setNegativeButton("Zurück",null).show();}
    void openSettings(Intent i){try{startActivity(i);}catch(ActivityNotFoundException e){Toast.makeText(this,"Öffne die App-Einstellungen von Missionen manuell.",Toast.LENGTH_LONG).show();}}
    void settings(){settingsVisible=true;base();label("KALLE / EINSTELLUNGEN");heading("KALLES BUDE");root.addView(Ui.text(this,"Stimmung "+Needs.mood(this)+" / 100 · Energie "+Needs.energy(this)+" / 100",16,Ui.GREEN));Ui.gap(root,18);
        setting(notifications(),"BENACHRICHTIGUNGEN","Für Missionen inklusive Ton; das Widget braucht diese Erlaubnis nicht. Speichern und Timer funktionieren auch ohne Erlaubnis.",()->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);else openSettings(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));});
        getSystemService(NotificationManager.class).createNotificationChannel(AlarmService.channel());
        android.app.NotificationChannel missionChannel=getSystemService(NotificationManager.class).getNotificationChannel(AlarmService.CHANNEL);
        setting(missionChannel==null||missionChannel.getImportance()>=NotificationManager.IMPORTANCE_HIGH,"MISSIONEN ALS POP-UP","Unter Android: Benachrichtigungskategorie → Pop-up anzeigen und Ton/Vibration erlauben. Nicht stören kann Pop-ups unterdrücken. Wegwischen schließt die Meldung, ohne die Mission zu erledigen.",()->openSettings(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID,AlarmService.CHANNEL)));
        setting(Settings.canDrawOverlays(this),"MISSIONSFENSTER ÜBER ANDEREN APPS","Nur für fällige Missionen: ein schließbares Fenster für höchstens 40 Sekunden. Kalle selbst bleibt im Widget. Ohne Erlaubnis bleibt die Android-Benachrichtigung.",()->openSettings(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
        toggle("Zusätzliches Missionsfenster erlauben","missionPopups",true);
        root.addView(Ui.text(this,AlarmService.diagnostics(this),13,Ui.MUTED));Ui.gap(root,10);
        root.addView(Ui.button(this,"TON UND POP-UP PRÜFEN",false,()->AlarmService.preview(this)));Ui.gap(root,12);
        setting(Scheduler.allowed(this),"GENAUE ERINNERUNGEN","Ohne Erlaubnis können Erinnerungen verspätet eintreffen.",()->{if(Build.VERSION.SDK_INT>=31)openSettings(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));});
        root.addView(Ui.text(this,"Kalle wohnt ausschließlich in seinem nativen 4×4-Widget. Für die Figur ist keine Overlay-Erlaubnis nötig. Nur das optionale Missionsfenster nutzt sie. Android-Benachrichtigungen und deren Ton bleiben unabhängig vom Widget.",14,Ui.MUTED));Ui.gap(root,12);
        root.addView(Ui.button(this,CompanionControl.enabled(this)?"KALLE VOLLSTÄNDIG DEAKTIVIEREN":"WIDGET-KALLE AKTIVIEREN",true,()->{if(CompanionControl.enabled(this))CompanionControl.stop(this);else CompanionControl.start(this);settings();}));Ui.gap(root,10);
        root.addView(Ui.button(this,"4×4-REVIER HINZUFÜGEN",false,()->KalleWidget.pin(this)));Ui.gap(root,16);
        choose("Kalles Größe im Revier","kalleSize",100,new String[]{"75 %","100 %","125 %","150 %"},new int[]{75,100,125,150});choose("Sprechblasengröße","bubbleSize",100,new String[]{"75 %","100 %","125 %","150 %"},new int[]{75,100,125,150});choose("Schriftgröße (Widget passt bei Bedarf an)","bubbleFont",24,new String[]{"16 sp","20 sp","24 sp","28 sp"},new int[]{16,20,24,28});choose("Laufgeschwindigkeit","speed",40,new String[]{"Langsam","Normal","Schnell"},new int[]{22,40,65});choose("Horizontaler Bereich","range",100,new String[]{"25 %","50 %","75 %","100 %"},new int[]{25,50,75,100});choose("Vertikale Grundlinie","baseline",98,new String[]{"Oben","Mitte","Weiter unten","Unten"},new int[]{0,45,75,98});choose("Kleidung","kalleOutfit",0,new String[]{"Jahreszeiten","Grüne Jacke","Weihnachtslook","Sommer","Hoodie","Mantel"},new int[]{0,1,2,3,4,5});choose("Humorlevel","humor",1,new String[]{"Freundlich","Frech","Asozial"},new int[]{0,1,2});toggle("Vulgäre Sprüche erlauben","vulgar",false);toggle("Ruhezeiten aktivieren (Figur und Sprüche)","quiet",false);timeSetting("Ruhe beginnt","quietStart",1320);timeSetting("Ruhe endet","quietEnd",480);toggle("Energiesparmodus (langsame Einzelbilder)","powerSave",false);toggle("Kalle pausieren","paused",false);toggle("Missionserinnerungen aktivieren","reminders",true);choose("Standard-Aufschieben","defaultSnooze",30,new String[]{"10 Minuten","30 Minuten","60 Minuten"},new int[]{10,30,60});toggle("Erfolgston in der App","sound",true);Ui.gap(root,14);buddySettings();
        root.addView(Ui.text(this,"Figur antippen: direkte Reaktion. Szene: optionale Handsteuerung. Kalle läuft zu festen Lagerplätzen, benutzt Gegenstände und geht weiter. Sprechblasen erscheinen gelegentlich und verschwinden nach vier Sekunden. Bewegung und Tiefe bleiben im Widget. Das vorbereitete Programm wird bei Ereignissen und regulären Systemupdates erneuert. Ruhezeiten werden beim nächsten Inhaltsupdate berücksichtigt.",13,Ui.MUTED));Ui.gap(root,12);root.addView(Ui.button(this,"DATEN EXPORTIEREN",false,()->startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"Kalle-Sicherung.json"),501)));Ui.gap(root,10);root.addView(Ui.button(this,"DATEN IMPORTIEREN",false,()->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json"),502)));Ui.gap(root,18);root.addView(Ui.button(this,"ZURÜCK ZU DEN MISSIONEN",false,()->home()));}
    void choose(String title,String key,int def,String[] names,int[] values){int current=Store.prefs(this).getInt(key,def),index=-1;for(int i=0;i<values.length;i++)if(values[i]==current)index=i;root.addView(Ui.button(this,title+": "+(index<0?current+" (übernommen)":names[index]),false,()->new AlertDialog.Builder(this).setTitle(title).setItems(names,(d,w)->{Store.prefs(this).edit().putInt(key,values[w]).commit();KalleWidget.updateAll(this);settings();}).show()));Ui.gap(root,10);}
    void timeSetting(String title,String key,int def){int val=Store.prefs(this).getInt(key,def);root.addView(Ui.button(this,String.format(Locale.GERMANY,"%s: %02d:%02d",title,val/60,val%60),false,()->new TimePickerDialog(this,(v,h,m)->{Store.prefs(this).edit().putInt(key,h*60+m).commit();KalleWidget.updateAll(this);settings();},val/60,val%60,true).show()));Ui.gap(root,10);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;try{if(request==501){try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(Backup.exportData(this).getBytes("UTF-8"));}Toast.makeText(this,"Sicherung gespeichert",Toast.LENGTH_LONG).show();}else if(request==502){String json;try(java.io.InputStream in=getContentResolver().openInputStream(data.getData())){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>10485760)throw new IllegalArgumentException("Datei zu groß");}json=new String(out.toByteArray(),"UTF-8");}Backup.validate(json);new AlertDialog.Builder(this).setTitle("Sicherung importieren?").setMessage("Ersetzt alle vorhandenen Missionen und Einstellungen. Die JSON-Datei enthält private Texte im Klartext.").setPositiveButton("Importieren",(d,w)->{try{Backup.importData(this,json);settings();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}).setNegativeButton("Zurück",null).show();}}catch(Exception e){Toast.makeText(this,"Dateifehler: "+e.getMessage(),Toast.LENGTH_LONG).show();}}

    void buddySettings(){
        label("KALLE / SPRECHBLASEN");Ui.gap(root,12);
        root.addView(Ui.text(this,"Kalles Figur und Sprechblase bleiben im Widget. Fällige Missionen können unabhängig davon als Android-Pop-up über geöffneten Apps erscheinen. Keine Spracheingabe.",13,Ui.MUTED));Ui.gap(root,10);
        root.addView(Ui.button(this,"EIGENE SPRÜCHE HINZUFÜGEN",false,()->{EditText input=new EditText(this);input.setText(Store.prefs(this).getString("buddyLines",""));input.setHint("Ein Spruch pro Zeile, höchstens 30");input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);input.setMinLines(4);AlertDialog d=new AlertDialog.Builder(this).setTitle("Eigene Sprüche").setMessage("Eigene Texte werden als asozial/vulgär behandelt und nur bei passenden Humorfiltern gezeigt.").setView(input).setPositiveButton("Speichern",null).setNegativeButton("Zurück",null).create();d.show();d.getButton(-1).setOnClickListener(v->{String content=input.getText().toString().trim();String[] lines=content.isEmpty()?new String[0]:content.split("\n");if(lines.length>30){input.setError("Maximal 30 Sprüche");return;}for(String line:lines)if(line.length()>200){input.setError("Maximal 200 Zeichen pro Zeile");return;}Store.prefs(this).edit().putString("buddyLines",content).apply();d.dismiss();});}));Ui.gap(root,12);
        root.addView(Ui.button(this,"ZUFALLSSPRÜCHE: "+DialogSystem.LINES.size()+" + EIGENE",false,()->new AlertDialog.Builder(this).setTitle("Kalles Sprüche").setMessage(""+DialogSystem.LINES.size()+" verschiedene freche/vulgäre Standardsprüche. Keine automatische Aufgabenanlage.").setPositiveButton("Alles klar",null).show()));Ui.gap(root,15);
    }

    void setting(boolean ok,String title,String desc,Runnable click){LinearLayout c=Ui.column(this);Ui.pad(c,16);c.setBackground(Ui.shape(Ui.CARD,Ui.dp(this,6)));c.addView(Ui.bold(this,(ok?"✓  ":"○  ")+title,14,ok?Ui.GREEN:Ui.YELLOW));Ui.gap(c,6);c.addView(Ui.text(this,desc,13,Ui.MUTED));c.setOnClickListener(v->click.run());root.addView(c);Ui.gap(root,10);}
    void toggle(String title,String key,boolean def){Switch sw=new Switch(this);sw.setText(title);sw.setTextSize(14);sw.setTextColor(Ui.FG);sw.setChecked(Store.prefs(this).getBoolean(key,def));sw.setPadding(0,Ui.dp(this,12),0,Ui.dp(this,12));sw.setOnCheckedChangeListener((b,v)->{Store.prefs(this).edit().putBoolean(key,v).commit();if(key.equals("missionPopups")&&!v&&MissionPopupService.live!=null)MissionPopupService.live.close();if(key.equals("reminders")){for(Mission m:Store.all(this)){Scheduler.cancel(this,m);if(!v)Scheduler.dismiss(this,m.id);else if(m.running()||m.state.equals("waiting"))AlarmService.notify(this,m,false);}Scheduler.reconcile(this);}KalleWidget.updateAll(this);});root.addView(sw);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==42)settings();}
    @Override public void onBackPressed(){if(selected!=-1||settingsVisible||page!=0){selected=-1;page=0;home();}else super.onBackPressed();}
}
