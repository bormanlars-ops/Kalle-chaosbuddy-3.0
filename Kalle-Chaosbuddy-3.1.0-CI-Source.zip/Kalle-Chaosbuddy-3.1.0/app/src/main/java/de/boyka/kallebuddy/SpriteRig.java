package de.boyka.kallebuddy;
import android.content.*;import android.graphics.*;
/** One consistent cutout rig: one head, one torso, two articulated arms, two legs. */
final class SpriteRig{
 static Bitmap[] pieces;final Paint paint=new Paint(3);final Paint ink=new Paint(3);final Canvas c;final Context context;final float phase;final KalleScene.Action action;final int outfit;
 SpriteRig(Context context,Canvas c,KalleScene.Action action,float phase,int outfit){this.context=context;this.c=c;this.action=action;this.phase=phase;this.outfit=outfit;load(context);ink.setColor(0xff28241e);ink.setStrokeCap(Paint.Cap.ROUND);}
 static synchronized void load(Context c){if(pieces!=null)return;Bitmap atlas=BitmapFactory.decodeResource(c.getResources(),R.drawable.kalle_rig);pieces=new Bitmap[12];int cw=atlas.getWidth()/3,ch=atlas.getHeight()/4;int[] pixels=new int[cw*ch];for(int i=0;i<12;i++){int ox=(i%3)*cw,oy=(i/3)*ch;atlas.getPixels(pixels,0,cw,ox,oy,cw,ch);int l=cw,t=ch,r=0,b=0;for(int y=0;y<ch;y++)for(int x=0;x<cw;x++)if(Color.alpha(pixels[y*cw+x])>24){l=Math.min(l,x);r=Math.max(r,x);t=Math.min(t,y);b=Math.max(b,y);}if(r<l)throw new IllegalStateException("Leeres Figurenteil "+i);pieces[i]=Bitmap.createBitmap(atlas,ox+l,oy+t,r-l+1,b-t+1);}atlas.recycle();BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=2;Bitmap torso=BitmapFactory.decodeResource(c.getResources(),R.drawable.kalle_torso,options);int[] data=new int[torso.getWidth()*torso.getHeight()];torso.getPixels(data,0,torso.getWidth(),0,0,torso.getWidth(),torso.getHeight());int left=torso.getWidth(),top=torso.getHeight(),right=0,bottom=0;for(int y=0;y<torso.getHeight();y++)for(int x=0;x<torso.getWidth();x++)if(Color.alpha(data[y*torso.getWidth()+x])>24){left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);}pieces[3].recycle();pieces[3]=Bitmap.createBitmap(torso,left,top,right-left+1,bottom-top+1);torso.recycle();}
 static void draw(Context context,Canvas canvas,KalleScene.Action a,float phase,boolean right,float turn,int mood,int outfit,int month){draw(context,canvas,a,phase,right,turn,mood,outfit,month,-1,0);}
 static void draw(Context context,Canvas canvas,KalleScene.Action a,float phase,boolean right,float turn,int mood,int outfit,int month,float posture,float lean){SpriteRig rig=new SpriteRig(context,canvas,a,phase,outfit==0?1:outfit);canvas.save();if(!right)canvas.scale(-1,1,83,130);if(a==KalleScene.Action.TURN){turn=Math.max(0,Math.min(1,turn));if(turn>.5f)canvas.scale(-1,1,83,130);canvas.rotate((float)Math.sin(turn*Math.PI)*3,83,249);}boolean lying=a==KalleScene.Action.NAP||a==KalleScene.Action.NEWSPAPER||a==KalleScene.Action.SLEEPING_BAG;if(lying){Matrix rotation=new Matrix();rotation.setRotate(-80,83,130.5f);RectF bound=new RectF(0,0,166,261);rotation.mapRect(bound);float fit=Math.min(150/bound.width(),105/bound.height());canvas.translate(83-bound.centerX()*fit,249-bound.bottom*fit);canvas.scale(fit,fit);canvas.concat(rotation);}if(a==KalleScene.Action.DANCE)canvas.rotate((float)Math.sin(phase)*5,83,249);if(a==KalleScene.Action.YOGA)canvas.rotate((float)Math.sin(phase)*5,83,249);
  canvas.rotate(lean,83,249);float breath=1+.006f*(float)Math.sin(phase);canvas.scale(breath,breath,83,249);rig.person(mood,posture);canvas.restore();}
 void filter(boolean clothing){paint.setColorFilter(clothing&&outfit>=2?new PorterDuffColorFilter(outfit==2?0xffd29c9c:outfit==3?0xffe9cba5:outfit==4?0xff9ba9d2:0xffbea588,PorterDuff.Mode.MULTIPLY):null);}
 void image(int part,float centerX,float top,float height,boolean clothing){Bitmap b=pieces[part];float width=height*b.getWidth()/b.getHeight();filter(clothing);c.drawBitmap(b,null,new RectF(centerX-width/2,top,centerX+width/2,top+height),paint);paint.setColorFilter(null);}
 void segment(int part,float height,boolean clothing){image(part,0,0,height,clothing);}
 PointF arm(boolean left,float shoulderY,float upperAngle,float elbowAngle,boolean upper,boolean lower){float shoulder=left?44:110;int p=left?4:6;float u=37,f=39;c.save();c.translate(shoulder,shoulderY);c.rotate(upperAngle);if(upper)segment(p,u,true);c.translate(0,u-4);c.rotate(elbowAngle);if(lower)segment(p+1,f,true);float[] point={0,f-4};c.getMatrix().mapPoints(point);c.restore();return new PointF(point[0],point[1]);}
 void leg(int part,float x,float hip,float upper,float lower){Bitmap b=pieces[part];float scale=73f/b.getHeight();int split=b.getHeight()/2;float half=split*scale;c.save();c.translate(x,hip);c.rotate(upper);paint.setColorFilter(null);Rect src=new Rect(0,0,b.getWidth(),split);RectF dst=new RectF(-b.getWidth()*scale/2,0,b.getWidth()*scale/2,half);c.drawBitmap(b,src,dst,paint);c.translate(0,half-1);c.rotate(lower);src.set(0,split,b.getWidth(),b.getHeight());dst.set(-b.getWidth()*scale/2,0,b.getWidth()*scale/2,73-half+1);c.drawBitmap(b,src,dst,paint);c.restore();}
 void person(int mood,float posture){boolean walk=action==KalleScene.Action.WALK||action==KalleScene.Action.CART;boolean sit=action==KalleScene.Action.SIT||action==KalleScene.Action.BEG||action==KalleScene.Action.POOL||action==KalleScene.Action.FIRE||action==KalleScene.Action.BBQ;float seated=posture>=0?posture:sit?1:0;float gait=walk?(float)Math.sin(phase)*15:0,hip=176+35*seated;float up=seated>0?-90*seated:gait,up2=seated>0?-90*seated:-gait;float knee=90*seated;
  // Keep the lower planted foot on the ground while the hip follows the gait.
  float compensation=249-(hip+36.5f*(float)Math.cos(Math.toRadians(up))+36.5f*(float)Math.cos(Math.toRadians(up+knee)));c.save();c.translate(0,compensation);leg(8,61,hip,up,knee);leg(9,92,hip,up2,knee);float body=35*seated;
  float left=walk?-gait*.8f:4,right=walk?gait*.35f:-3,el=8,er=4;
  if(action==KalleScene.Action.SMOKE||action==KalleScene.Action.YAWN){right=80;er=100+(float)Math.sin(phase)*5;}
  if(action==KalleScene.Action.BEER){right=65;er=80+(float)(.5+.5*Math.sin(phase))*35;}
  if(action==KalleScene.Action.ANNOY){left=-35;el=-100;right=35;er=100;}
  if(action==KalleScene.Action.BEG){left=-32;el=-35;right=32;er=35;}
  if(action==KalleScene.Action.DANCE){left=-50+(float)Math.sin(phase)*35;right=50-(float)Math.sin(phase)*35;el=-30;er=30;}
  if(action==KalleScene.Action.YOGA){left=155;right=-155;el=10;er=-10;}
  if(action==KalleScene.Action.DRUM){left=-8;right=8;el=-5+(float)Math.sin(phase)*20;er=5-(float)Math.sin(phase)*20;}
  if(action==KalleScene.Action.FIRE||action==KalleScene.Action.BBQ){left=-20;el=-50;right=-10;er=-70;}
  if(action==KalleScene.Action.FISH){right=10;er=75;}
  if(action==KalleScene.Action.SNOWMAN){left=-8;right=-10;el=-55+(float)Math.sin(phase)*20;er=-60-(float)Math.sin(phase)*15;}
  if(action==KalleScene.Action.CART){left=-15;right=15;el=-65;er=65;}
  arm(true,105+body,left,el,true,false);arm(false,105+body,right,er,true,false);
  boolean leftBehind=action==KalleScene.Action.STAND||action==KalleScene.Action.LOOK||walk;
  if(leftBehind)arm(true,105+body,left,el,false,true);
  image(3,79,85+body,106,true);
  if(!leftBehind)arm(true,105+body,left,el,false,true);
  // Right forearm is a single exclusive layer; there is no underlying rest arm.
  boolean raised=action==KalleScene.Action.SMOKE||action==KalleScene.Action.BEER||action==KalleScene.Action.YAWN;if(!raised)arm(false,105+body,right,er,false,true);
  int head=action==KalleScene.Action.YAWN?2:action==KalleScene.Action.ANNOY||mood<-2?11:action==KalleScene.Action.NAP||action==KalleScene.Action.NEWSPAPER||action==KalleScene.Action.SLEEPING_BAG||action==KalleScene.Action.YOGA?1:0;
  c.save();if(action==KalleScene.Action.LOOK)c.rotate((float)Math.sin(phase)*5,80,91+body);image(head,79,4+body,96,false);c.restore();
  if(raised)arm(false,105+body,right,er,false,true);
  c.save();c.translate(110,105+body);c.rotate(right);c.translate(0,33);c.rotate(er);c.translate(0,35);
  if(action==KalleScene.Action.BEER){ink.setColor(0xff7a4b24);c.drawRoundRect(-6,-12,6,13,2,2,ink);ink.setColor(0xffd7b56d);c.drawRect(-5,-2,5,7,ink);ink.setColor(0xff413c27);c.drawRect(-3,-20,3,-10,ink);}
  if(action==KalleScene.Action.SMOKE){ink.setColor(0xffe9dfc7);ink.setStrokeWidth(2);c.drawLine(-2,0,-15,0,ink);ink.setColor(0x779d9d9d);for(int i=0;i<3;i++)c.drawCircle(-15+i*2,-7-i*6+(float)Math.sin(phase+i)*2,2+i,ink);}
  if(action==KalleScene.Action.FISH){ink.setColor(0xff9b7641);ink.setStrokeWidth(2);c.drawLine(0,0,-8,-65,ink);ink.setColor(0xffbebca6);ink.setStrokeWidth(.7f);c.drawLine(-8,-65,-10,30,ink);}
  c.restore();
  boolean bag=action==KalleScene.Action.STAND||action==KalleScene.Action.LOOK||walk||action==KalleScene.Action.TURN;
  if(bag&&action!=KalleScene.Action.CART){c.save();c.translate(110,105+body);c.rotate(right);c.translate(0,33);c.rotate(er);image(10,13,25,70,false);c.restore();}
  c.restore();
 }
}
