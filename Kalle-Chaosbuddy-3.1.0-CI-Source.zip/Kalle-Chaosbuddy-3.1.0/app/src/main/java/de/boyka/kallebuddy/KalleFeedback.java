package de.boyka.kallebuddy;
import android.app.*;
import android.content.*;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

final class KalleFeedback {
    static String message(Mission m){String day=Stats.sameDay(m.start,System.currentTimeMillis())?"heute":new java.text.SimpleDateFormat("dd.MM.yyyy",Locale.GERMANY).format(new Date(m.start));String time=new java.text.SimpleDateFormat("HH:mm",Locale.GERMANY).format(new Date(m.start));String line="Ist eingetragen, Digga: "+m.title+" – "+day+" um "+time+" Uhr. ";if(!m.note.isEmpty())line+="Denk dran: "+(m.note.length()>80?m.note.substring(0,77)+"…":m.note);else line+="Den verdammten Auftrag hast du jetzt auf dem Zettel.";return line;}
    static void confirm(Activity a,Mission m,boolean close){String line=message(m);
        LinearLayout box=Ui.row(a);Ui.pad(box,14);box.setGravity(Gravity.CENTER_VERTICAL);box.addView(new CoachView(a),new LinearLayout.LayoutParams(Ui.dp(a,90),Ui.dp(a,150)));LinearLayout speech=Ui.column(a);Ui.pad(speech,15);speech.setBackground(Ui.shape(0xfff3e8cd,Ui.dp(a,14)));speech.addView(Ui.bold(a,"MISSION EINGETRAGEN",11,0xff796541));Ui.gap(speech,5);speech.addView(Ui.bold(a,m.title,22,0xff1e2424));Ui.gap(speech,7);speech.addView(Ui.bold(a,line,15,0xff1e2424));box.addView(speech,new LinearLayout.LayoutParams(0,-2,1));ScrollView scroll=new ScrollView(a);scroll.addView(box);
        AlertDialog d=new AlertDialog.Builder(a).setView(scroll).setPositiveButton("Alles klar, Kalle",null).create();if(close)d.setOnDismissListener(v->a.finish());d.show();
    }
}
