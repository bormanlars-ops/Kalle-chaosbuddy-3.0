package de.boyka.kallebuddy;
import android.content.*;
public final class BootReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){SettingsMigration.run(c);CompanionService.resetTracker();if(Intent.ACTION_TIMEZONE_CHANGED.equals(i.getAction()))Store.timezoneChanged(c);Scheduler.reconcile(c);KalleWidget.updateAll(c);}}
