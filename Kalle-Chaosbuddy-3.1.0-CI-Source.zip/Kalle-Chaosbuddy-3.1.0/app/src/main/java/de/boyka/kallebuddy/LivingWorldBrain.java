package de.boyka.kallebuddy;

import java.util.*;

/** Pure-Java event choices. Widget presentation is still launcher-owned RemoteViews. */
final class LivingWorldBrain {
    enum Daypart { MORNING, DAY, EVENING, NIGHT }
    static Daypart period(int hour) {
        if (hour<0||hour>23)throw new IllegalArgumentException("hour");
        return hour>=23||hour<6?Daypart.NIGHT:hour<10?Daypart.MORNING:hour<18?Daypart.DAY:Daypart.EVENING;
    }
    static final class Choice {
        final KalleScene.Action[] actions;final String event;
        Choice(KalleScene.Action[] actions,String event){this.actions=actions;this.event=event;}
    }
    static Choice plan(int hour,int energy,int mood,boolean missionOverdue,boolean missionSoon,int doneToday,boolean allTodayDone,
                       KalleScene.Action first,long now,long lastEaster,long seed) {
        Random rng=new Random(seed);Daypart part=period(hour);
        KalleScene.Action[] pool;
        switch(part){
            case MORNING: pool=new KalleScene.Action[]{KalleScene.Action.YAWN,KalleScene.Action.WALK,KalleScene.Action.LOOK,KalleScene.Action.STAND,KalleScene.Action.TENT,KalleScene.Action.SIT};break;
            case EVENING:pool=new KalleScene.Action[]{KalleScene.Action.FIRE,KalleScene.Action.SIT,KalleScene.Action.NEWSPAPER,KalleScene.Action.WALK,KalleScene.Action.LOOK,KalleScene.Action.TENT};break;
            case NIGHT:pool=new KalleScene.Action[]{KalleScene.Action.TENT,KalleScene.Action.NAP,KalleScene.Action.SLEEPING_BAG,KalleScene.Action.SIT,KalleScene.Action.YAWN,KalleScene.Action.LOOK};break;
            default:pool=new KalleScene.Action[]{KalleScene.Action.WALK,KalleScene.Action.LOOK,KalleScene.Action.STAND,KalleScene.Action.SIT,KalleScene.Action.NEWSPAPER,KalleScene.Action.CART,KalleScene.Action.SMOKE,KalleScene.Action.BEER};
        }
        if(energy<25)pool=new KalleScene.Action[]{KalleScene.Action.YAWN,KalleScene.Action.SIT,KalleScene.Action.NAP,KalleScene.Action.TENT,KalleScene.Action.LOOK};
        if(missionOverdue||missionSoon)first=KalleScene.Action.LOOK;
        else if(allTodayDone&&doneToday>0)first=KalleScene.Action.DANCE;
        else if(energy<25)first=KalleScene.Action.YAWN;
        else if(mood<20)first=KalleScene.Action.SIT;
        else if(part==Daypart.NIGHT)first=KalleScene.Action.TENT;
        else if(first==null)first=KalleScene.Action.WALK;
        KalleScene.Action[] actions=new KalleScene.Action[8];actions[0]=first;
        for(int i=1;i<actions.length;i++){
            KalleScene.Action next=pool[rng.nextInt(pool.length)];
            int retry=0;while(next==actions[i-1]&&retry++<12)next=pool[rng.nextInt(pool.length)];
            actions[i]=next;
        }
        String event=null;
        // Rare local Easter eggs, at most once in 8 hours; never emit a notification.
        if(now-lastEaster>=8L*3600000&&rng.nextInt(14)==0){
            switch(rng.nextInt(5)){
                case 0:actions[1]=KalleScene.Action.NAP;event="Ich wollte nur fünf Minuten die Augen zumachen. War wohl gestern.";break;
                case 1:actions[1]=KalleScene.Action.LOOK;event="Die Uhr geht doch falsch. Anders kann ich mir den Tag nicht erklären.";break;
                case 2:actions[1]=KalleScene.Action.TURN;event="Fast hingeflogen. Der Boden hat angefangen, nicht ich.";break;
                case 3:actions[1]=KalleScene.Action.SIT;event="Der Stuhl hat mich angegriffen. War Notwehr, dass ich sitzen bleibe.";break;
                default:actions[1]=KalleScene.Action.TENT;event="Immobilienpreise sind krank. Ich überleg, das Zelt unterzuvermieten.";break;
            }
        }
        return new Choice(actions,event);
    }
}
