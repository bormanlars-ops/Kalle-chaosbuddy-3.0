package de.boyka.kallebuddy;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.*;

/** Conservative, offline German one-off mission parsing. Does not save anything. */
final class MissionCommandParser {
    static final class Result {
        final String title, note, error;
        final LocalDateTime dateTime;
        private Result(String title, String note, LocalDateTime dateTime, String error) {
            this.title=title; this.note=note; this.dateTime=dateTime; this.error=error;
        }
        static Result fail(String message) { return new Result("", "", null, message); }
        boolean valid() { return error==null; }
        long millis(ZoneId zone) {
            if (!valid() || zone.getRules().getValidOffsets(dateTime).size()!=1)
                throw new IllegalArgumentException("Diese Ortszeit ist wegen der Zeitumstellung uneindeutig oder existiert nicht.");
            return dateTime.atZone(zone).toInstant().toEpochMilli();
        }
    }
    private static final Pattern DAY = Pattern.compile("(?iuU)\\b(übermorgen|uebermorgen|morgen|heute|am\\s+\\d{1,2}\\.\\d{1,2}(?:\\.\\d{4})?\\.?|(?:am\\s+)?(?:montag|dienstag|mittwoch|donnerstag|freitag|samstag|sonntag))\\b");
    private static final Pattern TIME = Pattern.compile("(?iuU)\\b(?:um\\s+)?((?:[01]?\\d|2[0-3]))(?::([0-5]\\d)\\s*(?:uhr)?|\\s*uhr)\\b");
    private static final Pattern REMINDER = Pattern.compile("(?iu)\\s+und\\s+((?:die|den|das|eine|einen|ein|meine|meinen|mein)\\s+.{2,110}?\\s+mitnehmen)\\s*$");
    private static final String[] WEEKDAYS={"montag","dienstag","mittwoch","donnerstag","freitag","samstag","sonntag"};
    static Result parse(String raw, LocalDateTime now) {
        if(raw==null || raw.trim().isEmpty())return Result.fail("Bitte einen Befehl eingeben.");
        if(raw.length()>350)return Result.fail("Befehl zu lang. Bitte kürzer formulieren.");
        String input=raw.trim().replaceAll("\\s+"," ").replaceFirst("(?iu)^kalle[,:!]?\\s*", "");
        Matcher d=DAY.matcher(input), t=TIME.matcher(input);
        if(!d.find())return Result.fail("Datum fehlt. Zum Beispiel: morgen um 16:30 einkaufen.");
        String dayToken=d.group(1).toLowerCase(Locale.GERMAN);int dayStart=d.start(),dayEnd=d.end();
        if(d.find())return Result.fail("Mehrere Datumsangaben. Bitte genau einen Termin nennen.");
        if(!t.find())return Result.fail("Uhrzeit fehlt. Zum Beispiel: um 16:30 oder um 16 Uhr.");
        int hour=Integer.parseInt(t.group(1)),minute=t.group(2)==null?0:Integer.parseInt(t.group(2));int timeStart=t.start(),timeEnd=t.end();
        if(t.find())return Result.fail("Mehrere Uhrzeiten. Bitte genau eine Uhrzeit nennen.");
        if(Math.max(dayStart,timeStart)<Math.min(dayEnd,timeEnd))return Result.fail("Datum und Uhrzeit nicht eindeutig erkannt.");
        LocalDate date=now.toLocalDate();
        if(dayToken.equals("heute")){}
        else if(dayToken.equals("morgen"))date=date.plusDays(1);
        else if(dayToken.equals("übermorgen")||dayToken.equals("uebermorgen"))date=date.plusDays(2);
        else if(dayToken.startsWith("am ")&&dayToken.matches("am\\s+\\d.*")) {
            String value=dayToken.substring(3).trim().replaceAll("\\.$","");
            String[] parts=value.split("\\.");
            try {
                int dd=Integer.parseInt(parts[0]),mm=Integer.parseInt(parts[1]);
                if(parts.length==3)date=LocalDate.of(Integer.parseInt(parts[2]),mm,dd);
                else{date=LocalDate.of(now.getYear(),mm,dd);if(date.isBefore(now.toLocalDate()))return Result.fail("Das Datum liegt zurück. Bitte das Jahr ausdrücklich angeben.");}
            }catch(DateTimeException|NumberFormatException e){return Result.fail("Ungültiges Datum. Beispiel: am 12.11.2026.");}
        } else {
            String weekday=dayToken.replaceFirst("^am\\s+","");int index=Arrays.asList(WEEKDAYS).indexOf(weekday);
            if(index<0)return Result.fail("Wochentag nicht erkannt.");
            int diff=(index+1-date.getDayOfWeek().getValue()+7)%7;
            // Same weekday without 'heute' means the next occurrence, not an elapsed event.
            date=date.plusDays(diff==0?7:diff);
        }
        LocalDateTime due=date.atTime(hour,minute);
        if(!due.isAfter(now))return Result.fail("Die Uhrzeit liegt in der Vergangenheit. Bitte einen zukünftigen Termin wählen.");
        StringBuilder clean=new StringBuilder(input);
        int[] starts={dayStart,timeStart},ends={dayEnd,timeEnd};
        if(starts[0]<starts[1]){clean.delete(starts[1],ends[1]);clean.delete(starts[0],ends[0]);}
        else {clean.delete(starts[0],ends[0]);clean.delete(starts[1],ends[1]);}
        String text=clean.toString().replaceFirst("(?iu)^\\s*(?:bitte|ich muss|ich möchte|erinnere mich(?: daran)?(?:,)?(?: dass ich)?|muss)\\s+","")
                .replaceAll("(?iu)^\\s*(?:,|:|und)\\s*","").replaceAll("(?iu)[.,;! ]+$","").trim();
        Matcher rem=REMINDER.matcher(text);String note="";
        if(rem.find()){note=rem.group(1).trim();text=text.substring(0,rem.start()).trim();}
        text=text.replaceAll("(?iu)^\\s*(?:zum|zur|für)\\s+","").trim();
        if(text.length()<3||text.length()>120)return Result.fail("Mission nicht eindeutig erkannt. Bitte Titel und Uhrzeit klar angeben.");
        if(text.toLowerCase(Locale.GERMAN).contains(" oder "))return Result.fail("Mehrdeutige Aufgabe. Bitte genau eine Mission nennen.");
        return new Result(Character.toUpperCase(text.charAt(0))+text.substring(1),note,due,null);
    }
}
