package de.boyka.kallebuddy;
import android.content.*;
final class Needs{
 static int clamp(int n){return Math.max(0,Math.min(100,n));}static int toward(int n,int steps){return n<65?Math.min(65,n+steps):Math.max(65,n-steps);}
 static synchronized void normalize(Context c){SharedPreferences p=Store.prefs(c);long now=System.currentTimeMillis(),last=p.getLong("needsAt",now);int step=(int)Math.min(100,Math.max(0,now-last)/1200000L);if(!p.contains("needsAt")||step>0||last>now)p.edit().putInt("mood",toward(p.getInt("mood",65),step)).putInt("energy",toward(p.getInt("energy",65),step*2)).putLong("needsAt",step>0?now-Math.max(0,now-last)%1200000L:now).commit();}
 static int mood(Context c){normalize(c);return Store.prefs(c).getInt("mood",65);}static int energy(Context c){normalize(c);return Store.prefs(c).getInt("energy",65);}static void change(Context c,int mood,int energy){normalize(c);Store.prefs(c).edit().putInt("mood",clamp(mood(c)+mood)).putInt("energy",clamp(energy(c)+energy)).commit();}
}
