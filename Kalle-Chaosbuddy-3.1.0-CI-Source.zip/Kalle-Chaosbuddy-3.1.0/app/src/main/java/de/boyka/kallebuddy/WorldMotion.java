package de.boyka.kallebuddy;
import android.graphics.*;
/** Pure geometry. All places are ground coordinates in the existing 256 x 160 scene. */
final class WorldMotion{
 static final int SCENES=4,STEPS=64,TOTAL=SCENES*STEPS;
 enum Phase{APPROACH,SETTLE,USE,RISE,LEAVE}
 static final class Frame{
  KalleScene.Action activity,pose;Phase phase;float x,y,height,posture=0,lean=0,alpha=1,turn=0;boolean right=true,front=false,seat=false;RectF actor,prop;int spriteStep;
 }
 static float smooth(float t){t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);}
 static PointF mix(PointF a,PointF b,float t){t=smooth(t);return new PointF(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t);}
 static boolean object(KalleScene.Action a){switch(a){case TENT:case FIRE:case BBQ:case SIT:case BEG:case POOL:case NEWSPAPER:case SLEEPING_BAG:case YOGA:case DRUM:case FISH:case UMBRELLA:case SNOWMAN:case CART:return true;default:return false;}}
 static boolean seated(KalleScene.Action a){return a==KalleScene.Action.SIT||a==KalleScene.Action.BEG||a==KalleScene.Action.POOL||a==KalleScene.Action.FIRE||a==KalleScene.Action.BBQ;}
 static RectF prop(KalleScene.Action a){switch(a){case TENT:return new RectF(153,72,233,133);case FIRE:case BBQ:return new RectF(174,100,219,147);case POOL:return new RectF(140,119,233,147);case UMBRELLA:return new RectF(164,16,234,146);case SNOWMAN:return new RectF(168,88,214,145);case YOGA:return new RectF(127,136,213,147);case NEWSPAPER:case SLEEPING_BAG:return new RectF(130,117,207,148);case DRUM:return new RectF(180,113,209,146);case FISH:return new RectF(196,122,219,148);case CART:return new RectF(174,108,222,148);default:return new RectF(145,112,188,148);}}
 static Frame at(KalleScene.Action a,int scene,int step,int size){return at(a,scene,step,size,new PointF(57,149));}
 static Frame at(KalleScene.Action a,int scene,int step,int size,PointF origin){return at(a,scene,step,size,origin,100,98);}
 static Frame at(KalleScene.Action a,int scene,int step,int size,PointF origin,int range,int baseline){Frame f=new Frame();f.activity=a;int j=Math.max(0,Math.min(63,step));PointF[] anchors={origin,new PointF(185,114),new PointF(201,148),new PointF(78,119),origin};for(int k=1;k<4;k++){anchors[k].x=128+(anchors[k].x-128)*Math.max(25,Math.min(100,range))/100f;anchors[k].y=Math.max(114,anchors[k].y-18*(98-Math.max(0,Math.min(98,baseline)))/98f);}PointF start=anchors[scene%4],end=anchors[scene%4+1];f.prop=object(a)?prop(a):null;
  PointF target=f.prop==null?mix(start,end,.5f):a==KalleScene.Action.TENT?new PointF(178,137):a==KalleScene.Action.FIRE||a==KalleScene.Action.BBQ?new PointF(153,143):a==KalleScene.Action.POOL?new PointF(183,142):a==KalleScene.Action.UMBRELLA?new PointF(198,143):a==KalleScene.Action.DRUM?new PointF(192,140):a==KalleScene.Action.YOGA||a==KalleScene.Action.NEWSPAPER||a==KalleScene.Action.SLEEPING_BAG?new PointF(165,143):new PointF(158,145);
  PointF position;
  if(a==KalleScene.Action.WALK){f.phase=Phase.APPROACH;position=mix(start,end,j/63f);f.pose=KalleScene.Action.WALK;f.right=end.x>=start.x;}
  else if(j<16){f.phase=Phase.APPROACH;position=mix(start,target,j/15f);f.pose=KalleScene.Action.WALK;f.right=target.x>=start.x;}
  else if(j<24){f.phase=Phase.SETTLE;position=target;f.posture=seated(a)||a==KalleScene.Action.TENT?smooth((j-16)/7f):0;f.pose=seated(a)?a:a==KalleScene.Action.TENT?KalleScene.Action.SIT:a;}
  else if(j<44){f.phase=Phase.USE;position=target;f.posture=seated(a)||a==KalleScene.Action.TENT?1:0;f.pose=a;}
  else if(j<48){f.phase=Phase.RISE;position=target;f.posture=seated(a)||a==KalleScene.Action.TENT?1-smooth((j-44)/3f):0;f.pose=seated(a)?a:a==KalleScene.Action.TENT?KalleScene.Action.SIT:a;}
  else{f.phase=Phase.LEAVE;position=mix(target,end,(j-48)/15f);f.pose=KalleScene.Action.WALK;f.right=end.x>=target.x;}
  if(a==KalleScene.Action.TENT&&j>=16&&j<48){float enter=j<24?smooth((j-16)/7f):j<44?1:1-smooth((j-44)/3f);position=new PointF(target.x+15*enter,target.y-7*enter);f.lean=25*enter;f.alpha=1-enter;if(j>=24&&j<44)f.pose=KalleScene.Action.NAP;}
  f.x=position.x;f.y=position.y;float scale=.55f+.45f*(f.y-114)/36f;f.height=Math.min(f.y-5,112*Math.max(60,Math.min(160,size))/100f*scale);float w=f.height*166/261f;f.x=Math.max(w/2+3,Math.min(253-w/2,f.x));float top=f.y-249*f.height/261f;f.actor=new RectF(f.x-w/2,top,f.x+w/2,top+f.height);
  if((a==KalleScene.Action.WALK&&end.x<start.x&&j<3)||(a!=KalleScene.Action.WALK&&end.x<target.x&&j>=45&&j<48)){f.pose=KalleScene.Action.TURN;f.right=true;}
  f.front=f.prop!=null&&f.prop.bottom>=f.y;if((a==KalleScene.Action.SIT||a==KalleScene.Action.BEG||a==KalleScene.Action.YOGA)&&j>=16&&j<48)f.front=false;f.seat=(a==KalleScene.Action.FIRE||a==KalleScene.Action.BBQ);f.spriteStep=f.pose==KalleScene.Action.TURN&&a!=KalleScene.Action.TURN?(j<3?j:j-45):(f.pose==KalleScene.Action.WALK?j%16:j%8);if(f.pose==KalleScene.Action.TURN)f.turn=a==KalleScene.Action.TURN?(float)(.5-.5*Math.cos(j*Math.PI/8)):f.spriteStep/2f;return f;
 }
}
