package de.boyka.kallebuddy;
import android.content.*;import android.graphics.*;import android.text.*;import java.util.*;
/** Pre-rendered poses; only native ViewFlipper in the launcher advances frames. */
final class WidgetRenderer{
 static final int WIDTH=256,HEIGHT=160,FRAMES=32,BACKGROUND=0xff13251d;
 static final android.util.LruCache<String,Bitmap[]> CACHE=new android.util.LruCache<>(4);
 private static Bitmap sceneBackground;
 private static final Paint BACKGROUND_PAINT=new Paint(Paint.FILTER_BITMAP_FLAG);
 static void drawBackground(Context c,Canvas canvas,int width,int height){
  if(sceneBackground==null){BitmapFactory.Options options=new BitmapFactory.Options();options.inScaled=false;options.inSampleSize=4;sceneBackground=BitmapFactory.decodeResource(c.getResources(),R.drawable.widget_scene_background,options);}
  float scale=Math.max(width/(float)sceneBackground.getWidth(),height/(float)sceneBackground.getHeight());
  float w=sceneBackground.getWidth()*scale,h=sceneBackground.getHeight()*scale;
  canvas.drawBitmap(sceneBackground,null,new RectF((width-w)/2,(height-h)/2,(width+w)/2,(height+h)/2),BACKGROUND_PAINT);
 }
 static final class Pose{final float x,turn;final boolean right,moving;final KalleScene.Action action;Pose(float x,boolean right,boolean move,KalleScene.Action a,float turn){this.x=x;this.right=right;moving=move;action=a;this.turn=turn;}}
 static Pose pose(KalleScene.Action a,int frame){int i=Math.floorMod(frame,FRAMES);if(a!=KalleScene.Action.WALK&&a!=KalleScene.Action.CART)return new Pose(.5f,true,false,a,a==KalleScene.Action.TURN?(float)(.5-.5*Math.cos(i*Math.PI*2/FRAMES)):0);
  if(i<3)return new Pose(0,true,false,KalleScene.Action.STAND,0);
  if(i<14)return new Pose((i-3)/10f,true,true,a,0);
  if(i<18)return new Pose(1,true,false,KalleScene.Action.TURN,(i-14)/3f);
  if(i<30)return new Pose((29-i)/11f,false,true,a,0);
  return new Pose(0,false,false,KalleScene.Action.TURN,(i-29)/3f);
 }
 static RectF bounds(Context c,Pose p){SharedPreferences s=Store.prefs(c);float h=Math.min(HEIGHT-12,Math.max(48,(HEIGHT-12)*.76f*s.getInt("kalleSize",100)/100f)),w=h*CoachView.ART_WIDTH/CoachView.ART_HEIGHT,range=Math.max(0,Math.min(100,s.getInt("range",100)))/100f,available=WIDTH-12-w;float x=6+available*(1-range)/2+available*range*p.x,y=6+(HEIGHT-12-h)*Math.max(0,Math.min(100,s.getInt("baseline",98)))/100f;return new RectF(x,y,x+w,y+h);}
 static Bitmap[] frames(Context c,int id,boolean still){return framesFor(c,WidgetState.action(c,id),still);}
 static int[] resolution(Context c){android.util.DisplayMetrics d=c.getResources().getDisplayMetrics();long budget=Math.min(8000000L,(long)(d.widthPixels*d.heightPixels*6*.70));double scale=Math.min(1,Math.sqrt(budget/(80.0*WIDTH*HEIGHT*2)));return new int[]{Math.max(48,(int)(WIDTH*scale)),Math.max(30,(int)(HEIGHT*scale))};}
 static Bitmap[] framesFor(Context c,KalleScene.Action action,boolean still){if(!WidgetState.allowed(c,action))action=KalleScene.Action.WALK;SharedPreferences s=Store.prefs(c);int mood=Needs.mood(c)/10-5,month=Calendar.getInstance().get(Calendar.MONTH),outfit=s.getInt("kalleOutfit",0);boolean closed=action==KalleScene.Action.TENT;int[] size=resolution(c);
  String key=action+":"+still+":"+WidgetState.enabled(c)+":"+mood+":"+month+":"+outfit+":"+closed+":"+s.getInt("kalleSize",100)+":"+s.getInt("range",100)+":"+s.getInt("baseline",98)+":"+size[0]+":"+size[1];Bitmap[] found=CACHE.get(key);if(found!=null)return found;int count=still?1:action==KalleScene.Action.WALK||action==KalleScene.Action.CART?32:16;Bitmap[] result=new Bitmap[count];
  for(int i=0;i<result.length;i++){Bitmap bitmap=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.RGB_565);Canvas canvas=new Canvas(bitmap);drawBackground(c,canvas,size[0],size[1]);canvas.scale(size[0]/(float)WIDTH,size[1]/(float)HEIGHT);if(WidgetState.enabled(c)){Pose pose=pose(action,action==KalleScene.Action.WALK||action==KalleScene.Action.CART?i:i*2);RectF box=bounds(c,pose);CoachView view=new CoachView(c);view.layout(0,0,(int)CoachView.ART_WIDTH,(int)CoachView.ART_HEIGHT);view.scene(pose.action,mood,outfit,month,closed);view.transition=-10000;view.turnProgress=pose.turn;view.walk(pose.moving,pose.moving?i*.8f:(float)(i*Math.PI*2/Math.max(1,count)),pose.right);canvas.save();canvas.translate(box.left,box.top);float scale=box.width()/CoachView.ART_WIDTH;canvas.scale(scale,scale);view.draw(canvas);canvas.restore();}result[i]=bitmap;}CACHE.put(key,result);return result;
 }
 static int interval(Context c){if(Store.prefs(c).getBoolean("powerSave",false)||Needs.energy(c)<30)return 200;int speed=Store.prefs(c).getInt("speed",40);return speed>=60?100:speed<30?200:125;}
 static final class Caption{final String text;final float sp;final boolean shortened;Caption(String t,float s,boolean cut){text=t;sp=s;shortened=cut;}}
 static StaticLayout layout(String t,TextPaint p,int width){return StaticLayout.Builder.obtain(t,0,t.length(),p,Math.max(1,width)).setIncludePad(false).setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY).build();}
 static Caption caption(Context c,String full,int widthDp,int heightDp){float density=c.getResources().getDisplayMetrics().density,scaled=c.getResources().getDisplayMetrics().scaledDensity;int width=Math.max(40,(int)((widthDp-40)*density)),height=Math.max(20,(int)((heightDp-12)*density));TextPaint p=new TextPaint(Paint.ANTI_ALIAS_FLAG);float sp=Math.min(20,Math.max(11,Store.prefs(c).getInt("bubbleFont",24)*.75f));while(sp>11){p.setTextSize(sp*scaled);if(layout(full,p,width).getHeight()<=height)return new Caption(full,sp,false);sp--;}p.setTextSize(sp*scaled);if(layout(full,p,width).getHeight()<=height)return new Caption(full,sp,false);String suffix=" … Tippen";int low=0,high=full.length();while(low<high){int mid=(low+high+1)/2;if(layout(full.substring(0,mid)+suffix,p,width).getHeight()<=height)low=mid;else high=mid-1;}if(low>0&&Character.isHighSurrogate(full.charAt(low-1)))low--;return new Caption(full.substring(0,low).trim()+suffix,sp,true);}
}
