package de.boyka.kallebuddy;
import android.content.*;import java.util.*;
/** A varied, preselected program is advanced by the launcher, never app background ticks. */
final class WidgetStory{
 static final int SCENES=8;
 static KalleScene.Action[] select(Context c,int id,Calendar day){long epoch=System.currentTimeMillis()/1800000;String stored=WidgetState.prefs(c).getString(WidgetState.key(id,"program"),"");long until=WidgetState.prefs(c).getLong(WidgetState.key(id,"programUntil"),0);String context=day.get(Calendar.HOUR_OF_DAY)/3+":"+LivingWorldBrain.period(day.get(Calendar.HOUR_OF_DAY))+":"+(Needs.energy(c)<30)+":"+(Needs.mood(c)<30?0:Needs.mood(c)>=70?2:1)+":"+(System.currentTimeMillis()<WidgetState.prefs(c).getLong(WidgetState.key(id,"attentionUntil"),0)?WidgetState.action(c,id):"auto");if(context.equals(WidgetState.prefs(c).getString(WidgetState.key(id,"programContext"),""))&&System.currentTimeMillis()<until){String[] names=stored.split(",");if(names.length==SCENES){KalleScene.Action[] result=new KalleScene.Action[SCENES];boolean valid=true;for(int i=0;i<SCENES;i++)try{result[i]=KalleScene.Action.valueOf(names[i]);valid&=WidgetState.allowed(c,result[i]);}catch(IllegalArgumentException e){valid=false;}if(valid)return result;}}
  long now=System.currentTimeMillis();int hour=day.get(Calendar.HOUR_OF_DAY),energy=Needs.energy(c),mood=Needs.mood(c);
  int planned=0,completed=0;boolean overdue=false,missionSoon=false;String today=java.time.LocalDate.now().toString();
  for(Mission m:Store.all(c)){
   if(m.dueDay().equals(today)){planned++;if(m.completed())completed++;}
   if(m.state.equals("overdue")||m.state.equals("waiting")||m.state.equals("scheduled")&&m.reminder()<=now)overdue=true;
   if(m.state.equals("scheduled")&&m.reminder()>now&&m.reminder()<=now+3600000L)missionSoon=true;
  }
  boolean immediate=now<WidgetState.prefs(c).getLong(WidgetState.key(id,"attentionUntil"),0);
  KalleScene.Action first=immediate?WidgetState.action(c,id):null;
  long lastEaster=WidgetState.prefs(c).getLong(WidgetState.key(id,"lastEaster"),0);
  LivingWorldBrain.Choice choice=LivingWorldBrain.plan(hour,energy,mood,overdue,missionSoon,completed,planned>0&&completed==planned,first,now,lastEaster,epoch*107+id*31L);
  KalleScene.Action[] result=choice.actions;
  boolean showEvent=choice.event!=null&&WidgetState.allowed(c,choice.actions[1]);
  for(int i=0;i<result.length;i++)if(!WidgetState.allowed(c,result[i]))result[i]=i>0?result[i-1]:KalleScene.Action.WALK;
  if(showEvent){
   WidgetState.prefs(c).edit().putLong(WidgetState.key(id,"lastEaster"),now).putString(WidgetState.key(id,"text"),choice.event).commit();
   WorldSpeech.event(c,id);
  }
  StringBuilder names=new StringBuilder();for(KalleScene.Action a:result){if(names.length()>0)names.append(',');names.append(a.name());}
  WidgetState.prefs(c).edit().putString(WidgetState.key(id,"programContext"),context).putString(WidgetState.key(id,"program"),names.toString()).putLong(WidgetState.key(id,"programUntil"),now+1800000).commit();return result;
 }
 static void invalidate(Context c,int id){WidgetState.prefs(c).edit().remove(WidgetState.key(id,"programUntil")).commit();}
}
