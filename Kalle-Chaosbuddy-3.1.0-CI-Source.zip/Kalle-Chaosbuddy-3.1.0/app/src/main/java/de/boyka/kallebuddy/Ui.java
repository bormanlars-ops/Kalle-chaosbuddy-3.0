package de.boyka.kallebuddy;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

final class Ui {
    static final int BG=Color.rgb(11,12,14), CARD=Color.rgb(27,29,32), FG=Color.rgb(247,247,242), MUTED=Color.rgb(156,161,165), GREEN=Color.rgb(121,204,92), RED=Color.rgb(255,155,137);
    static final int BLUE=Color.rgb(100,185,242);
    static final int YELLOW=Color.rgb(240,190,76);
    static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    static TextView heavy(Context c,String s,int size,int color){TextView t=text(c,s,size,color);t.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));t.setShadowLayer(1,1,2,Color.BLACK);return t;}
    static int dp(Context c,float n){return (int)(n*c.getResources().getDisplayMetrics().density+.5f);}
    static GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    static TextView text(Context c,String s,int size,int color){TextView t=new TextView(c);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("tnum");return t;}
    static TextView bold(Context c,String s,int size,int color){TextView t=text(c,s,size,color);t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;}
    static void gap(LinearLayout l,int height){View v=new View(l.getContext());l.addView(v,new LinearLayout.LayoutParams(1,dp(l.getContext(),height)));}
    static void pad(View v,int n){int d=dp(v.getContext(),n);v.setPadding(d,d,d,d);}
    static TextView button(Context c,String label,boolean primary,Runnable click){
        TextView t=bold(c,label,16,primary?BG:FG);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(c,54));t.setPadding(dp(c,16),dp(c,10),dp(c,16),dp(c,10));t.setBackground(shape(primary?YELLOW:Color.rgb(45,47,50),dp(c,5)));t.setOnClickListener(v->click.run());t.setContentDescription(label);return t;
    }
    static TextView accentButton(Context c,String label,int accent,Runnable click){TextView t=button(c,label,true,click);t.setBackground(shape(accent,dp(c,6)));return t;}
    static class MissionBackdrop extends android.graphics.drawable.Drawable {
        final Paint p=new Paint(3);final int accent;
        MissionBackdrop(int color){accent=color;}
        public void draw(Canvas c){Rect r=getBounds();p.setColor(CARD);c.drawRect(r,p);c.save();c.clipRect(r);
            p.setColor(Color.argb(12,Color.red(accent),Color.green(accent),Color.blue(accent)));
            Path a=new Path();a.moveTo(r.right-r.width()*.48f,r.top);a.lineTo(r.right,r.top);a.lineTo(r.right,r.bottom);a.lineTo(r.right-r.width()*.8f,r.bottom);a.close();c.drawPath(a,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(0x122fffff);
            for(int i=-r.height();i<r.width();i+=64)c.drawLine(r.left+i,r.top,r.left+i+r.height(),r.bottom,p);
            p.setStyle(Paint.Style.FILL);p.setColor(accent);c.drawRect(r.left,r.top,r.left+3,r.bottom,p);c.restore();
        }
        public void setAlpha(int a){}public void setColorFilter(ColorFilter f){}public int getOpacity(){return PixelFormat.OPAQUE;}
    }
    static class YearChart extends View {
        final Stats stats;final Paint p=new Paint(3);
        YearChart(Context c,Stats s){super(c);stats=s;setContentDescription("Jahresaktivität "+s.year+": "+s.done+" erledigte Missionen an "+s.activeDays+" Tagen");}
        protected void onDraw(Canvas canvas){
            java.util.Calendar date=java.util.Calendar.getInstance();date.clear();date.set(stats.year,0,1);
            int offset=(date.get(java.util.Calendar.DAY_OF_WEEK)+5)%7;
            int count=date.getActualMaximum(java.util.Calendar.DAY_OF_YEAR),cols=(offset+count+6)/7;
            float step=getWidth()/(float)cols,cell=Math.max(1,step-1.5f),top=dp(getContext(),25);
            p.setTypeface(Typeface.create("sans-serif",0));p.setTextSize(dp(getContext(),9));p.setTextAlign(Paint.Align.LEFT);
            String[] month={"J","F","M","A","M","J","J","A","S","O","N","D"};
            for(int d=0;d<count;d++){
                int v=stats.activity.getOrDefault(Stats.dayKey(date.getTimeInMillis()),0),x=(offset+d)/7,y=(offset+d)%7;
                if(date.get(java.util.Calendar.DAY_OF_MONTH)==1){p.setColor(MUTED);canvas.drawText(month[date.get(java.util.Calendar.MONTH)],x*step,dp(getContext(),13),p);}
                p.setColor(v==0?0xff303336:v==1?0xff365841:v<=3?0xff598e50:GREEN);
                canvas.drawRoundRect(x*step,top+y*dp(getContext(),11),x*step+cell,top+y*dp(getContext(),11)+dp(getContext(),9),1,1,p);date.add(java.util.Calendar.DATE,1);
            }
        }
    }
    static class MonthChart extends View {
        final Stats s;final Paint p=new Paint(3);
        MonthChart(Context c,Stats stats){super(c);s=stats;setContentDescription("Monatsdiagramm: "+Stats.duration(s.total)+" erfasste Laufzeit im Jahr "+s.year);setOnClickListener(v->{StringBuilder text=new StringBuilder();String[] names={"Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"};for(int i=0;i<12;i++)text.append(names[i]).append(": ").append(Stats.duration(s.months[i])).append("\n");new android.app.AlertDialog.Builder(c).setTitle("Monatswerte "+s.year).setMessage(text.toString()).setPositiveButton("Schließen",null).show();});}
        protected void onDraw(Canvas c){float w=getWidth(),h=getHeight(),top=dp(getContext(),22),bottom=h-dp(getContext(),28),left=dp(getContext(),30);long max=1;for(long n:s.months)max=Math.max(max,n);
            p.setTextSize(dp(getContext(),9));p.setTypeface(Typeface.create("sans-serif",0));p.setStrokeWidth(1);p.setTextAlign(Paint.Align.LEFT);
            for(int j=0;j<3;j++){float y=top+(bottom-top)*j/2;p.setColor(0xff36393d);c.drawLine(left,y,w,y,p);p.setColor(MUTED);c.drawText(String.format(java.util.Locale.GERMANY,"%.1fh",max/3600000.0*(1-j/2.0)),0,y-3,p);}
            float step=(w-left)/12;String[] names={"J","F","M","A","M","J","J","A","S","O","N","D"};
            for(int i=0;i<12;i++){float x=left+i*step+step*.18f,y=bottom-(bottom-top)*s.months[i]/max;p.setColor(BLUE);c.drawRoundRect(x,y,x+step*.64f,bottom,2,2,p);p.setColor(MUTED);p.setTextAlign(Paint.Align.CENTER);c.drawText(names[i],left+(i+.5f)*step,h-dp(getContext(),10),p);}p.setTextAlign(Paint.Align.LEFT);
        }
    }
    static class WeekChart extends View{final java.util.List<Mission>all;final java.time.LocalDate today;final Paint p=new Paint(3);WeekChart(Context c,java.util.List<Mission>a,java.time.LocalDate d){super(c);all=a;today=d;setContentDescription("Sieben Tage: erledigte und geplante Missionen");}protected void onDraw(Canvas c){float step=getWidth()/7f,bottom=getHeight()-dp(getContext(),28),top=dp(getContext(),25);int max=1;for(int i=0;i<7;i++)max=Math.max(max,WeeklyStats.today(all,today.minusDays(i)).planned);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(dp(getContext(),10));for(int i=0;i<7;i++){java.time.LocalDate d=today.minusDays(6-i);WeeklyStats.Summary n=WeeklyStats.today(all,d);float x=(i+.5f)*step,h=(bottom-top)*n.planned/max,done=(bottom-top)*n.done/max;p.setColor(0xff394137);c.drawRect(x-step*.3f,bottom-h,x+step*.3f,bottom,p);p.setColor(GREEN);c.drawRect(x-step*.3f,bottom-done,x+step*.3f,bottom,p);p.setColor(FG);c.drawText(n.done+"/"+n.planned,x,bottom-h-dp(getContext(),7),p);p.setColor(MUTED);c.drawText(d.format(java.time.format.DateTimeFormatter.ofPattern("dd.MM")),x,getHeight()-dp(getContext(),9),p);}}}
    static class Ring extends View {
        final Paint p=new Paint(3);int accent=YELLOW;long remaining,total;boolean overdue;
        Ring(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void update(long r,long t){remaining=r;total=t;overdue=r<=0;setContentDescription(overdue?"Zeit abgelaufen":"Noch "+Mission.clock(r));invalidate();}
        @Override protected void onDraw(Canvas canvas){
            float w=getWidth(),h=getHeight(),cx=w/2,cy=h/2,r=Math.min(w,h)/2-dp(getContext(),12);
            RectF rect=new RectF(cx-r,cy-r,cx+r,cy+r);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(getContext(),8));p.setColor(Color.rgb(49,60,46));canvas.drawOval(rect,p);
            p.setColor(overdue?RED:accent);p.setStrokeCap(Paint.Cap.ROUND);canvas.drawArc(rect,-90,overdue?360:(float)(360*Math.min(1,Math.max(0,(double)remaining/Math.max(1,total)))),false,p);p.setStrokeCap(Paint.Cap.BUTT);
            p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(dp(getContext(),48));canvas.drawText(overdue?"00:00":Mission.clock(remaining),cx,cy+dp(getContext(),9),p);
            p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setTextSize(dp(getContext(),11));p.setColor(MUTED);canvas.drawText(overdue?"ZEIT ABGELAUFEN":"DEINE RESTZEIT",cx,cy+dp(getContext(),36),p);
        }
    }
}
