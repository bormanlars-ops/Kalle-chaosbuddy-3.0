package de.boyka.kallebuddy;
import java.time.*;import java.util.*;
final class WeeklyStats{
 static final class Summary{int planned,done,open,snoozed,snoozes;long snoozeMillis;int percent(){return planned==0?0:done*100/planned;}}
 static Summary between(List<Mission>a,LocalDate begin,LocalDate end){Summary s=new Summary();Set<Integer>ids=new HashSet<>();for(Mission m:a){LocalDate d=LocalDate.parse(m.dueDay());if(d.isBefore(begin)||!d.isBefore(end)||!ids.add(m.id))continue;s.planned++;if(m.completed())s.done++;else if(!m.archived())s.open++;if(m.snoozeCount>0)s.snoozed++;s.snoozes+=m.snoozeCount;s.snoozeMillis+=m.snoozeMillis;}return s;}
 static LocalDate monday(LocalDate d){return d.minusDays(d.getDayOfWeek().getValue()-1);}static Summary today(List<Mission>a,LocalDate d){return between(a,d,d.plusDays(1));}static Summary week(List<Mission>a,LocalDate d){LocalDate b=monday(d);return between(a,b,b.plusDays(7));}
}
