package de.boyka.kallebuddy;
import android.app.*;import android.appwidget.AppWidgetManager;import android.os.Bundle;import android.widget.*;
/** Direct widget PendingIntent opens a normal, user-initiated dialog activity. */
public final class WidgetInteractionActivity extends Activity{
 int widgetId;boolean asking;String line;
 public void onCreate(Bundle b){super.onCreate(b);widgetId=getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);if(!KalleWidget.valid(this,widgetId)){finish();return;}asking=WidgetState.action(this,widgetId)==KalleScene.Action.BEG;
  line=b!=null?b.getString("line",WidgetState.text(this,widgetId)):"react".equals(getIntent().getAction())?WidgetState.react(this,widgetId):WidgetState.text(this,widgetId);showContent();KalleWidget.updateAll(this);
 }
 protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putString("line",line);}
 void showContent(){ScrollView scroll=new ScrollView(this);LinearLayout root=Ui.column(this);Ui.pad(root,20);scroll.addView(root);root.addView(Ui.bold(this,"KALLE / DEIN REVIER",18,Ui.YELLOW));Ui.gap(root,8);
  CoachView coach=new CoachView(this);coach.scene(WidgetState.action(this,widgetId),Needs.mood(this)/10-5,Store.prefs(this).getInt("kalleOutfit",0),java.util.Calendar.getInstance().get(java.util.Calendar.MONTH),WidgetState.sleeping(this,widgetId));coach.setOnClickListener(v->{line=WidgetState.react(this,widgetId);KalleWidget.updateAll(this);showContent();});coach.transition=-10000;coach.walk(false,1.2f,true);root.addView(coach,new LinearLayout.LayoutParams(-1,Ui.dp(this,160)));root.addView(Ui.text(this,line,18,Ui.FG));Ui.gap(root,16);
  if(asking){root.addView(Ui.text(this,"Nur virtuelle Pfandflaschen – kein echtes Geld.",13,Ui.MUTED));root.addView(Ui.button(this,"VIRTUELLE PFANDFLASCHE SPENDEN",true,()->donate(true)));root.addView(Ui.button(this,"HEUTE NICHT",false,()->donate(false)));}
  if(!WidgetState.enabled(this))root.addView(Ui.button(this,"KALLE AKTIVIEREN",true,()->{CompanionControl.start(this);finish();}));
  root.addView(Ui.button(this,"ZU DEN MISSIONEN",false,()->{startActivity(new android.content.Intent(this,MainActivity.class));finish();}));Ui.gap(root,8);root.addView(Ui.button(this,"SCHLIESSEN",true,()->finish()));setContentView(scroll);
 }
 void donate(boolean yes){if(!asking)return;asking=false;WidgetState.donate(this,widgetId,yes);line=WidgetState.text(this,widgetId);KalleWidget.updateAll(this);showContent();}
}
