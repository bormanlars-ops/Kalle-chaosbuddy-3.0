package de.boyka.kallebuddy;

import java.util.Calendar;
import java.util.Random;

/** Pure-Java homescreen actor state machine. All durations use wall clock in milliseconds. */
final class KalleScene {
    enum Action {WALK, NAP, BEER, SMOKE, BEG, CART, TENT, NEWSPAPER,
        POOL, BBQ, FIRE, DANCE, DRUM, FISH, UMBRELLA, SNOWMAN, SLEEPING_BAG, YOGA, STAND, LOOK, TURN, YAWN, ANNOY, SIT}
    Action action=Action.WALK;
    int mood=0, donations=0, annoyances=0;
    boolean tentClosed=false;
    long until=0, nextChange=0, specialDue=0;
    long started=0;

    /** Persists only the rare-activity eligibility boundary; the scene itself is ephemeral. */
    void start(long now,long savedSpecialDue){
        if(specialDue==0) specialDue=savedSpecialDue>0?savedSpecialDue:now+2*86400000L;
        nextChange=now+20000;
    }
    boolean sleeping(){return action==Action.NAP||action==Action.NEWSPAPER||action==Action.SLEEPING_BAG||action==Action.TENT&&tentClosed;}
    boolean stationary(){return action!=Action.WALK&&action!=Action.CART;}
    boolean showPerson(){return action!=Action.TENT||!tentClosed;}
    boolean asking(){return action==Action.BEG;}
    void set(Action next,long now,long duration){action=next;started=now;until=now+duration;nextChange=until;tentClosed=next==Action.TENT;}
    boolean update(long now,Calendar c,Random rng,boolean allowSpecial){
        if(now<nextChange)return false;
        if(allowSpecial&&now>=specialDue){
            Action[] rare={Action.POOL,Action.BBQ,Action.DRUM,Action.FISH,Action.UMBRELLA,Action.YOGA,Action.SNOWMAN};
            Action next=rare[rng.nextInt(rare.length)];
            if(next==Action.SNOWMAN&&c.get(Calendar.MONTH)!=Calendar.DECEMBER&&c.get(Calendar.MONTH)!=Calendar.JANUARY&&c.get(Calendar.MONTH)!=Calendar.FEBRUARY)next=Action.FIRE;
            set(next,now,60000L+rng.nextInt(70000));
            specialDue=now+(2L+rng.nextInt(3))*86400000L;
            return true;
        }
        if(c.get(Calendar.HOUR_OF_DAY)>=19&&rng.nextInt(6)==0){set(Action.TENT,now,70000L+rng.nextInt(60000));return true;}
        Action[] common={Action.WALK,Action.WALK,Action.WALK,Action.NAP,Action.BEER,Action.SMOKE,
           Action.BEG,Action.CART,Action.NEWSPAPER,Action.DANCE,Action.SLEEPING_BAG,Action.LOOK,Action.YAWN,Action.SIT};
        Action next=common[rng.nextInt(common.length)];
        set(next,now,next==Action.WALK?35000+rng.nextInt(45000):25000+rng.nextInt(35000));
        return true;
    }
    /** Tap sleeping Kalle; independent from tap-callback UI so can be tested. */
    String disturb(long now){
        if(sleeping()){
            annoyances++;mood=Math.max(-5,mood-1);tentClosed=false;
            set(Action.WALK,now,30000);
            return annoyances%3==0?"Alter, schon wieder?! Hast du keine eigene Baustelle, du Nervensäge?":"Ey, du Arsch, ich habe gerade gepennt!";
        }
        return null;
    }
    String donate(boolean yes,long now){
        if(yes){donations++;mood=Math.min(5,mood+2);set(Action.BBQ,now,110000);return "Ehrenmensch! Heute wird fein gegrillt. Eine Dose für den König der Parkbank!";}
        mood=Math.max(-5,mood-2);set(Action.WALK,now,30000);return "Nicht mal 'ne virtuelle Pfandflasche? Du geiziger Sack!";
    }
    String status(){switch(action){
        case NAP:return "Pssst. Kalle pennt gerade.";
        case BEER:return "Feierabend, Digga. Kalle trinkt Bier.";
        case SMOKE:return "Kalle gönnt sich eine Kippe.";
        case BEG:return "Kalle sitzt am Straßenrand und fragt nach Spenden.";
        case CART:return "Kalle rollt mit seinem Pfandwagen durch die Gegend.";
        case TENT:return "Kalle hat sein Zelt aufgestellt. Tipp das Zelt an, um ihn zu wecken.";
        case NEWSPAPER:return "Kalle hat sich mit der Zeitung zugedeckt.";
        case POOL:return "Kalle chillt im aufblasbaren Minipool.";
        case BBQ:return "Kalle grillt am Lagerfeuer.";
        case FIRE:return "Kalle starrt ins Lagerfeuer und sinniert über Pfandpreise.";
        case DANCE:return "Kalle legt einen schrägen Freudentanz hin.";
        case DRUM:return "Kalle macht Straßenmusik auf Eimern.";
        case FISH:return "Kalle angelt im Eimer nach besseren Zeiten.";
        case UMBRELLA:return "Kalle versteckt sich unter einem löchrigen Schirm.";
        case SNOWMAN:return "Kalle baut einen leicht verstörten Schneemann.";
        case SLEEPING_BAG:return "Kalle macht ein Nickerchen im Schlafsack.";
        case YOGA:return "Kalle probiert Parkbank-Yoga.";
        default:return "Kalle macht die Nachbarschaft unsicher.";}}
}
