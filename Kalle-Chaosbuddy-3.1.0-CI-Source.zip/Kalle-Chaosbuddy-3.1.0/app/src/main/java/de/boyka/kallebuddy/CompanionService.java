package de.boyka.kallebuddy;
import android.app.Service;import android.content.*;import android.os.IBinder;
/** Compatibility bridge only; no manifest service and no global window. */
public final class CompanionService extends Service{
 static boolean running=false;static CompanionService live=null;
 static void feedback(Context c,String text){WidgetState.feedback(c,text);}
 static void mission(Context c,int id){WidgetState.mission(c,id);}
 static void resetTracker(){} void hideBubble(){}
 public IBinder onBind(Intent i){return null;}
 public int onStartCommand(Intent i,int flags,int id){stopSelf();return START_NOT_STICKY;}
}
