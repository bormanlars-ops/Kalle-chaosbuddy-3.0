package de.boyka.kallebuddy;
import android.content.*;import android.graphics.*;
/** Reusable alpha sprites; perspective is layout scaling, not a unique bitmap per position. */
final class WorldAssets{
 static final int SW=128,SH=202;static int rw=SW,rh=SH;static Bitmap background,chair;static final android.util.LruCache<String,Bitmap> CACHE=new android.util.LruCache<>(160);
 static String poseKey(WorldMotion.Frame f){return f.pose+":"+f.spriteStep+":"+Math.round(f.posture*7)+":"+Math.round(f.lean/5)+":"+f.right+":"+Math.round(f.turn*7);}
 static void configure(Context c,KalleScene.Action[] programme,android.graphics.PointF origin){java.util.Set<String> poses=new java.util.HashSet<>();for(int scene=0;scene<4;scene++)for(int i=0;i<64;i++)poses.add(poseKey(WorldMotion.at(programme[scene],scene,i,Store.prefs(c).getInt("kalleSize",100),origin,Store.prefs(c).getInt("range",100),Store.prefs(c).getInt("baseline",98))));android.util.DisplayMetrics d=c.getResources().getDisplayMetrics();double budget=d.widthPixels*(double)d.heightPixels*6*.74-650000;double scale=Math.min(1,Math.sqrt(Math.max(180000,budget)/(Math.max(1,poses.size())*SW*(double)SH*4)));rw=Math.max(40,(int)(SW*scale));rh=Math.max(64,(int)(SH*scale));}
 static Bitmap background(Context c){if(background==null){background=Bitmap.createBitmap(320,200,Bitmap.Config.RGB_565);WidgetRenderer.drawBackground(c,new Canvas(background),320,200);}return background;}
 static final Bitmap[] TIME_BACKGROUNDS=new Bitmap[4];
 /** Preserve the original background image; apply only subtle scene-time lighting. */
 static Bitmap background(Context c,int hour){
  int period=LivingWorldBrain.period(hour).ordinal();
  if(TIME_BACKGROUNDS[period]!=null)return TIME_BACKGROUNDS[period];
  Bitmap b=Bitmap.createBitmap(320,200,Bitmap.Config.RGB_565);Canvas canvas=new Canvas(b);
  canvas.drawBitmap(background(c),0,0,null);
  int overlay=period==0?0x0dffe4aa:period==1?0x00000000:period==2?0x20ffae64:0x88061119;
  canvas.drawColor(overlay);TIME_BACKGROUNDS[period]=b;return b;
 }

 static Bitmap actor(Context c,WorldMotion.Frame f){int posture=Math.round(f.posture*7),lean=Math.round(f.lean/5),mood=Needs.mood(c)/10-5,outfit=Store.prefs(c).getInt("kalleOutfit",0),month=java.util.Calendar.getInstance().get(java.util.Calendar.MONTH);String key="actor:"+f.pose+":"+f.spriteStep+":"+posture+":"+lean+":"+f.right+":"+Math.round(f.turn*7)+":"+mood+":"+outfit+":"+month+":"+rw+":"+rh;Bitmap b=CACHE.get(key);if(b!=null)return b;b=Bitmap.createBitmap(rw,rh,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(b);float k=Math.min(rw/166f,rh/261f);canvas.translate((rw-166*k)/2,(rh-261*k)/2);canvas.scale(k,k);SpriteRig.draw(c,canvas,f.pose,(float)(f.spriteStep*Math.PI*2/(f.pose==KalleScene.Action.WALK?16:8)),f.right,f.turn,mood,outfit,month,posture/7f,lean*5);CACHE.put(key,b);return b;}
 static Bitmap prop(Context c,KalleScene.Action action,int step){if(action==KalleScene.Action.SIT||action==KalleScene.Action.BEG)return chair(c);int frame=(action==KalleScene.Action.FIRE||action==KalleScene.Action.BBQ||action==KalleScene.Action.TENT||action==KalleScene.Action.POOL)?step%4:0;String key="object:"+action+":"+frame;Bitmap cached=CACHE.get(key);if(cached!=null)return cached;Bitmap b=Bitmap.createBitmap(112,96,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(b);CoachView brush=new CoachView(c);brush.scene(action,0,1,0,action==KalleScene.Action.TENT);brush.phase=frame*1.4f;RectF source;
  switch(action){case TENT:source=new RectF(0,62,151,222);break;case FIRE:case BBQ:source=new RectF(-3,150,62,234);break;case POOL:source=new RectF(-3,181,152,243);break;case CART:source=new RectF(-3,148,79,231);break;case DRUM:source=new RectF(-3,175,54,232);break;case FISH:source=new RectF(0,195,48,238);break;case UMBRELLA:source=new RectF(-6,10,72,213);break;case SNOWMAN:source=new RectF(-3,123,69,242);break;case YOGA:source=new RectF(-3,216,152,238);break;default:source=new RectF(8,140,143,238);}
  canvas.scale(112/source.width(),96/source.height());canvas.translate(-source.left,-source.top);if(action==KalleScene.Action.FISH)brush.rect(canvas,3,201,43,235,0xff5984a7);else{brush.surroundings(canvas,false);brush.surroundings(canvas,true);}CACHE.put(key,b);return b;}
 static Bitmap chair(Context c){if(chair==null){chair=Bitmap.createBitmap(64,64,Bitmap.Config.ARGB_8888);Canvas x=new Canvas(chair);CoachView p=new CoachView(c);p.rect(x,5,6,58,33,0xff765c40);p.rect(x,4,33,60,40,0xff90714d);p.line(x,0xff272d24,4,9,39,6,61,54,39,59,61);p.line(x,0xffb49a70,2,11,14,51,14,11,23,51,23);}return chair;}
}
