package de.boyka.kallebuddy;
import android.content.Context;
import java.time.LocalDate;

/** Visual reactions only; never modify mission scoring, completion or deadlines. */
final class LivingWorldReactions {
 static void finished(Context c,Mission current){
  if(current==null)return;
  int count=0,planned=0;String today=LocalDate.now().toString();
  for(Mission m:Store.all(c))if(m.dueDay().equals(today)){
   planned++;if(m.completed())count++;
  }
  String line;
  KalleScene.Action action;
  if(current.completed()){
   if(planned>0&&count==planned){line="Okay. Jetzt wird's langsam unheimlich. Alle Missionen durch.";action=KalleScene.Action.DANCE;}
   else if(count>=3){line="Drei oder mehr erledigt? Wer bist du und was hast du mit meinem Chef gemacht?";action=KalleScene.Action.LOOK;}
   else{line="Na siehste. Manchmal funktioniert dieses Konzept namens Arbeit.";action=KalleScene.Action.LOOK;}
  }else{line="Ich sag mal so: Luft nach oben. Wir planen morgen neu.";action=KalleScene.Action.SIT;}
  for(int id:WidgetState.ids(c)){
   if(WidgetState.allowed(c,action))WidgetState.setAction(c,id,action);
   WidgetStory.invalidate(c,id);
  }
  WidgetState.feedback(c,line);
 }
}
