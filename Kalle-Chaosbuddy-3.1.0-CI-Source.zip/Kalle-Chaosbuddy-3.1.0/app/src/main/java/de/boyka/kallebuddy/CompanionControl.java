package de.boyka.kallebuddy;

import android.app.*;

import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.provider.Settings;
import java.util.*;

final class CompanionControl {
    static boolean enabled(Context c){return WidgetState.enabled(c);}
    static boolean ready(Context c){return true;}
    static void start(Context c){WidgetState.setEnabled(c,true);KalleWidget.updateAll(c);}
    static void stop(Context c){WidgetState.setEnabled(c,false);KalleWidget.updateAll(c);}
    /** Nearest unfinished mission associated with the current day. */
    static Mission nextOpen(Context c){long now=System.currentTimeMillis();Mission nearest=null;
        for(Mission m:Store.all(c)){
            if(m.archived()||!Stats.sameDay(m.anchor(),now))continue;
            if(nearest==null||m.start<nearest.start)nearest=m;
        }
        return nearest;
    }
    static String reminder(Context c){long now=System.currentTimeMillis();Mission next=null;int open=0;for(Mission m:Store.all(c)){if(m.archived()||!Stats.sameDay(m.anchor(),now))continue;open++;if(next==null||m.start<next.start)next=m;}if(next==null)return "Heute nichts Offenes mehr, Digga. Dein Arsch darf kurz Pause machen.";
        String time=new java.text.SimpleDateFormat("HH:mm",Locale.GERMANY).format(new Date(next.start));String state=next.running()?"läuft noch":"um "+time;
        String note=next.note.isEmpty()?"":" Denk dran: "+(next.note.length()>80?next.note.substring(0,77)+"…":next.note);
        return "Heute noch "+open+" offen. "+next.title+" "+state+". Vergiss den verdammten Auftrag nicht."+note;
    }
}
