package de.boyka.kallebuddy;
import android.content.Context;
import android.graphics.*;
import android.view.View;

// Original vector cartoon: transparent canvas, no rectangular background.
final class CoachView extends View {
    boolean walking,facing=true;float phase,turnProgress;KalleScene.Action previous=KalleScene.Action.WALK;long transition;
    KalleScene.Action action=KalleScene.Action.WALK;int mood=0,outfit=0,month=0;boolean tentClosed=false;
    void scene(KalleScene.Action a,int m,int o,int seasonalMonth,boolean closed){if(action!=a){previous=action;transition=android.os.SystemClock.uptimeMillis();}action=a;setContentDescription("Kalle: "+a.name());mood=m;outfit=o;month=seasonalMonth;tentClosed=closed;invalidate();}
    boolean is(KalleScene.Action a){return action==a;}

    void walk(boolean move,float value,boolean right){walking=move;phase=value;facing=right;invalidate();}
    final Paint p=new Paint(3);final int ink=0xff182225;
    CoachView(Context c){super(c);setContentDescription("Kalle: bärtiger Straßen-Coach mit Mütze, Mantel und Pfandtasche");}
    void oval(Canvas c,float l,float t,float r,float b,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawOval(l,t,r,b,p);p.setStyle(Paint.Style.STROKE);p.setColor(ink);p.setStrokeWidth(2.8f);c.drawOval(l,t,r,b,p);p.setStyle(Paint.Style.FILL);}
    void path(Canvas c,int color,float... points){Path path=new Path();path.moveTo(points[0],points[1]);for(int i=2;i<points.length;i+=2)path.lineTo(points[i],points[i+1]);path.close();p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawPath(path,p);p.setStyle(Paint.Style.STROKE);p.setColor(ink);p.setStrokeWidth(2.8f);p.setStrokeJoin(Paint.Join.ROUND);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}
    void line(Canvas c,int color,float width,float... points){p.setColor(color);p.setStrokeWidth(width);p.setStrokeCap(Paint.Cap.ROUND);for(int i=0;i<points.length-2;i+=2)c.drawLine(points[i],points[i+1],points[i+2],points[i+3],p);}
    static final float ART_WIDTH=166,ART_HEIGHT=261;
    static RectF fitBounds(int width,int height){float scale=Math.min(width/ART_WIDTH,height/ART_HEIGHT);float w=ART_WIDTH*scale,h=ART_HEIGHT*scale;return new RectF((width-w)/2,(height-h)/2,(width+w)/2,(height+h)/2);}
    protected void onDraw(Canvas c){drawCharacter(c);}
    void drawCharacter(Canvas c){c.save();RectF fit=fitBounds(getWidth(),getHeight());float scale=fit.width()/ART_WIDTH;c.translate(fit.left,fit.top);c.scale(scale,scale);SpriteRig.draw(getContext(),c,action,phase,facing,turnProgress,mood,outfit,month);c.restore();}
    void rect(Canvas c,float left,float top,float right,float bottom,int fill){p.setColor(fill);p.setStyle(Paint.Style.FILL);c.drawRoundRect(left,top,right,bottom,4,4,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(ink);c.drawRoundRect(left,top,right,bottom,4,4,p);p.setStyle(Paint.Style.FILL);}
    void text(Canvas c,String content,float x,float y,int size,int color){p.setColor(color);p.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));p.setTextSize(size);p.setStyle(Paint.Style.FILL);c.drawText(content,x,y,p);}
    void surroundings(Canvas c,boolean foreground){
        switch(action){
            case TENT:
                if(foreground){path(c,0xff927650,7,212,72+(float)Math.sin(phase)*2,68,145,213);line(c,0xff332b29,3,72,68,72,219);path(c,0xff50483a,73,213,109,152,129,213);
                    if(tentClosed){float floaty=(float)Math.sin(phase)*3;text(c,"Z",103,107+floaty,20,0xffd9d4ca);text(c,"z",125,91+floaty,12,0xffd9d4ca);}}
                break;
            case BEG:
                if(!foreground){rect(c,28,181,118,192,0xff6c5842);line(c,ink,4,34,189,34,230,111,189,111,231);}
                else{rect(c,0,188,63,224,0xffd4b58b);text(c,"PFAND",4,207,12,ink);text(c,"BITTE",6,219,10,ink);}
                break;
            case CART:
                if(foreground){rect(c,4,174,73,211,0xff82948e);line(c,ink,4,10,177,1,161);oval(c,11,209,26,226,0xff212b30);oval(c,52,209,68,226,0xff212b30);
                    float k=(float)Math.sin(phase);line(c,0xffddddc8,1,19,217,19+6*k,217+5*k,60,217,60-6*k,217-5*k);
                    for(int bottle=0;bottle<5;bottle++){rect(c,12+bottle*10,157-(bottle%2)*9,20+bottle*10,182,0xff629370);line(c,0xffcdd6bc,2,16+bottle*10,158,16+bottle*10,178);}}
                break;
            case BEER:
                if(foreground){c.save();c.rotate((float)Math.sin(phase)*13,113,171);rect(c,104,132,124,175,0xffb27827);rect(c,108,129,121,139,0xffead8a2);text(c,"B",109,159,16,0xfff8e5bf);c.restore();}
                break;
            case SMOKE:
                if(foreground){line(c,0xffeee5c5,4,96,76,122,67);p.setColor(0x99999999);for(int i=0;i<3;i++)c.drawCircle(120-i*5,60-i*19+(float)Math.sin(phase+i)*3,5+i*2,p);}
                break;
            case NAP:case SLEEPING_BAG:case NEWSPAPER:
                if(foreground){if(is(KalleScene.Action.NEWSPAPER)){rect(c,25,148,123,208,0xffbdb4a0);for(int i=0;i<5;i++)line(c,0xff74736f,1.2f,34,161+i*9,110,161+i*9);}
                    if(is(KalleScene.Action.SLEEPING_BAG))path(c,0xff375c6b,20,156,101,156,136,220,16,231);
                    text(c,"Z",112,90,19,0xffa1b8c4);text(c,"z",127,71,13,0xffa1b8c4);}
                break;
            case POOL:
                if(foreground){float wiggle=(float)Math.sin(phase)*3;oval(c,1,187+wiggle,149,240,0xff54aec4);oval(c,13,187+wiggle,135,227,0xff97dce0);line(c,0xffeeeeee,4,7,202+wiggle,143,202-wiggle);}
                break;
            case BBQ:case FIRE:
                if(foreground){float flutter=(float)Math.sin(phase*3)*6;path(c,0xff754733,1,230,24,204,49,230);path(c,0xffd96927,15,220,20,177+flutter,27,195,37,169-flutter,44,205,49,221);path(c,0xfffbd45c,23,221,31,190+flutter,40,221);
                    if(is(KalleScene.Action.BBQ)){line(c,ink,4,4,186,57,192);oval(c,9,179,44,193,0xff8c4430);}}
                break;
            case DRUM:
                if(foreground){rect(c,2,180,48,229,0xff647d9b);line(c,ink,4,3,179,49,179);line(c,0xffc6b187,4,18+(float)Math.sin(phase)*6,155,32,180);}
                break;
            case FISH:
                if(foreground){rect(c,3,201,43,235,0xff5984a7);line(c,0xff986f3b,3,40,154,8,47);line(c,0xffa8b4c8,1,8,47,7+(float)Math.sin(phase)*5,210);}
                break;
            case UMBRELLA:
                if(!foreground){float sway=(float)Math.sin(phase)*3;line(c,ink,3,24+sway,32,24+sway,210);Path umbrella=new Path();umbrella.moveTo(0,64);umbrella.cubicTo(0,23,48,17,64,64);umbrella.cubicTo(49,55,43,58,32,66);umbrella.cubicTo(18,55,10,57,0,64);umbrella.close();c.save();c.translate(sway,0);p.setColor(0xff9e596b);c.drawPath(umbrella,p);p.setStyle(Paint.Style.STROKE);p.setColor(ink);p.setStrokeWidth(2.5f);c.drawPath(umbrella,p);p.setStyle(Paint.Style.FILL);line(c,0xffd9a0a0,1.4f,24,30,32,64);c.restore();}
                break;
            case SNOWMAN:
                if(foreground){oval(c,2,188,64,238,0xffeeeef3);oval(c,12,154,52,194,0xffeeeef3);rect(c,17,148,47,155,0xff2a3844);rect(c,23,130,42,151,0xff2a3844);}
                break;
            case DANCE:
                if(foreground){text(c,"♪",3,72,22,0xfff9cf67);text(c,"♫",112,49,24,0xfff9cf67);}
                break;
            case YOGA:
                if(foreground){rect(c,0,220,147,235,0xffac6aa4);}
                break;
            default:break;
        }
    }
}
