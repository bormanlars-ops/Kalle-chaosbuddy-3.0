package de.boyka.kallebuddy;
import java.util.*;
import java.text.SimpleDateFormat;

final class Stats {
    final int year;int done,onTime,started,activeDays;long total;
    final long[] months=new long[12];
    final Map<String,Integer> activity=new HashMap<>();
    final Map<String,Task> tasks=new LinkedHashMap<>();
    static class Task {int count;long time;}
    Stats(List<Mission> missions,int selectedYear){year=selectedYear;
        Calendar c=Calendar.getInstance();
        for(Mission m:missions){c.setTimeInMillis(m.anchor());if(c.get(Calendar.YEAR)!=year)continue;
            if(!m.state.equals("scheduled"))started++;
            if(!m.completed())continue;done++;if(m.state.equals("done"))onTime++;
            long elapsed=m.elapsed();total+=elapsed;months[c.get(Calendar.MONTH)]+=elapsed;
            String key=dayKey(m.anchor());activity.put(key,activity.getOrDefault(key,0)+1);
            Task t=tasks.get(m.title);if(t==null){t=new Task();tasks.put(m.title,t);}t.count++;t.time+=elapsed;
        }activeDays=activity.size();
    }
    static String dayKey(long time){return new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).format(new Date(time));}
    static boolean sameDay(long a,long b){return dayKey(a).equals(dayKey(b));}
    static String duration(long millis){long min=Math.max(0,millis)/60000;if(millis>0&&min==0)return "<1 Min";return min<60?min+" Min":(min/60)+" h "+(min%60)+" m";}
}
