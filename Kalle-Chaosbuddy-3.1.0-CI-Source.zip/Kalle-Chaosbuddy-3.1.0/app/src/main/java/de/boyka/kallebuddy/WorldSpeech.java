package de.boyka.kallebuddy;
import android.content.*;import java.util.*;import org.json.*;
/** Stored, filtered quote programme. Appearance/fade are native launcher animations. */
final class WorldSpeech{
 static void event(Context c,int id){WidgetState.prefs(c).edit().putLong(WidgetState.key(id,"speechEvent"),System.currentTimeMillis()+90000).remove(WidgetState.key(id,"speechContext")).commit();}
 static void mission(Context c,int id,int missionId,String text){WidgetState.prefs(c).edit().putInt(WidgetState.key(id,"speechMission"),missionId).putString(WidgetState.key(id,"speechMissionText"),text).remove(WidgetState.key(id,"speechContext")).commit();}
 // Everyday observations, not generic motivational slogans. No claims about real-world facts.
 private static final String[] OWN_LIFE={
   "Ich hab heute die Zeitung gelesen. Drei Seiten. Danach war ich wieder bedient.",
   "Ralle wollte mir einen Businessplan verkaufen. Auf einer Serviette.",
   "Der Kioskbesitzer hat gesagt, ich soll seriöser wirken. Ich hatte sogar Schuhe an.",
   "Manchmal sitz ich hier und beobachte die Tauben. Die haben klarere Tagespläne als ich.",
   "Hab überlegt, mein Zelt zu renovieren. Dann hab ich festgestellt: Es ist ein Zelt.",
   "Mein Nachbar hat WLAN. Ich hab dafür den besseren Blick auf die Mülltonne.",
   "Ich hab einen Euro gefunden. War meiner. Hatte ihn gestern verloren.",
   "Ein Typ hat mir erklärt, wie man reich wird. Er hat danach nach Kleingeld gefragt.",
   "Ich bin nicht faul. Ich betreibe intensives Energiemanagement.",
   "Die Taube Bodo war schon wieder am Frühstück. Ohne zu fragen.",
   "Ich wollte Ralle anrufen. Dann fiel mir ein, dass ich sein Handy hab.",
   "Heute steht viel auf dem Programm: sitzen, aufstehen, wieder sitzen.",
   "Ich hab dem Feuer beim Brennen zugeguckt. Wenigstens einer arbeitet hier.",
   "Das Zelt knarzt nachts. Der Vermieter ist nicht erreichbar.",
   "Komisch, wie schnell ein Tag rumgeht, wenn man auf nichts wartet.",
   "Hab meine Tasche durchgezählt. Der Bestand ist überschaubar und klappert.",
   "Ich wollte die Uhr stellen. Dann hab ich gemerkt, dass sie gar nicht läuft.",
   "Zeitung von gestern. Geschichten von vorgestern. Läuft bei uns.",
   "Ein guter Stuhl versteht mich. Vor allem, wenn ich nichts erzähle.",
   "Hab mich kurz verlaufen. In meinem eigenen Revier. Frag nicht."
 };
 private static String ownLife(Context c,int id,KalleScene.Action a,int index){
   int bucket=(int)(System.currentTimeMillis()/1800000);
   int offset=Math.floorMod(bucket*13+id*17+a.ordinal()*7,OWN_LIFE.length);
   if(a==KalleScene.Action.TENT)return index%2==0?"Ich hab das Zelt neu eingerichtet. Sieht jetzt aus wie vorher.":OWN_LIFE[(offset+index)%OWN_LIFE.length];
   if(a==KalleScene.Action.FIRE)return index%2==0?"Das Feuer knistert. Das ist heute mein ganzer Gesprächsbedarf.":OWN_LIFE[(offset+index)%OWN_LIFE.length];
   if(a==KalleScene.Action.NEWSPAPER)return index%2==0?"In der Zeitung steht auch nicht, wo meine zweite Socke ist.":OWN_LIFE[(offset+index)%OWN_LIFE.length];
   return OWN_LIFE[(offset+index)%OWN_LIFE.length];
 }
 static String[] lines(Context c,int id,KalleScene.Action activity){SharedPreferences p=WidgetState.prefs(c);Mission mission=Store.get(c,p.getInt(WidgetState.key(id,"speechMission"),-1));boolean priority=mission!=null&&(mission.state.equals("waiting")||mission.state.equals("overdue"));boolean event=System.currentTimeMillis()<p.getLong(WidgetState.key(id,"speechEvent"),0);int hour=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);String category=Needs.energy(c)<35||hour>=22||hour<6||WidgetState.sleeping(c,id)?"Müdigkeit":Needs.mood(c)<35||activity==KalleScene.Action.ANNOY?"Genervtheit":Needs.mood(c)>=70?"Erfolg":activity==KalleScene.Action.WALK||activity==KalleScene.Action.CART?"Alltag":"Alltag";
  String context=category+":"+priority+":"+(priority?mission.id+"/"+mission.revision:event?WidgetState.text(c,id):"ambient")+":"+Store.prefs(c).getInt("humor",1)+":"+Store.prefs(c).getBoolean("vulgar",false);
  try{if(context.equals(p.getString(WidgetState.key(id,"speechContext"),""))&&System.currentTimeMillis()<p.getLong(WidgetState.key(id,"speechUntil"),0)){JSONArray cached=new JSONArray(p.getString(WidgetState.key(id,"speechLines"),"[]"));if(cached.length()==8){String[] result=new String[8];for(int i=0;i<8;i++)result[i]=cached.getString(i);return result;}}}catch(JSONException ignored){}
  String[] result=new String[8];Set<String> chosen=new HashSet<>();for(int i=0;i<8;i++){String text=i==0&&priority?p.getString(WidgetState.key(id,"speechMissionText"),"Chef, deine Mission wartet."):i==0&&event?WidgetState.text(c,id):i%3!=2?ownLife(c,id,activity,i):DialogSystem.line(c,category,true);for(int retry=0;chosen.contains(text)&&retry<8;retry++)text=DialogSystem.line(c,category,true);chosen.add(text);result[i]=text;}
  p.edit().putString(WidgetState.key(id,"speechContext"),context).putString(WidgetState.key(id,"speechLines"),new JSONArray(Arrays.asList(result)).toString()).putLong(WidgetState.key(id,"speechUntil"),System.currentTimeMillis()+1800000).commit();return result;
 }
 static int interval(Context c){int seconds=Store.prefs(c).getInt("homeTalkSeconds",180);return seconds<=30?30000:seconds<=90?90000:seconds<=180?180000:seconds<=300?300000:600000;}
}
