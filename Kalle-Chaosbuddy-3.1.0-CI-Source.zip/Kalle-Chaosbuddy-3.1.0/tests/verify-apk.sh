#!/usr/bin/env bash
set -euo pipefail
SDK="${ANDROID_SDK_ROOT:?Setze ANDROID_SDK_ROOT}"
APK="${1:?Pfad zur APK}"
BT="$SDK/build-tools/35.0.0"
"$BT/apksigner" verify --verbose --print-certs "$APK"
"$BT/zipalign" -c -p 4 "$APK"
INFO="$(mktemp)"; trap 'rm -f "$INFO"' EXIT
"$BT/aapt2" dump badging "$APK" > "$INFO"
python3 - "$APK" "$INFO" <<'PY'
import sys,zipfile
apk,info=sys.argv[1:];s=open(info).read()
assert "name='de.boyka.kallebuddy'" in s
assert "versionCode='30001'" in s and "versionName='3.0.0'" in s
assert "minSdkVersion:'28'" in s and "targetSdkVersion:'35'" in s
for permission in ['RECORD_AUDIO','INTERNET','USE_FULL_SCREEN_INTENT','BIND_ACCESSIBILITY_SERVICE']:
 assert 'android.permission.'+permission not in s,permission
with zipfile.ZipFile(apk) as z:
 assert z.testzip() is None
 assert z.read('classes.dex').startswith(b'dex\n')
 assert not any(n.endswith(('.p12','.jks','.keystore')) for n in z.namelist())
print('PASS: APK archive, DEX, applicationId, version, SDK, permissions and no private keys')
PY
