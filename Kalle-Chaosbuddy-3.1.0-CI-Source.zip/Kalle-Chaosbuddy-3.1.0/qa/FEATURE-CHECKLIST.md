# Interne Abnahmecheckliste für 3.0

Stand: abschließend geprüft; 21 Frameworktests bestanden. Geräteseitige Grenzen siehe TESTREPORT.

| Bereich | Codezustand | Abgrenzung |
|---|---|---|
| Missionen / Bearbeiten / Löschen / Kategorien | Implementiert | Reale lokale Daten, ursprüngliches Format bleibt lesbar |
| Start / Pause / Fortsetzen / Erledigt / Abbruch | Implementiert | Pause zählt nicht als aktive Timerzeit |
| Aufschieben 10 / 30 / 60 | Implementiert | Revision + Ereignistoken, Originaltermin bleibt |
| Wiederholungen | Implementiert | Konkrete Instanzen, acht Tage Vorausplanung |
| Tages- / Wochenstatistik | Implementiert | Ursprünglicher lokaler Fälligkeitstag, eindeutige IDs |
| Jahresstatistik / sieben Tage / Wochenverlauf | Implementiert | Aus vorhandenen Daten, keine Demowerte |
| 20 Animationen | 24 Zustände nativ gerendert | 24 benannte Vektorszenen einschließlich Stand, Blick, Wende, Gähnen und genervter Reaktion; Renderingtest prüft visuelle Unterschiede |
| 200 Sprüche | 264 eindeutige Texte getestet | Erhaltener Katalog plus 64 kategorisierte Basiszeilen; Laufzeittest zählt eindeutige Texte |
| Schlafen / Zelt / virtuelle Spenden | Bestehenden Code erhalten und eingebunden | Keine echten Zahlungen; Zustandsübergänge und Speicherung werden geprüft |
| Stimmung / Energie | Implementiert | 0–100, lokale Normalisierung; beeinflussen Verhalten und Sprüche |
| Homescreen | Teilweise plattformabhängig | Launcher-Paket-Erkennung kann App-Schublade/Übersicht nicht sicher trennen |
| Einstellungen | Implementiert | Separate Figuren-/Blasengröße, Schrift, Dauer, Tempo, Bereich, Höhe, Humor, Ruhe, Pause, Energiesparen, Erinnerungen, Aufschieben |
| Sonntagsbericht | Nicht implementiert, bewusst außerhalb des ursprünglichen 3.0-Umfangs | Im Originalauftrag ausdrücklich für 3.3 vorgesehen; keine vorgetäuschte Automatik |
| Original-Update-Signatur | Nicht verfügbar | Weder ursprünglicher 2.0-Schlüssel noch verlorener temporärer 3.0-Schlüssel sind rekonstruierbar. Neue Linie separat gesichert |
| Samsung / One UI | Nicht getestet | Kein verbundenes Gerät; nicht als bestanden markieren |
