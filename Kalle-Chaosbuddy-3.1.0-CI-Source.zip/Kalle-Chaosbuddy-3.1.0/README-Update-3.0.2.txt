KALLE – CHAOSBUDDY 3.0.2

UPDATE
APK über die vorhandene 3.0.1 installieren, nicht vorher deinstallieren.
Gleiche Paketkennung de.boyka.kallebuddy und gleicher Signierschlüssel.
Version 3.0.2 / versionCode 30005; der Zwischenstand hat 30004.
Missionsdaten und Statistikformat bleiben unverändert. Die separate App
Kalle Missionschaot 1.0 (de.boyka.kalle) wird nicht verändert.
Einmal öffnen. Ein bereits platziertes Widget wird aktualisiert. Falls der
Launcher noch die alte Ansicht zeigt: App öffnen oder das Widget entfernen
und neu hinzufügen. Das Entfernen des Widgets löscht keine Missionsdaten.

DIREKTE INTERAKTION
Kalle im Widget antippen: Spruch und sichtbare Reaktion direkt im Widget,
kein automatischer App-Start. Auch der tatsächlich sichtbare Schlafzustand
kann so geweckt werden. Mehrfach schnell tippen nervt ihn vorübergehend.
Bei seiner Pfandfrage lässt sich über PFAND +1 eine virtuelle Flasche geben.
MISSIONEN öffnet ausdrücklich die App. Die Sprechblase öffnet weiterhin auf
Wunsch den vollständigen Text; ein langer Text ist im Widget als Vorschau
mit „… Tippen“ gekennzeichnet. SZENE ist nur eine zusätzliche Handsteuerung.
Das ganze 4×4-Widget lässt sich wie gewohnt im Launcher verschieben.
Es gibt keine globale Charakterfigur auf anderen Homescreen-Seiten.

ANIMATION
Ein nativer ViewFlipper spielt eine vorbereitete Folge von acht Abschnitten
mit vier unterschiedlichen Aktivitäten ab. Keine benachbarten Wiederholungen,
auch nicht am Schleifenende. Auswahl berücksichtigt Uhrzeit, Energie, Stimmung
und die letzten direkten Reaktionen. Neue Ereignisse und die regulären
Android-Systemupdates erzeugen bzw. aktualisieren das Programm.
Die Folge enthält 256 Bildplätze und verwendet wiederverwendete Bitmaps:
100 ms/Bild = nominell 10 Bilder/s, 125 ms = 8 Bilder/s, 200 ms = 5 Bilder/s.
Normal: 4 Sekunden je Abschnitt, 32 Sekunden je vollständigem Programm.
Energiesparen oder geringe Energie: 5 Bilder/s, 6,4 Sekunden je Abschnitt.
Schnell: 10 Bilder/s, 3,2 Sekunden je Abschnitt.
Das Programm wiederholt sich bis zum nächsten inhaltlichen Update. Dies ist
kein unbegrenzt laufender Zufallsgenerator. Es gibt keine sekündlichen App-
Hintergrundupdates, zusätzlichen Widget-Alarme oder Animationsdienste.
Das Anhalten unsichtbarer Widgets/bei ausgeschaltetem Display steuert der
Launcher über die Fenstersichtbarkeit. Pause/Ruhezeit deaktivieren die
Bildfolge vollständig. Echte Samsung-FPS und Akkuverbrauch sind nicht gemessen.
Die 24 Vektorzustände und 264 Standardsprüche bleiben erhalten. Körper werden
nun einheitlich skaliert, mit Randreserve und korrigierten Armhaltungen.

MISSIONSFENSTER UND TON: EINMAL EINRICHTEN
1. Kalles Bude → BENACHRICHTIGUNGEN: Android-Erlaubnis einschalten.
2. MISSIONEN ALS POP-UP: Android-Kanal öffnen, Ton und Pop-up zulassen.
   Bereits vorhandene stumme Kanaleinstellungen bleiben erhalten und müssen
   dort vom Nutzer geändert werden. Die App überschreibt sie nicht heimlich.
3. Für das zusätzliche große Missionsfenster über YouTube/WhatsApp/Browser:
   MISSIONSFENSTER ÜBER ANDEREN APPS öffnen und die Overlay-Erlaubnis erteilen.
   Der Schalter „Zusätzliches Missionsfenster erlauben“ muss eingeschaltet sein.
4. GENAUE ERINNERUNGEN erlauben. Ein nutzerseitig geplanter exakter Alarm kann
   den kurzen Missionsdienst zulässig aus dem Hintergrund starten. Wenn das
   System den Start oder das Fenster verweigert, bleibt die Benachrichtigung
   mit allen Aktionen als Fallback erhalten.
5. TON UND POP-UP PRÜFEN sendet eine echte Testbenachrichtigung, ohne Mission
   oder Statistikdaten anzulegen. Für hörbaren Ton müssen Benachrichtigungs-
   lautstärke und Klingelmodus passen. „Nicht stören“ und stumme Kanäle werden
   nicht umgangen. Die Diagnose in der Bude zeigt Kanalton/Wichtigkeit an.

Das zusätzliche Fenster zeigt Titel, Kalles Kommentar, Starten, 30 Minuten
Aufschieben, Erledigt und Schließen. Es wird spätestens nach 40 Sekunden
beendet, beim Ausschalten des Displays geschlossen und nicht auf dem
Sperrbildschirm eingeblendet. Schließen erledigt die Mission nicht; ihre
Benachrichtigung bleibt zugänglich. Der Ton kommt einmal über den normalen
Android-Kanal, nicht über einen zweiten dauernden Audioplayer.
Das Overlay-Recht wird ausschließlich für dieses kurzzeitige Missionsfenster
verwendet; es aktiviert keinen zweiten Kalle. Keine Vollbild-Intents oder
Accessibility-Umgehung. Einige Apps dürfen Overlays vom System ausblenden.

Die tatsächliche Overlay-/Heads-up-Anzeige und der hörbare Ton auf dem
Samsung S22 Ultra sind noch nicht geräteseitig getestet. Sie lassen sich nicht
gegen verweigerte Rechte, stumme Kanäle oder Lautstärkeeinstellungen erzwingen.
Ausgeführte Prüfungen und offene Punkte: TESTREPORT-3.0.2.md.
