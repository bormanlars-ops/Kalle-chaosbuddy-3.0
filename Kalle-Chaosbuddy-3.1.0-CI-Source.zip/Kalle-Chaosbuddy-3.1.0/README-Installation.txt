KALLE – CHAOSBUDDY 3.0.0
======================

APK: Kalle-Chaosbuddy-3.0.apk
Paket: de.boyka.kallebuddy
Finaler versionCode: 30001 (gesicherter Build 01: 30000)
Ziel: Samsung Galaxy S22 Ultra, Android 15 / One UI.

SIGNATUR UND VORHANDENE DATEN

Die separate Kalle-Missionschaot-1.0-App (de.boyka.kalle) wird nicht ersetzt.
Chaosbuddy hat eine eigene Kennung und eigene lokale Missionen/Einstellungen.

Die finale APK verwendet denselben neu gesicherten Schlüssel wie der in dieser
Fortsetzung bereitgestellte Build 01. Sie ist als Aktualisierung dieses Builds
vorgesehen. APK-Zertifikate und aufsteigende Versionscodes wurden geprüft.
Eine tatsächliche Installation auf deinem Samsung wurde NICHT durchgeführt.

Der ursprüngliche Chaosbuddy-2.0-Schlüssel war nicht im Quellarchiv enthalten.
Der temporäre Schlüssel aus dem unterbrochenen Arbeitsordner ist ebenfalls nicht
mehr vorhanden. Die jetzige APK kann daher eine damit anders signierte bestehende
Installation nicht direkt aktualisieren. Bei einem Paket-/Signaturkonflikt die
alte App NICHT vorschnell deinstallieren: dadurch würden private Daten gewöhnlich
gelöscht. Für ein datenbewahrendes direktes Update der Originalinstallation wird
deren privater Signierschlüssel benötigt. Eine APK allein liefert ihn nicht.

Die neue Exportfunktion kann keine privaten Daten einer anders signierten alten
Installation auslesen. Ein Import vorhandener Sicherungen ist erst innerhalb der
jetzigen Versionslinie möglich. Es wird nichts automatisch deinstalliert.

INSTALLIEREN

1. APK auf das Handy laden und mit der Dateien-App öffnen.
2. Falls Android fragt, die Installation aus dieser Quelle erlauben und den
   Systemhinweisen folgen. Keine andere Kalle-App dafür löschen.
3. Kalle öffnen und „Kalles Bude“ aufrufen.
4. Benachrichtigungen erlauben. Für pünktliche Erinnerungen zusätzlich die
   Berechtigung für genaue Alarme/Erinnerungen erteilen.
   Ohne genaue Alarme bleibt die App nutzbar; Meldungen können später kommen.
5. Für die bewegliche Homescreen-Figur zusätzlich Overlay-Anzeige und
   Nutzungszugriff erlauben. Die Bezeichnungen können in One UI abweichen.
6. „Kalle auf Homescreen starten“ wählen und zum Homescreen wechseln.

BENUTZEN

Eine Mission hat Originaltermin, aktuelle Erinnerung, Beschreibung, Kategorie,
Zeitlimit und optional Wochentage. „Fester externer Termin“ verschiebt beim
Aufschieben ausschließlich die Erinnerung, nie den ursprünglichen Termin.
Eine Erinnerung startet den Timer nicht automatisch. Du entscheidest: Starten,
Aufschieben oder Erledigt. Aktive Timer können pausiert und fortgesetzt werden.
10, 30 und 60 Minuten sind verfügbar. Anzahl und Gesamtzeit stehen im Detail.

Kalle antippen: Reaktion. Schnell mehrfach tippen: genervte Pose.
Lange drücken: Begleiter ausschalten. Missionen bleiben gespeichert.
Schlafende Figuren/Zelt können geweckt werden. Spenden sind ausschließlich
virtuelles Spielgeld; es gibt keine Überweisung oder Zahlungsfunktion.

In der Bude: Figur und Blase getrennt skalieren, Schrift, Dauer, Geschwindigkeit,
Bewegungsbereich, Grundlinie, Humor, vulgäre Texte, Ruhezeiten, Energiesparmodus,
Pause, Missionserinnerungen und Standard-Aufschieben einstellen.
Derbe Alttexte/eigene Texte erscheinen nur bei Humor „asozial“ mit erlaubten
vulgären Sprüchen. Der freundliche Katalog bleibt ohne solche Freigabe nutzbar.
Ruhezeiten pausieren Figur und spontane Sprüche; Missionserinnerungen werden
separat gesteuert. Identische Ruhe-Start-/Endzeit bedeutet ganztägige Ruhe.
Lange Blasen sind scrollbar; Antippen schließt gewöhnliche Spruchblasen.

DATEN

Alles bleibt lokal. Keine Internet- oder Mikrofonberechtigung, keine Werbung,
keine Tracker und keine Spracheingabe. Die vorhandene SharedPreferences-Datei
„missions“ wird mit abwärtslesbarem JSON weiterverwendet. Vor der ersten
3.0-Speicherung wird das ursprüngliche Missions-JSON intern gesichert.

Export und Import verwenden selbst gewählte JSON-Dateien. Diese enthalten deine
Missionstexte im Klartext. Privat aufbewahren. Ein Import ersetzt nach Bestätigung
die vorhandenen Daten und lässt den Begleiter ausgeschaltet. Vorher exportieren.

Jede Wiederholung zählt einmal. Die Wochenquote verwendet den ursprünglich
speicherten lokalen Fälligkeitstag, nicht die aufgeschobene Erinnerung. Kommende
geplante Aufgaben der Woche zählen bereits mit. Gelöschte Aufgaben zählen nicht
mehr; abgebrochene bleiben nicht erledigt. Wiederholungen werden acht Tage im
Voraus gespeichert. Ein persönliches Tagesziel ist von der Erledigungsquote
(erledigt / tatsächlich geplant) getrennt.

GRENZEN UND TESTSTAND

Build, Signatur und automatisierte Android-Frameworktests wurden durchgeführt.
Das sind Tests auf dem Rechner (Robolectric, API 35), keine echten Samsung- oder
Android-Emulator-Gerätetests. Den vollständigen Stand nennt TESTREPORT-3.0.md.

Die Figur orientiert sich am Vordergrund-Launcher-Paket. App-Schublade, Recents
und manche Systemoberflächen desselben Launchers lassen sich nicht zuverlässig
vom Homescreen trennen. Ausblendung erfolgt mit Abfrage-/Systemlatenz. Bei
fehlenden Erlaubnissen oder unbekanntem Vordergrund wird sicher ausgeblendet.
Kein Accessibility-Dienst. Das Widget ist eine Steuerung, die bewegliche Figur
ein eigenes transparentes Overlay. Berührungen außerhalb seiner begrenzten
Fenster sollen an den Launcher gehen; echte One-UI-Bedienprüfung steht aus.

Bei Display-Aus stoppt die Animationsschleife. Sichtbar sind maximal ca. 24 fps,
im Energiesparmodus ca. 12 fps. Ein Akku-Langzeittest wurde nicht durchgeführt.
Nach Handy-Neustart Kalle wieder manuell starten. Missionserinnerungen werden
nach dem ersten Entsperren wiederhergestellt. Nach „Stopp erzwingen“ die App neu
öffnen. Samsung kann Hintergrunddienste zusätzlich beenden; dann die App- und
Akku-Einstellungen prüfen. Keine erzwungenen Vollbildbenachrichtigungen.

Wiederholungen folgen bei Zeitzonenwechseln der lokalen Uhrzeit. Einmalige Termine
und bereits aufgeschobene Erinnerungen bleiben absolute Zeitpunkte. Manuelle
Systemuhr-Änderungen können die Restzeit laufender Timer beeinflussen.
Automatische Sonntagsberichte sind gemäß Originalauftrag erst für 3.3 geplant.

SPÄTERE UPDATES

Chaosbuddy-3-Signiersicherung.zip enthält den passwortgeschützten privaten
PKCS12-Schlüssel. Das Passwort steht ausschließlich im separaten privaten
Zugangsdokument. Beides privat und getrennt/offline sichern. Nicht in Git oder ein
öffentliches Quellprojekt geben. Ohne denselben Schlüssel sind keine direkten
Updates dieser neuen Linie möglich. Der Quellcode enthält keinen privaten Schlüssel.
